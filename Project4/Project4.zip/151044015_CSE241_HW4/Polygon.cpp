#include <iostream>
#include "Polygon.h"

namespace shape {

	double Polygon::Point2D::getCoord_x()const{		//get coord_x variable 
		return coord_x;
	}
	void Polygon::Point2D::setCoord_x(double new_coordinate){		//set coord_x variable
		coord_x=new_coordinate;
	}
	double Polygon::Point2D::getCoord_y()const{		//get coord_x variable 
		return coord_y;
	}
	void Polygon::Point2D::setCoord_y(double new_coordinate){		//set coord_y variable
		coord_y=new_coordinate;
	}
	int Polygon::getCapacity(){		//get private capacity variable
		return capacity;
	}
	Polygon::Point2D& Polygon::getArray(){	//it's for polygon obje's in polyline class accesing
		return *temp_obje;
	}	
	Polygon::Polygon(rectangle& obj_r){
		capacity=4;		//point num
		temp_obje= new Polygon::Point2D[4];					//I allocate memory for our shape of rectangle points.It has four points.
		//I set coorc of all points	my array
		temp_obje[0].setCoord_x(obj_r.getPosition_x());					//left
		temp_obje[0].setCoord_y(obj_r.getPosition_y());
		temp_obje[1].setCoord_x(obj_r.getWidth()+obj_r.getPosition_x());	//right
		temp_obje[1].setCoord_y(obj_r.getPosition_y());
		temp_obje[2].setCoord_x(obj_r.getPosition_x());					//left alt
		temp_obje[2].setCoord_y(obj_r.getHeight()+obj_r.getPosition_y());
		temp_obje[3].setCoord_x(obj_r.getWidth()+obj_r.getPosition_x());	//right and alt
		temp_obje[3].setCoord_y(obj_r.getHeight()+obj_r.getPosition_y());								

	}
	Polygon::Polygon(triangle& obj_t){			
		capacity=3;		//point num
		temp_obje= new Polygon::Point2D[3];				//I allocate memory for our shape of triangle points.It has three points.
		//I set coorc of all points	my array
		temp_obje[0].setCoord_x(obj_t.getPosition_x());
		temp_obje[0].setCoord_y(obj_t.getPosition_y());	
		temp_obje[1].setCoord_x(obj_t.getPosition_x2());
		temp_obje[1].setCoord_y(obj_t.getPosition_y2());
		temp_obje[2].setCoord_x(obj_t.getPosition_x3());
		temp_obje[2].setCoord_y(obj_t.getPosition_y3());					
	}
	Polygon::Polygon(circle& obj_c){		//conversion circle obje
		double teta;		//angle
		int i;		//loop element
		capacity=100;			//point num
		temp_obje= new Polygon::Point2D[100];			//allocation new shape points array
		for(i=0;i<100;i++){
			teta=i*(3.6)*3.14/180;														//calclating points angle
			//I set coorc of all points	my array
			temp_obje[i].setCoord_x (obj_c.getPosition_x()+obj_c.getRadius()*cos((teta)));		//calculate each x points
	    	temp_obje[i].setCoord_y (obj_c.getPosition_y()+obj_c.getRadius()*sin((teta)));		//calculate each y points	
		}	 
	}	
	const Polygon Polygon::operator +(const Polygon &other){		// adding polygon and creating new object
		int capacity,i,a=0;
		Polygon temp;									//new object
		capacity=this->capacity+other.capacity;			//nex object capacity size
		temp.capacity=capacity;		
		temp.temp_obje= new Polygon::Point2D[capacity];		//new arrat aloocation for two objects points
		for(i=0;i<this->capacity;i++){						//first array points adding
			temp.temp_obje[i]=this->temp_obje[i];
		}
		for(i;i<capacity;i++){	
			temp.temp_obje[i]=other.temp_obje[a];
			a++;
	
		}		

		return temp;									// adding polygon and creating new object
	}

	bool Polygon::operator ==(  Polygon& obj){		/*this function comparison operators to compare two shapes (circle circle) with respect to their areas.*/
		if(this->capacity==obj.capacity){		//controlled capasity size
			for(int i=0;i<this->capacity;i++){
				if((this->temp_obje[i].getCoord_x()!=obj.temp_obje[i].getCoord_x()) && (this->temp_obje[i].getCoord_y()!=obj.temp_obje[i].getCoord_y()))	//check all points polgons
					return false;		//not equal
			}
			return true;	//equal
		}
		return false;		//capacity different so not equal
	}
	bool Polygon::operator !=(  Polygon& obj){		/*this function comparison operators to compare two shapes (circle circle) with respect to their areas.*/
		if(this->capacity==obj.capacity){		//controlled capasity size
			for(int i=0;i<this->capacity;i++){
				if((this->temp_obje[i].getCoord_x()==obj.temp_obje[i].getCoord_x()) && (this->temp_obje[i].getCoord_y()==obj.temp_obje[i].getCoord_y()))	//check all points polgons
					return false;		//not equal
			}
			return true;	//equal
		}
		return true;		//capacity different so not equal
	}

	Polygon& Polygon::Polygon ::operator[](int index){		/*this function [] overloaded for accessing vector eleman which type of ShapeElem class object*/
		if (index >= capacity){		//error condition
			cout << "Illegal index in Polygon.\n";
			exit(0);
		}			
		return this[index];									//return polygon object
	}
	Polygon::Point2D& Polygon::Point2D::operator[](int index){
		return this[index];									//return polygon object

	}

	ostream& operator <<(ostream& outputStream, const Polygon &obje){		//writing svg file for all shape overloading
		int i;
		if(obje.capacity==4){									//write svg file for our rectangle obje
		   	  outputStream<<"<polygon points="<<"\""<<obje.temp_obje[0].getCoord_x() <<" "<<obje.temp_obje[0].getCoord_y() <<" "<<obje.temp_obje[2].getCoord_x() <<" "<<obje.temp_obje[2].getCoord_y() <<" "<<obje.temp_obje[3].getCoord_x() <<" "<<obje.temp_obje[3].getCoord_y()<<" " <<obje.temp_obje[1].getCoord_x() <<" "<<obje.temp_obje[1].getCoord_y() <<" \""<< 
		  " stroke="<<"\"transparent\""<< " fill="<<"\"green\""<< " stroke-width="<<"\"0.3\""<<"/>\n";	
		}
		else if(obje.capacity==3){								//write svg for our triangle obje
		   	  outputStream<<"<polygon points="<<"\""<<obje.temp_obje[0].getCoord_x() <<" "<<obje.temp_obje[0].getCoord_y() <<" "<<obje.temp_obje[2].getCoord_x() <<" "<<obje.temp_obje[2].getCoord_y() <<" "<<obje.temp_obje[1].getCoord_x() <<" "<<obje.temp_obje[1].getCoord_y() <<" \""<< 
		  " stroke="<<"\"transparent\""<< " fill="<<"\"green\""<< " stroke-width="<<"\"0.3\""<<"/>\n";		
		 }	
		else {
			outputStream<<"<polygon points="<<"\"";
			for(i=0;i<obje.capacity;i++){						// write svg file our 100 point for circle
				outputStream<<obje.temp_obje[i].getCoord_x() <<" "<<obje.temp_obje[i].getCoord_y() <<" ";		
			}
			outputStream<<"\""<<" stroke="<<"\"transparent\""<< " fill="<<"\"green\""<< " stroke-width="<<"\"0.3\""<<"/>\n";	
		}
		return outputStream;		//return outputfile
	}

	Polygon& Polygon::operator =( const Polygon& rightSide){		/*assigment operator overloading*/
		if ( this == &rightSide){	//if the right side is the same as the left side
			return * this;
		}		
		if (capacity != rightSide.capacity){							//it'for incrementing size if the our object capacity smaller than other
	 		delete [] temp_obje;										//delete our allocated point2d obje
	 		temp_obje = new Polygon::Point2D[rightSide.capacity];
	 	}
	 	capacity = rightSide.capacity;								
	 	for ( int i = 0; i < capacity; i++)								//assign point from other ocject
	 		temp_obje[i] = rightSide.temp_obje[i];
	 	return * this;
	}		
	Polygon::~Polygon(){												//destructur
		delete  temp_obje;												//delete allocated memory
	}
	Polygon::Polygon( const Polygon& obje):capacity(obje.capacity){		//copy constructure
		temp_obje = new Polygon::Point2D[capacity];		
		for ( int i = 0; i < capacity; i++)								//copy points to another obje
			temp_obje[i] = obje.temp_obje[i];
	
	}
	
}

	
