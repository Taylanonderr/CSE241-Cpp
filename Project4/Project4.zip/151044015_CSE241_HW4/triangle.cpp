	#include "triangle.h"

	namespace {		//unnamed namespace  helper functions for adding and subbing 1 to coordinates
		int adding_x(int coord_x){
			coord_x++;
			return coord_x;
		}
		int adding_y(int coord_y){
			coord_y++;
			return coord_y;
		}
		int subbing_x(int coord_x){
			coord_x--;
			return coord_x;
		}
		int subbing_y(int coord_y){
			coord_y--;
			return coord_y;
		}			
	}

namespace shape {

		double triangle::area = 0;		/*static members beginning value assigment*/
		double triangle::length = 0;
		triangle::triangle(){};	/*default counstructure*/
		triangle::triangle(double first,double second,double third, double fourth, double fifth,double sixth ){	/*setting triangle coordinates constructure*/
				x=first;
				y=second;
				x2=third;
				y2=fourth;
				x3=fifth;
				y3=sixth;				
			

		}
		triangle::triangle(double first,double second,double third, double fourth, double fifth,double sixth,double side_t ){		/*this constructure for assign member value in new triangle obje in ShapeElem class*/
			if(side_t>0){
				x=first;	
				y=second;
				x2=third;
				y2=fourth;
				x3=fifth;
				y3=sixth;
				side=side_t;
				area+=(side*side*sqrt(3))/4;
				length+=3*side;				
			}			
		}					
		triangle::triangle(double f_side){		/*When the user send side I determine begin coordinates for triangle shape*/
		  if(f_side>0){
			  setSide(f_side);			
		   	  x=0;
		   	  y=(f_side*sqrt(3))/2;
		   	  
		   	  x2=f_side/2;
		   	  y2=0;
		   	  
		   	  x3=f_side;
		   	  y3=(f_side*sqrt(3))/2;  		  	
		  }
		}	
		double triangle::getSide()const{	/*get side for triangle objes for another class or functions which in not this class*/
			return side;
		}
		void triangle::setSide(double side_t){		/*set side for triangle objes for another class or functions which in not this class*/
			side=side_t;
		}		
		double triangle::getPosition_x()const{		/*get coordinate first x for circle objes for another class or functions which in not this class*/
			return x;
		}
		void triangle::setPosition_x(double x_koordinat){	/*set coordinate first x for circle objes for another class or functions which in not this class*/
			x=x_koordinat;
		}
		double triangle::getPosition_y()const{		/*get coordinate first y for circle objes for another class or functions which in not this class*/
			return y;	
		}				
		void triangle::setPosition_y(double y_koordinat){		/*set coordinate first y for circle objes for another class or functions which in not this class*/
			y=y_koordinat;
		}
		double triangle::getPosition_x2()const{		/*get coordinate second x for circle objes for another class or functions which in not this class*/
			return x2;
		}
		void triangle::setPosition_x2(double x_koordinat){		/*set coordinate second x for circle objes for another class or functions which in not this class*/
			x2=x_koordinat;
		}
		double triangle::getPosition_y2()const{		/*get coordinate second y for circle objes for another class or functions which in not this class*/
			return y2;
		}				
		void triangle::setPosition_y2(double y_koordinat){		/*set coordinate second y for circle objes for another class or functions which in not this class*/
			y2=y_koordinat;
		}
		double triangle::getPosition_x3()const{		/*get coordinate third x for circle objes for another class or functions which in not this class*/
			return x3;
		}
		void triangle::setPosition_x3(double x_koordinat){		/*set coordinate third x for circle objes for another class or functions which in not this class*/
			x3=x_koordinat;
		}
		double triangle::getPosition_y3()const{		/*get coordinate third y for circle objes for another class or functions which in not this class*/
			return y3;
		}				
		void triangle::setPosition_y3(double y_koordinat){		/*set coordinate third y for circle objes for another class or functions which in not this class*/
			y3=y_koordinat;
		}									
		ostream& operator <<(ostream& file, const triangle& shape){
		   	  file<<"<polygon points="<<"\"0 "<<shape.y<<" "<<shape.x2<<" 0"<<" "<<shape.x3<<" "<<shape.y3<<"\""<<   // 3 noktanın x ve y koordinatlarını gireceğiz
		  " stroke="<<"\"transparent\""<< " fill="<<"\"red\""<< " stroke-width="<<"\"0.3\""<<"/>\n";	
		 	return file;
		}	

		double triangle::triangle_area(){	/*this function return the triagnle area*/
			double area;
			area=(side*side*sqrt(3))/4;
			return area;
		}
		double triangle::perimeter_l(){		/*this function return the triagnle perimeter length*/
			double perimeter_length;
			perimeter_length=3*side;
			return perimeter_length;
		}

		const triangle triangle::operator +( const double adding_size){			/*this function add double to the size of the shape to make the new shape.*/
			side+=adding_size;
			return *this;
		}
		const triangle triangle::operator -( const double subbing_size){		/*this function sub double to the size of the shape to make the new shape.*/
			side-=subbing_size;
			return *this;
		}		
		triangle triangle:: operator++(int ignoreMe) //Postfix version 
		{
			auto temp1 = x;
	 		auto temp2 = y;
	 		auto temp3 =x2;
	 		auto temp4 =y2;
	 		auto temp5 =x3;
	 		auto temp6 =y3;	 		
			x=adding_x(x);	//helper funcitons
			y=adding_x(y);
			x2=adding_x(x2);
			y2=adding_x(y2);
			x3=adding_x(x3);
			y3=adding_x(y3);
 			return triangle(temp1, temp2,temp3,temp4,temp5,temp6);	/*return first coordinates value but after return will be adding one*/
		}
		triangle triangle:: operator++( ) //Prefix version
		{
			x=adding_x(x);	//helper funcitons
			y=adding_x(y);
			x2=adding_x(x2);
			y2=adding_x(y2);
			x3=adding_x(x3);
			y3=adding_x(y3);
			return triangle(x, y,x2,y2,x3,y3);	/*return adding 1 coordinates value */
		}
		triangle triangle:: operator--(int ignoreMe) //Postfix version 
		{
			auto temp1 = x;
	 		auto temp2 = y;
	 		auto temp3 =x2;
	 		auto temp4 =y2;
	 		auto temp5 =x3;
	 		auto temp6 =y3;	 		
			x=subbing_x(x);	//helper funcitons
			y=subbing_x(y);
			x2=subbing_x(x2);
			y2=subbing_x(y2);
			x3=subbing_x(x3);
			y3=subbing_x(y3);
 			return triangle(temp1, temp2,temp3,temp4,temp5,temp6);	/*return first coordinates value but after return will be subbing one*/
		}
		triangle triangle:: operator--( ) //Prefix version
		{
			x=subbing_x(x);	//helper funcitons
			y=subbing_x(y);
			x2=subbing_x(x2);
			y2=subbing_x(y2);
			x3=subbing_x(x3);
			y3=subbing_x(y3);
			return triangle(x, y,x2,y2,x3,y3);	/*return subbed 1 coordinates value */
		}							
		bool operator ==(  triangle& obj1, triangle& obj2){		/*this function comparison operators to compare two shapes with respect to their areas.*/
			return(obj1.triangle_area()==obj2.triangle_area());
		}	
		bool operator !=(  triangle& obj1, triangle& obj2){		/*this function comparison operators to compare two shapes with respect to their areas.*/
			return(obj1.triangle_area()!=obj2.triangle_area());
		}
		bool operator >(  triangle& obj1, triangle& obj2){		/*this function compare with > operator first object bigger than second*/
			return(obj1.triangle_area()>obj2.triangle_area());
		}
		bool operator <( triangle& obj1, triangle& obj2){		/*this function compare with < operator first object smaller than second*/
			return(obj1.triangle_area()<obj2.triangle_area());
		}
		double triangle::total_areas(){
			return area;
		}
		double triangle::perimeter_length(){
			return length;
		}	
	}