#ifndef POLYGON_H_
#define POLYGON_H_
#include <iostream>
#include <fstream>
#include <cmath>
#include <vector>
#include "rectangle.h"
#include "circle.h"
#include "triangle.h"

using namespace std;

namespace shape {

class Polygon{
	public:
		Polygon(){}
		Polygon( const Polygon& obje);
		Polygon(rectangle &obj);
		Polygon(triangle &obj);
		Polygon(circle &obj);	
		class Point2D{
			public:			
				double getCoord_x()const;
				void setCoord_x(double new_coordinate);
				double getCoord_y()const;
				void setCoord_y(double new_coordinate);		
				Polygon::Point2D& operator[](int index);
					
			private:
				double coord_x;
				double coord_y;

		};
		Polygon& operator =( const Polygon& rightSide);
		friend ostream& operator <<(ostream& outputStream, const Polygon &obje);	
			
		const Polygon operator +(const Polygon &other);
		bool operator ==( Polygon& obj);
		bool operator !=( Polygon& obj);
		Polygon& operator[](int index);
		int getCapacity();
		Polygon::Point2D& getArray();
		~Polygon();

	private:
		Polygon::Point2D *temp_obje;
		int capacity;
	};
}

#endif	
