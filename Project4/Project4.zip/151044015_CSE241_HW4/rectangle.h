#ifndef RECTANGLE_H_
#define RECTANGLE_H_
#include <iostream>
#include <fstream>

using namespace std;
namespace shape {

	class rectangle{
		public:
			rectangle();
			rectangle(double width_num,double height_num);
			rectangle(double x_k,double y_k ,double r_width,double r_height);

			int getWidth()const;
			void setWidth(double width_r);		
			int getHeight()const;
			void setHeight(double height_r);
			double getPosition_x()const;
			void setPosition_x(double x_koordinat);		
			double getPosition_y()const;
			void setPosition_y(double y_koordinat);											
			double rectangle_area();		
			double perimeter_l();		
			friend ostream& operator <<(ostream& outputStream, const rectangle& shape);		
			const rectangle operator +( const double adding_size);		
			const rectangle operator -( const double subbing_size);
			friend bool operator!=(  rectangle& obj1, rectangle& obj2);
			friend bool operator ==(  rectangle& obj1, rectangle& obj2);	
			friend bool operator >(  rectangle& obj1, rectangle& obj2);	
			friend bool operator <(  rectangle& obj1, rectangle& obj2);
					
			rectangle operator++(); //Prefix version	
			rectangle operator++(int ); //Postfix version	
			rectangle operator--(); //Prefix version	
			rectangle operator--(int ); //Postfix version			
			static double total_areas();
			static double perimeter_length();
		private:
			int width;
			int height;
			double x;
			double y;
			static double area; 
			static double length;
	};	
	
}
#endif
