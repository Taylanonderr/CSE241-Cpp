#ifndef TRIANGLE_H_
#define TRIANGLE_H_
	#include <iostream>
	#include <fstream>
	#include <cmath>
#include <vector>

using namespace std;
namespace shape {
	class triangle{
		public:
			triangle();
			triangle(double f_side);		
			triangle(double first,double second,double third, double fourth, double fifth,double sixth );	
			triangle(double first,double second,double third, double fourth, double fifth,double sixth,double side_t );		

			double getSide()const;
			void setSide(double side_t);	
			double getPosition_x()const;
			void setPosition_x(double x_koordinat);
			double getPosition_y()const;			
			void setPosition_y(double y_koordinat);
			double getPosition_x2()const;
			void setPosition_x2(double x_koordinat);
			double getPosition_y2()const;	
			void setPosition_y2(double y_koordinat);
			double getPosition_x3()const;
			void setPosition_x3(double x_koordinat);
			double getPosition_y3()const;			
			void setPosition_y3(double y_koordinat);						
			double triangle_area();
			double perimeter_l();		
			friend ostream& operator <<(ostream& outputStream, const triangle& shape);		
			const triangle operator +(  const double addbing_size);		
			const triangle operator -(  const double subbing_size);	
			friend bool operator !=( triangle& obj1, triangle& obj2);
			friend bool operator ==( triangle& obj1, triangle& obj2);	
			friend bool operator >(  triangle& obj1, triangle& obj2);	
			friend bool operator <(  triangle& obj1, triangle& obj2);		
			triangle operator++(); //Prefix version	
			triangle operator++(int ); //Postfix version
			triangle operator--(); //Prefix version	
			triangle operator--(int ); //Postfix version				
			static double total_areas();
			static double perimeter_length();

		private:
			double side;
			double x;
			double x2;
			double x3;
			double y;
			double y2;
			double y3;
			static double area; 
			static double length;		
	};
}
	

#endif
