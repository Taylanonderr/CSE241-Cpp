#include <iostream>
#include "Polyline.h"
using namespace std;

namespace shape {
		/*I initiliaze the << operator for polyline drawing*/
	ostream& operator <<(ostream& outputStream,  Polyline &obje){		//writing svg file for all shape overloading
		int i;
		if(obje.poly_obje.getCapacity()==4){									//write svg file for our rectangle obje
		   	  outputStream<<"<polyline points="<<"\""<<obje.poly_obje.getArray()[0].getCoord_x() <<" "<<obje.poly_obje.getArray()[0].getCoord_y() <<" "<<obje.poly_obje.getArray()[1].getCoord_x() <<" "<<obje.poly_obje.getArray()[1].getCoord_y()<<" "" \""<<" style="<<"\"fill:red;stroke:green;stroke-width:4\""<<"/>\n";	

		   	  outputStream<<"<polyline points="<<"\""<<obje.poly_obje.getArray()[1].getCoord_x() <<" "<<obje.poly_obje.getArray()[1].getCoord_y() <<" "<<obje.poly_obje.getArray()[3].getCoord_x() <<" "<<obje.poly_obje.getArray()[3].getCoord_y()<<" "" \""<<" style="<<"\"fill:red;stroke:green;stroke-width:4\""<<"/>\n";	

		   	  outputStream<<"<polyline points="<<"\""<<obje.poly_obje.getArray()[3].getCoord_x() <<" "<<obje.poly_obje.getArray()[3].getCoord_y() <<" "<<obje.poly_obje.getArray()[2].getCoord_x() <<" "<<obje.poly_obje.getArray()[2].getCoord_y()<<" "" \""<<" style="<<"\"fill:red;stroke:green;stroke-width:4\""<<"/>\n";	
		}
		else if(obje.poly_obje.getCapacity()==3){								//write svg for our triangle obje
		   	  outputStream<<"<polyline points="<<"\""<<obje.poly_obje.getArray()[0].getCoord_x() <<" "<<obje.poly_obje.getArray()[0].getCoord_y() <<" "<<obje.poly_obje.getArray()[1].getCoord_x() <<" "<<obje.poly_obje.getArray()[1].getCoord_y() <<" "<<" \""<<" style="<<"\"fill:red;stroke:green;stroke-width:4\""<<"/>\n";	 
		   	  outputStream<<"<polyline points="<<"\""<<obje.poly_obje.getArray()[1].getCoord_x() <<" "<<obje.poly_obje.getArray()[1].getCoord_y() <<" "<<obje.poly_obje.getArray()[2].getCoord_x() <<" "<<obje.poly_obje.getArray()[2].getCoord_y() <<" "<<" \""<< " style="<<"\"fill:red;stroke:green;stroke-width:4\""<<"/>\n";	

		 }	
		else {
			for(i=0;i<obje.poly_obje.getCapacity()-1;i++){						// write svg file our 100 point for circle
				outputStream<<"<polyline points="<<"\""<<obje.poly_obje.getArray()[i].getCoord_x() <<" "<<obje.poly_obje.getArray()[i].getCoord_y() <<" "<<obje.poly_obje.getArray()[i+1].getCoord_x() <<" "<<obje.poly_obje.getArray()[i+1].getCoord_y() <<" "<<" \""<< " style="<<"\"fill:red;stroke:green;stroke-width:4\""<<"/>\n";		
			}
		}		
		return outputStream;		//return outputfile
	}


	
}

	
