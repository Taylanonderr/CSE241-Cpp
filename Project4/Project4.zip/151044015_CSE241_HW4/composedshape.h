#ifndef COMPOSEDSHAPE_H_
#define COMPOSEDSHAPE_H_
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <vector>
#include "rectangle.h"
#include "circle.h"
#include "Polygon.h"
#include "Polyline.h"
#include "triangle.h"


using namespace std;

namespace shape {
	class ComposedShape{
		public:
			ComposedShape();
			ComposedShape(rectangle &shape,rectangle &small_shape);	/*this constructor for main container rectangle and small container rectangle assign the objes which create in main,to composedshape clas's objes*/
			ComposedShape(rectangle &shape,triangle &small_shape );	/*this constructor for main container rectangle and small container triangle assign the objes which create in main,to composedshape clas's objes*/
			ComposedShape(rectangle &shape,circle &small_shape);	/*this constructor for main container rectangle and small container circle assign the objes which create in main,to composedshape clas's objes*/	
			ComposedShape(triangle &shape,rectangle &small_shape );	/*this constructor for main container triangle and small container rectangle assign the objes which create in main,to composedshape clas's objes*/
			ComposedShape(triangle &shape,triangle &small_shape);	/*this constructor for main container triangle and small container triangle assign the objes which create in main,to composedshape clas's objes*/
			ComposedShape(triangle &shape,circle &small_shape);		/*this constructor for main container triangle and small container circle assign the objes which create in main,to composedshape clas's objes*/
			ComposedShape(circle &shape,rectangle &small_shape );	/*this constructor for main container circle and small container rectangle assign the objes which create in main,to composedshape clas's objes*/
			ComposedShape(circle &shape,triangle &small_shape);		/*this constructor for main container circle and small container triangle assign the objes which create in main,to composedshape clas's objes*/
			ComposedShape(circle &shape,circle &small_shape);		/*this constructor for main container circle and small container circle assign the objes which create in main,to composedshape clas's objes*/		
			void optimalfit();
			inline char getMainchar()const;
			void setMainchar(char main_container);
			inline char getSmallchar()const;
			void setSmallchar(char main_container);	
			vector<Polygon> getVector_Polygon()const;
			void setVector_Polygon(Polygon shape_obje);
			vector<Polyline> getVector_Polyline()const;
			void setVector_Polyline(Polyline shape_obje);
			rectangle getobje(){return small_rectangle; }	
			friend ostream& operator <<(ostream& outputStream,const ComposedShape& obje);
			ComposedShape& operator[](int index);

		private:
		rectangle small_rectangle;
		triangle triang;
		triangle small_triangle;	
		rectangle rectang;
		circle circ;
		circle small_circle;		
		char main_char;
		char small_char;
		vector <Polygon> shape_polygon;		
		vector <Polyline> shape_polyline;						
		void optimalfit_helper1();
		void optimalfit_helper2();
		void optimalfit_helper3();
		void optimalfit_helper4();
		void optimalfit_helper5();
		void optimalfit_helper6();
		void optimalfit_helper7();
		void optimalfit_helper8();
		void optimalfit_helper9();
	};
}

#endif	
