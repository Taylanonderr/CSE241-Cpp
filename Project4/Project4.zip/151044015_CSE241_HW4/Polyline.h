#ifndef POLYLINE_H_
#define POLYLINE_H_
#include <iostream>
#include <fstream>
#include <cmath>
#include <vector>
#include "rectangle.h"
#include "circle.h"
#include "triangle.h"
#include "Polygon.h"

using namespace std;

namespace shape {

class Polyline{
	public:
		Polyline(){}
	
		friend ostream& operator <<(ostream& outputStream,  Polyline &obje);	
		Polygon poly_obje;

	private:
	};
}

#endif	
