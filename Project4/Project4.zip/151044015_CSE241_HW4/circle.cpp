	#include "circle.h"

	namespace {		//unnamed namespace helper functions for adding and subbing 1 to coordinates
		int adding_x(int coord_x){
			coord_x++;
			return coord_x;
		}
		int adding_y(int coord_y){
			coord_y++;
			return coord_y;
		}
		int subbing_x(int coord_x){
			coord_x--;
			return coord_x;
		}
		int subbing_y(int coord_y){
			coord_y--;
			return coord_y;
		}			
	}

	namespace shape {
		double circle::area = 0;		/*static members beginning value assigment*/
		double circle::length = 0;
		circle::circle(){};
		circle::circle(double first,double second){		/*setting circle coordinates constructure and */
			if(first>0 && second>0){
				x=first;
				y=second;
			}
		}

		circle::circle(double f_radius){	/*When the user send radius I determine begin coordinate shape*/
			if(f_radius>0){
				setRadius(f_radius);
				setPosition_x(f_radius);
				setPosition_y(f_radius);				
			}			
		}
		circle::circle(double x_k,double y_k,double radius_c){
			if(x_k>0 && y_k>0){
				x=x_k;
				y=y_k;
				radius=radius_c;
				area+=(radius*radius*3.14);
				length+=(2*radius*3.14);		
			}			
		}					
		double circle:: getRadius()const{	/*get radius for circle objes for another class or functions which in not this class*/
			return radius;
		}
		void circle::setRadius(double radius_c){	/*set radius for circle objes for another class or functions which in not this class*/
			radius=radius_c;
		}		
		double circle::getPosition_x()const{	/*get coordinate x for circle objes for another class or functions which in not this class*/
			return x;
		}
		void circle::setPosition_x(double x_koordinat){		/*set coordinate x for circle objes for another class or functions which in not this class*/
			x=x_koordinat;
		}
		double circle::getPosition_y()const{	/*get coordinate y for circle objes for another class or functions which in not this class*/
			return y;
		}
		void circle::setPosition_y(double y_koordinat){		/*set coordinate y for circle objes for another class or functions which in not this class*/
			y=y_koordinat;
		}						
		void circle::setShape(char choise){		/*set character for user input to use in composedshape class control in optimalfit function*/
			main_shape = choise;	
		}
		double circle::circle_area(){		/*this function return the circle area*/
			double area;
			area=3.14*radius*radius;
			return area;
		}
		double circle::perimeter_l(){		/*this function return the circle perimeter length*/
			double perimeter_length;
			perimeter_length=2*3.14*radius;
			return perimeter_length;
		}	

		ostream& operator <<(ostream& file, const circle& shape){
		  	file<<"<circle cx="<<"\""<<shape.getPosition_x() <<"\""<<" cy="<<"\""<<shape.getPosition_y()<<"\""<< " r="<<"\""<<shape.getRadius()<<"\"" <<" stroke="<<"\"green\""<<" fill="<<"\"red\""<<" stroke-width="<<"\"0\""<<" />\n";
			return file;
		}			
		const circle circle::operator +(const double adding_size){		/*this function add double to the size of the shape to make the new shape.*/
			radius+=adding_size;
			return *this;
		}
		const circle circle::operator -(const double subbing_size){		/*this function sub double to the size of the shape to make the new shape.*/
			radius-=subbing_size;
			return *this;
		}		
	
		const circle circle:: operator++(int ignoreMe) //Postfix version 
		{
			int temp1 = x;
	 		int temp2 = y;
	 		x=adding_x(x);	//unnamed namespace using here
			y=adding_y(y);	//unnamed namespace using here
 			return circle(temp1, temp2);	/*return first coordinates value but after return will be adding one*/
		}
		const circle circle:: operator++( ) //Prefix version
		{
	 		x=adding_x(x);	//unnamed namespace using here
			y=adding_y(y);	//unnamed namespace using here
			return circle(x, y);		/*return adding 1 coordinates value */
		}	
		const circle circle:: operator--(int ignoreMe) //Postfix version 
		{
			int temp1 = x;
	 		int temp2 = y;
	 		x=subbing_x(x);	//unnamed namespace using here
			y=subbing_y(y);	//unnamed namespace using here
 			return circle(temp1, temp2);		/*return first coordinates value but after return will be subbing one*/
		}
		const circle circle:: operator--( ) //Prefix version
		{
	 		x=subbing_x(x);	//unnamed namespace using here
			y=subbing_y(y);	//unnamed namespace using here
			return circle(x, y);		/*return subbed 1 coordinates value */
		}		
		bool operator ==(  circle& obj1, circle& obj2){		/*this function comparison operators to compare two shapes (circle circle) with respect to their areas.*/
			return(obj1.circle_area()==obj2.circle_area());			
		}	
		bool operator !=(  circle& obj1, circle& obj2){		/*this function comparison operators to compare two shapes (circle circle) with respect to their areas.*/
			return(obj1.circle_area()!=obj2.circle_area());
		}
		bool operator >(  circle& obj1, circle& obj2){		/*this function compare with > operator first object bigger than second*/
			return(obj1.circle_area()>obj2.circle_area());
		}
		bool operator <(  circle& obj1, circle& obj2){		/*this function compare with < operator first object smaller than second*/
			return(obj1.circle_area()<obj2.circle_area());
		}			
		double circle::total_areas(){
			return area;
		}
		double circle::perimeter_length(){
			return length;
		}			
	}	