#include <iostream>
#include <fstream>
#include "rectangle.h"
using namespace std;

	namespace {		//unnamed namespace helper functions for adding and subbing 1 to coordinates.I used in postfix and prefix version
		int adding_x(int coord_x){
			coord_x++;
			return coord_x;
		}
		int adding_y(int coord_y){
			coord_y++;
			return coord_y;
		}
		int subbing_x(int coord_x){
			coord_x--;
			return coord_x;
		}
		int subbing_y(int coord_y){
			coord_y--;
			return coord_y;
		}			
	}

namespace shape {
		double rectangle::area = 0;		/*static members beginning value assigment*/
		double rectangle::length = 0;
		rectangle::rectangle(){}	/*default constructure*/
		rectangle::rectangle(double width_num,double height_num ){	/*setting rectangle width and height value*/
			if(width_num>0 && height_num>0){
				setWidth(width_num);
				setHeight(height_num);				
			}
			x=0;
			y=0;
				
		}
		rectangle::rectangle(double x_k,double y_k ,double r_width,double r_height){	/*this constructure for assign member value in new rectangle obje in ShapeElem class*/
				x=x_k;
				y=y_k;
				width=r_width;
				height=r_height;
				area+=width*height;
				length+=(2*width+2*height);				
			
	
		}		
		int rectangle::getWidth()const{		/*get width for rectangle objes for another class or functions which in not this class*/
			return width;
		}
		void rectangle::setWidth(double width_r){		/*set width for rectangle objes for another class or functions which in not this class*/
			width=width_r;
		}		
		int rectangle::getHeight()const{		/*get height for rectangle objes for another class or functions which in not this class*/
			return height;
		}
		void rectangle::setHeight(double height_r){		/*set height for rectangle objes for another class or functions which in not this class*/
			height=height_r;
		}
		double rectangle::getPosition_x()const{		/*get coordinate x for circle objes for another class or functions which in not this class*/
			return x;
		}
		void rectangle::setPosition_x(double x_koordinat){		/*set coordinate y for circle objes for another class or functions which in not this class*/
			x=x_koordinat;
		}		
		double rectangle::getPosition_y()const{		/*get coordinate y for circle objes for another class or functions which in not this class*/
			return y;
		}
		void rectangle::setPosition_y(double y_koordinat){		/*set coordinate y for circle objes for another class or functions which in not this class*/
			y=y_koordinat;
		}												

		double rectangle::rectangle_area(){	/*this fuction return area of the shape*/
			double area;
			area=width*height;
			return area;
		}
		double rectangle::perimeter_l(){	/*this function return the perimeter length*/
			double perimeter_length;
			perimeter_length=2*width+2*height;
			return perimeter_length;
		}
		ostream& operator <<(ostream& file, const rectangle& shape){	/*this overloaded operator << for drawing(writing) rectangle shape to an ostream object such as an SVG file*/
	 		file <<"<rect width="<<"\""<<shape.getWidth()<<"\""<<" height="<<"\""<<shape.getHeight()<<"\""<<" x="<<"\""<<0<<"\""<<" y="<<"\""<<0<<"\""<<" stroke="<< "\"red\""<<" fill=\"red\""<< " stroke-width="<<"\"0.1\""<<" />\n\t";				
			return file;
		}	
		const rectangle rectangle::operator +( const double adding_size){	/*this function add double to the size of the shape to make the new shape.*/
			width=width+adding_size;
			height=height+adding_size;
			return *this;
		}
		const rectangle rectangle::operator -( const double subbing_size){		/*this function sub double to the size of the shape to make the new shape.*/
			width-=subbing_size;
			height-=subbing_size;
			return *this;
		}	
		bool operator ==( rectangle& obj1,rectangle& obj2){		/*this function comparison operators to compare two shapes with respect to their areas.*/
			return(obj1.rectangle_area()==obj2.rectangle_area());
		}	
		bool operator !=( rectangle& obj1, rectangle& obj2){		/*this function comparison operators to compare two shapes with respect to their areas.*/
			return(obj1.rectangle_area()!=obj2.rectangle_area());
		}
		bool operator >(  rectangle& obj1, rectangle& obj2){		/*this function compare with > operator first object bigger than second*/
			return(obj1.rectangle_area()>obj2.rectangle_area());
		}
		bool operator <(  rectangle& obj1, rectangle& obj2){		/*this function compare with < operator first object smaller than second*/
			return(obj1.rectangle_area()<obj2.rectangle_area());
		}						

		rectangle rectangle:: operator++(int ignoreMe) //Postfix incrementing version 
		{
			auto temp1 = x;
	 		auto temp2 = y;
			x=adding_x(x);
			y=adding_x(y);
 			return rectangle(temp1, temp2);	/*return first x,y value but after return will be adding one*/
		}
		rectangle rectangle:: operator++( ) //Prefix incrementing version
		{
			x=adding_x(x);
			y=adding_x(y);
			return rectangle(x, y);	/*return adding 1 x,y value */
		}	
		rectangle rectangle:: operator--(int ignoreMe) //Postfix decreasing version 
		{
			auto temp1 = x;
	 		auto temp2 = y;
			x=subbing_x(x);
			y=subbing_x(y);
 			return rectangle(temp1, temp2);		/*return first x,y value but after return will be subbing one*/
		}
		rectangle rectangle:: operator--( ) //Prefix decreasing version
		{
			x=subbing_x(x);
			y=subbing_x(y);
			return rectangle(x, y);			/*return subbed 1 x,y value */
		}					
		double rectangle::total_areas(){
			return area;
		}
		double rectangle::perimeter_length(){
			return length;
		}	
}
