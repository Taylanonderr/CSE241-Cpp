#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <vector>
#include "composedshape.h"
#include "rectangle.h"
#include "circle.h"
#include "triangle.h"
#include "Polygon.h"
#include "Polyline.h"


using namespace std;
using namespace shape ;

int main(){
	int i=0,r=0,t=0,c=0;
	double width,height;
	double radius,side,small_side,s_radius,small_width,small_height;
	string file[10];	/*for output filenames*/
	char choose[9][2],second_choose[9][2];		
	rectangle	rect_obj[1];	/*this array for main conventer*/
	rectangle	small_rect_obj[3];	/*this array obje for small shapes using in loop*/
	triangle tri_obj[1];	/*this array for main conventer*/
	triangle small_tri_obj[3];	/*this array obje for small shapes using in loop*/	
	circle	circ_obj[1];	/*this array for main conventer*/
	circle	small_circ_obj[3];	/*this array obje for small shapes using in loop*/

	Polygon p_array[5];
	ComposedShape composed_array[5];
	rect_obj[0]=rectangle (1000.0,800.0);	/*it's for trying main rectangle obj*/
	small_rect_obj[0]=rectangle (52.0,30.0);	/*it's for trying small rectangle obj*/
	small_rect_obj[1]=rectangle (100.0,78.0);	/*it's for trying small rectangle obj*/
	small_rect_obj[2]=rectangle (80.0,70.0);	/*it's for trying small rectangle obj*/	

	tri_obj[0]=triangle (800.0);		/*it's for trying main triangle obj*/
	small_tri_obj[0]=triangle (90.0);		/*it's for trying small rectangle obj*/
	small_tri_obj[1]=triangle (56.0);		/*it's for trying small rectangle obj*/
	small_tri_obj[2]=triangle (150.0);	/*it's for trying small rectangle obj*/


	circ_obj[0]=circle (300.0);		/*it's for trying main circle obj*/
	small_circ_obj[0]=circle (82.0);		/*it's for trying small circle obj*/
	small_circ_obj[1]=circle (100.0);		/*it's for trying small circle obj*/
	small_circ_obj[2]=circle (25.0);		/*it's for trying small circle obj*/
	/*I compare two object when I didn't write anyting*/

	p_array[0]=Polygon(small_rect_obj[0]);	//polygon constructures working
	p_array[1]=Polygon(small_rect_obj[0]);
	p_array[2]=Polygon(small_circ_obj[0]);
	p_array[3]=Polygon(small_rect_obj[1]);
	p_array[4]=Polygon(small_tri_obj[1]);


	composed_array[0]=ComposedShape(rect_obj[0],small_rect_obj[1]);	
	composed_array[1]=ComposedShape(rect_obj[0],small_tri_obj[2]);	
	composed_array[2]=ComposedShape(rect_obj[0],small_circ_obj[2]);	
	composed_array[3]=ComposedShape(tri_obj[0],small_rect_obj[2]);	
	composed_array[4]=ComposedShape(tri_obj[0],small_tri_obj[1]);	

/*it's for users choise*/
	choose[0][0]='r',second_choose[0][0]='r';
	choose[1][0]='r',second_choose[1][0]='t';             
	choose[2][0]='r',second_choose[2][0]='c';
	choose[3][0]='t',second_choose[3][0]='r';				
	choose[4][0]='t',second_choose[4][0]='t';				
	choose[5][0]='t',second_choose[5][0]='c';				
	choose[6][0]='c',second_choose[6][0]='r';
	choose[7][0]='c',second_choose[7][0]='t';
	choose[8][0]='c',second_choose[8][0]='c';
/*it's for nine situation different file name*/	
	file[0]="result.svg";										
	file[1]="result1.svg";
	file[2]="result2.svg";	
	file[3]="result3.svg";
	file[4]="result4.svg";
	file[5]="result5.svg";
	file[6]="result6.svg";
	file[7]="result7.svg";
	file[8]="result8.svg";
	cout<<"I try postfix and prefix operator to see my unnamed space functions\n";
	cout<<"Shape x:coordinate:  "<<small_circ_obj[2].getPosition_x()<<"  Shape y:coordinate:"<<small_circ_obj[2].getPosition_y()<<endl;
	small_circ_obj[2]++;
	cout<<"New shape x:coordinate:  "<<small_circ_obj[2].getPosition_x()<<"  Nex shape y:coordinate:"<<small_circ_obj[2].getPosition_y()<<endl<<endl;
	while(i<9){		/*all of the about all situation print*/
	  	ofstream myfile;
	  	myfile.open(file[i]);	/*I open the file which get the main for many result output file */
	    myfile <<"<svg version=\"1.1\"\n\t\t"<<"baseProfile=\"full\"\n\t\t"
	    <<"xmlns=\"http://www.w3.org/2000/svg\">\n\n\t"  ;		/*it's for file svg format*/			
		if(choose[i][0]=='R' || choose[i][0]=='r'){
			if(second_choose[i][0]=='R' || second_choose[i][0]=='r'){
				myfile<<rect_obj[0];	/*rect << overload*/	
				composed_array[0].setMainchar(choose[i][0]);
				composed_array[0].setSmallchar(second_choose[i][0]);
				composed_array[0].optimalfit();
				myfile<<composed_array[0];
							
			}
			if(second_choose[i][0]=='T' || second_choose[i][0]=='t'){
				myfile<<rect_obj[0];	/*rect << overload*/	
				composed_array[1].setMainchar(choose[i][0]);
				composed_array[1].setSmallchar(second_choose[i][0]);
				composed_array[1].optimalfit();
				myfile<<composed_array[1];	
			}
			if(second_choose[i][0]=='C' || second_choose[i][0]=='c'){
				myfile<<rect_obj[0];	/*rect << overload*/	
				composed_array[2].setMainchar(choose[i][0]);
				composed_array[2].setSmallchar(second_choose[i][0]);
				composed_array[2].optimalfit();
				myfile<<composed_array[2];	
			}
			r++;
		}
		
  		else if(choose[i][0]=='T' || choose[i][0]=='t'){
			if(second_choose[i][0]=='R' || second_choose[i][0]=='r'){	
				myfile<<tri_obj[0];	/*rect << overload*/	
				composed_array[3].setMainchar(choose[i][0]);
				composed_array[3].setSmallchar(second_choose[i][0]);
				composed_array[3].optimalfit();
				myfile<<composed_array[3];
			}
			else if(second_choose[i][0]=='T' || second_choose[i][0]=='t'){		
				myfile<<tri_obj[0];	/*rect << overload*/	
				composed_array[4].setMainchar(choose[i][0]);
				composed_array[4].setSmallchar(second_choose[i][0]);
				composed_array[4].optimalfit();
				myfile<<composed_array[4];		
			}
			else if(second_choose[i][0]=='C' || second_choose[i][0]=='c'){
				myfile<<tri_obj[0];		
				myfile<<p_array[0];		
	    		myfile<<"	</svg>"	;	/*finish of the svg format I wrote in a file*/

			}
			t++;		  	
   		} 

		else if(choose[i][0]=='C' || choose[i][0]=='c'){	
			if(second_choose[i][0]=='R' || second_choose[i][0]=='r'){
				myfile<<rect_obj[0];	/*circle << overload*/
				myfile<<p_array[1];	
				myfile<<"	</svg>"	;	/*finish of the svg format I wrote in a file*/				
			}
			if(second_choose[i][0]=='T' || second_choose[i][0]=='t'){
				myfile<<rect_obj[0];	/*circle << overload*/
				myfile<<p_array[2];	
				myfile<<"	</svg>"	;	/*finish of the svg format I wrote in a file*/	
			}
			if(second_choose[i][0]=='C' || second_choose[i][0]=='c'){		
				myfile<<rect_obj[0];	/*circle << overload*/
				myfile<<p_array[4];	
				myfile<<"	</svg>"	;	/*finish of the svg format I wrote in a file*/				
			}
			c++;    			
		}		
		myfile.close(); 
		i++; 				
	}
	  	ofstream myfile;
		myfile.open("result9.svg");
	    myfile <<"<svg version=\"1.1\"\n\t\t"<<"baseProfile=\"full\"\n\t\t"
	    <<"xmlns=\"http://www.w3.org/2000/svg\">\n\n\t"  ;		//it's for file svg format	
	    myfile<<circ_obj[0];
		myfile<<p_array[1];	
	    myfile	<<"	</svg>"	;	//finish of the svg format I wrote in a file
		myfile.close();
		if(p_array[0]==p_array[1])
			cout<<"Polygon0 objesi Polygon1 objesine eşit \n\n";	
		if(p_array[1]!=p_array[2])
			cout<<"Polygon1 objesi Polygon2 objesine eşit değil \n\n";		

		Polygon result=p_array[0]+p_array[3];
		cout<<"1. polygonun toplamının x \n:"<<p_array[0];
		cout<<"2. polygonun toplamının x : \n"<<p_array[3];
		cout<<"2 polygonun toplamının x : \n"<<result;	
		cout<<"\nDosyaya basarken koordinatlarımın sırası 0 2 3 1 şeklinde tanımlayarak istedigim düzeni olusturdum bu yuzden koordinatlarin yerleri ekrana ve dosyaya bastirma islemlerinde normalden farklı ama + islemi calısıyor\n";
	//My polyline objects yo write in a file with svg format

	Polyline temp_poly;	//I use polyline class to access polygone functions
	temp_poly.poly_obje=Polygon(small_rect_obj[0]);
	myfile.open("result10.svg");	
    myfile <<"<svg version=\"1.1\"\n\t\t"<<"baseProfile=\"full\"\n\t\t"
    <<"xmlns=\"http://www.w3.org/2000/svg\">\n\n\t"  ;		//it's for file svg format	
    myfile<<circ_obj[0];
	myfile<<temp_poly;	
    myfile	<<"	</svg>"	;	//finish of the svg format I wrote in a file	
	myfile.close();

	cout<<"\n I use polyline class to access polygone functions.  My polyline obje's points :"<<temp_poly.poly_obje;
	cout<<"\n I access with my polyline class obje is polygon and I can use all functions polygon class \n";	
	temp_poly.poly_obje=Polygon(small_tri_obj[0]);
	myfile.open("result11.svg");	
    myfile <<"<svg version=\"1.1\"\n\t\t"<<"baseProfile=\"full\"\n\t\t"
    <<"xmlns=\"http://www.w3.org/2000/svg\">\n\n\t"  ;		//it's for file svg format	
    myfile<<circ_obj[0];
	myfile<<temp_poly;	
    myfile	<<"	</svg>"	;	//finish of the svg format I wrote in a file	
	myfile.close();

	temp_poly.poly_obje=Polygon(small_circ_obj[0]);
	myfile.open("result12.svg");	
    myfile <<"<svg version=\"1.1\"\n\t\t"<<"baseProfile=\"full\"\n\t\t"
    <<"xmlns=\"http://www.w3.org/2000/svg\">\n\n\t"  ;		//it's for file svg format	
    myfile<<rect_obj[0];
	myfile<<temp_poly;	
    myfile	<<"	</svg>"	;	//finish of the svg format I wrote in a file	
	myfile.close();		
	return 0;	

}