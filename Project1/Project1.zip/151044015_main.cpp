#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
using namespace std;

enum class shape{
	rectangle,
	triangle,
	circle 
}main_shape,small_shape;

void rectandtri_f(double &width,double &height);
void circle_f(double &radius);
void triinrect(double &side,double &width,double &height,ofstream *myfile );
void circinrect(double &radius,double &width,double &height,ofstream *myfile);
void rectinrect(int &width,int &height,ofstream *myfile);
void rectintri(double &side,double &small_width,double &small_height,ofstream *myfile);
void triincirc(double &side,double &radius,ofstream *myfile);
void triinttri(double &side,double &s_side,ofstream *myfile);
void rectincirc(double &radius,double &width,double &height,ofstream *myfile);
void circintri(double &radius,double &side,ofstream *myfile);
void circincirc(double &radius,double &s_radius,ofstream *myfile);

void choose_f();

int main(){
	choose_f();	
	return 0;	
}

void choose_f(){	/*it is my main function */
	char choose,second_choose;
	double width,height;
	double radius,side,second_side,s_radius;
	int widthh,heightt;
	cout<<"Please enter the main container shape (R, C, T)";
	cin>>choose;					/*I get an user's choise*/
  	ofstream myfile;				/*I initiliza file variabe for writing*/
  	myfile.open("test.svg");
    myfile <<"<svg version=\"1.1\"\n\t\t"<<"baseProfile=\"full\"\n\t\t"
    <<"xmlns=\"http://www.w3.org/2000/svg\">\n\n\t"  ;		/*it's for file svg format*/
	if(choose=='R' || choose=='r'){
		main_shape=shape::rectangle;
		rectandtri_f(width,height);		
    	myfile <<"<rect width="<<"\""<<width<<"\""<<" height="<<"\""<<height<<"\"" <<" fill=\"red\" />\n\t";
		cout<<"Please enter the small shape (R, C, T)";
		cin>>second_choose;    	
			if(second_choose=='R' || second_choose=='r'){
				small_shape=shape::rectangle;
			}
			else if(second_choose=='T' || second_choose=='t'){
				small_shape=shape::triangle;			
			}
			else if(second_choose=='C' || second_choose=='c'){
				small_shape=shape::circle;						
			}		
   		}
   		
   		else if(choose=='T' || choose=='t'){
			main_shape=shape::triangle;
   			cout<<"Please enter the side";
   			cin>>side;
			cout<<"Please enter the small shape (R, C, T)";
			cin>>second_choose;   						
	   	  myfile<<"<polygon points="<<"\"0 "<<(side*sqrt(3))/2<<" "<<side/2<<" 0 "<<side<<" "<<(side*sqrt(3))/2<<"\""<<   // 3 noktanın x ve y koordinatlarını gireceğiz
		  " stroke="<<"\"red\""<< " fill="<<"\"transparent\""<< " stroke-width="<<"\"0.3\""<<"/>\n";
			if(second_choose=='R' || second_choose=='r'){
				small_shape=shape::rectangle;			
			}
			else if(second_choose=='T' || second_choose=='t'){
				small_shape=shape::triangle;						
			}
			else if(second_choose=='C' || second_choose=='c'){
				small_shape=shape::circle;								
			}		  	
   		} 
	
	else if(choose=='C' || choose=='c'){
		main_shape=shape::circle;	
		cout<<"Please enter the radius";
		cin>>radius;	
    	myfile	<<"<circle cx=\""<<radius<<"\""<<" cy=\""<<radius<<"\""<<" r=\""<<radius<<"\"" <<" fill=\"red\" />\n\t"  ; 
		cout<<"Please enter the small shape (R, C, T)";
		cin>>second_choose;     	
    	if(second_choose=='T' || second_choose=='t'){
			small_shape=shape::triangle;						    					
		}
    	if(second_choose=='R' || second_choose=='r'){
   			small_shape=shape::rectangle;			 	   			   		
    	}
    	if(second_choose=='C' || second_choose=='c'){
			small_shape=shape::circle;						    						
		}    			
	}
	if(	(main_shape==shape::rectangle) && (small_shape==shape::rectangle)	){
		widthh=width;
		heightt=height;
		rectinrect(widthh,heightt,&myfile);		
	}
	else if((main_shape==shape::rectangle) && (small_shape==shape::triangle)){
		cout<<"Please enter the side";
		cin>>side;
		triinrect(side,width,height,&myfile);	
	}
	else if((main_shape==shape::rectangle) && (small_shape==shape::circle)){
		cout<<"Please enter the radius";	
		cin>>radius;
		circinrect(radius,width,height,&myfile);	
	}
	else if((main_shape==shape::triangle) && (small_shape==shape::rectangle)){
		rectintri(side,width,height,&myfile);	
	}
	else if((main_shape==shape::triangle) && (small_shape==shape::triangle)){
		cin>>second_side;
		triinttri(side,second_side,&myfile);	
	}
	else if((main_shape==shape::triangle) && (small_shape==shape::circle)){
		cout<<"Please enter the radius";	
		cin>>radius;
		circintri(side,radius,&myfile);		
	}
	else if((main_shape==shape::circle) && (small_shape==shape::rectangle)){
		cout<<"Please enter the width";	    	
   		cin>>width; 
		cout<<"Please enter the height";	    	
   		cin>>height; 		   	
   		rectincirc(radius,width,height,&myfile);
	}
	else if((main_shape==shape::circle) && (small_shape==shape::triangle)){
		cout<<"Please enter the side";	 	
   		cin>>second_side; 	
   		triincirc(radius,second_side,&myfile) ;		   			
	}
	else if((main_shape==shape::circle) && (small_shape==shape::circle)){
		cout<<"Please enter the side";	    	
   		cin>>s_radius; 	
   		circincirc(radius,s_radius,&myfile) ;	
	}
    myfile	<<"	</svg>"	;
	myfile.close();
}

void rectandtri_f(double &width,double &height){
	cout<<"Please enter the width";
	cin>>width;
	cout<<"Please enter the height";
	cin>>height;
}

void circle_f(	double &radius){
	cout<<"Please enter the radius";

}

void triinrect(double &side,double &width,double &height,ofstream *myfile){	/*I replace triangle in rectangle*/
	int i,j,h_1,w_1;
	int x=0, y=0,num_triangle=0;
	double triangle_area,rect_area;
	h_1=height/(side/2*sqrt(3));	/*I calculate num of triangle for every column*/
	w_1=width/side;		/*I calculate num of triangle for every line*/
	for(i=0;i<h_1;i++){
		for(j=0;j<w_1;j++){
			*myfile<< "<polygon points="<<"\""<<x<<","<<y+(side/2)*sqrt(3)<<","<<x+side<<","<<y+(side/2)*sqrt(3)<<","<<x+side/2<<","<<y<<"\""<<" stroke="<< "\"green\""<<" fill="<<"\"transparent\""<< " stroke-width="<<"\"1\""<<" />\n";
			num_triangle+=1;	/*count of triangle*/
			x+=side;
		}
		y+=side/2*sqrt(3);
		j=0;
		x=0;
	}
			/*I write in file for reversing triangle in rectangle*/
	h_1=height/(side/2*sqrt(3));
	w_1=(width-side/2)/side;
	x=side/2;
	y=0;
	for(i=0;i<h_1;i++){
		for(j=0;j<w_1;j++){
			*myfile<< "<polygon points="<<"\""<<x<<","<<y<<","<<x+side<<","<<y<<","<<x+side/2<<","<<y+(side/2)*sqrt(3)<<"\""<<" stroke="<< "\"green\""<<" fill="<<"\"transparent\""<< " stroke-width="<<"\"1\""<<" />\n";
			x+=side;
			num_triangle+=1;	/*count of triangle*/
		}
		y+=side/2*sqrt(3);
		j=0;
		x=side/2;
	}
	rect_area=width*height;		/*area of rectangle*/
	triangle_area=num_triangle*((side*side)*sqrt(3)/4);		/*area of all of the triangle in rectangle*/
	cout<<"I can fit at most "<< num_triangle<<" small shapes into the main container. The empty area (red) in container is :"<<rect_area-triangle_area<<endl;
}

void circinrect(double &radius,double &width,double &height,ofstream *myfile){	/*I replace circle in rectangle*/   //WİDTH HEGİHT 600 RADİUS 80 HATALİ	
	int y1_a,y2_a,x_k,y_k,sayac=0,num_circle=0,rect_area,circ_area;
	y1_a=height/(4*radius);					/*it's for first type sequence*/
	x_k=radius;
	y_k=radius;
	y2_a=height/(2*radius+(radius*sqrt(3)));	/*it's for second type sequence*/
	if(y1_a<y2_a && y2_a<width && y2_a<height){
		while(y_k<=height){
	  		*myfile<<"<circle cx="<<"\""<<x_k<<"\""<<" cy="<<"\""<<y_k<<"\""<< " r="<<"\""<<radius<<"\"" <<" stroke="<<"\"green\""<<" fill="<<"\"transparent\""<<" stroke-width="<<"\"0\""<<" />\n";	
			num_circle+=1;		/*count of circle*/
			x_k+=2*radius;
			if(x_k+radius>width){
				sayac++;	
				if(sayac%2==1)
					x_k=2*radius;
				else
					x_k=radius;
				y_k+=(radius*sqrt(3));
			}
		}
	}
	else{
		while(y_k+radius<=height){
	  		*myfile<<"<circle cx="<<"\""<<x_k<<"\""<<" cy="<<"\""<<y_k<<"\""<< " r="<<"\""<<radius<<"\"" <<" stroke="<<"\"green\""<<" fill="<<"\"transparent\""<<" stroke-width="<<"\"1\""<<" />\n";	
			num_circle+=1;		/*count of circle*/
			x_k+=2*radius;
			if(x_k+radius>width){
				x_k=radius;
				y_k+=2*radius;
			}
		}
	}
	rect_area=width*height;
	circ_area=num_circle*(radius*radius*sqrt(3));
	cout<<"I can fit at most "<< num_circle<<" small shapes into the main container. The empty area (red) in container is :"<<rect_area-circ_area<<endl;
}

void rectinrect(int &width,int &height,ofstream *myfile){		/*I replace rectangle in rectangle*/
	int small_width,small_height,num_width,num_height,res1_x,res1_y,res1,i,j,w_1,h_1,x,y,temp1,temp2,control,rect_area,s_rect_area,num_rectengle=0;
	res1=0,x=0,y=0;
	cout<<"Please enter the width";
	cin>>small_width;
	cout<<"Please enter the height";
	cin>>small_height;		/*I get a value of small rectangle and I calculate for 2 type max put type*/
	num_width=width/small_width;
	num_height=height/small_height;
	if((width%(small_width))>=small_height){	/*it's for horizontal small rectangle*/
		res1_x=small_height/(width%small_width);
		res1_y=height/small_height;
		res1=res1_x*res1_y;
		control=0;
	}
	else if(height%(small_height)>=small_width){		/*it's for vertical small rectangle*/
		res1_x=small_width/(height%small_height);
		res1_y=width/small_width;
		res1=res1_x*res1_y;
		control=1;
	}
	temp1=num_width*num_height+res1;	/*This is for residual space.It calculates more space than width of height*/
	num_width=width/small_height;
	num_height=height/small_width;	
	temp2=num_width*num_height;		/*This is for except for residual space.It calculates smaller space than width of height*/
	if(temp1>temp2){	
		w_1=width/small_width;
		h_1=height/small_height;
		for(i=0;i<w_1;i++){
			for(j=0;j<h_1;j++){
	    		*myfile <<"<rect width="<<"\""<<small_width<<"\""<<" height="<<"\""<<small_height<<"\""<<" x="<<"\""<<x<<"\""<<" y="<<"\""<<y<<"\""<<" stroke="<< "\"green\""<<" fill=\"transparent\""<< " stroke-width="<<"\"1\""<<" />\n\t";
	    		num_rectengle+=1;		/*value of rectengle which drawed for type 1*/
	    		y+=small_height;			
			}
			y=0;
			x+=small_width;
		}
		
		if(control==0 && res1!=0){	/*this condition for horizontal and more space than width of height*/
			while(x<=width){
				*myfile <<"<rect width="<<"\""<<small_height<<"\""<<" height="<<"\""<<small_width<<"\""<<" x="<<"\""<<x<<"\""<<" y="<<"\""<<y<<"\""<<" stroke="<< "\"green\""<<" fill=\"transparent\""<< " stroke-width="<<"\"1\""<<" />\n\t";
		    	num_rectengle+=1;			
				x+=small_height;		
			}			
		}
	
		else if(control==1 && res1!=0) {  /*this condition for vertical and more space than width of height*/
			y=(h_1)*small_height;
			x=0;
			while(y<=height && x+small_height<=width){
	    		*myfile <<"<rect width="<<"\""<<small_height<<"\""<<" height="<<"\""<<small_width<<"\""<<" x="<<"\""<<x<<"\""<<" y="<<"\""<<y<<"\""<<" stroke="<< "\"green\""<<" fill=\"transparent\""<< " stroke-width="<<"\"1\""<<" />\n\t";
	    		num_rectengle+=1;	/*value of rectengle which drawed for type 2*/
	    		x+=small_height;
			}
		}
	}
	else{	/*This condition for except for residual space.It calculates smaller space than width of height*/
		w_1=width/small_height;
		h_1=height/small_width;
		for(i=0;i<h_1;i++){
			for(j=0;j<w_1;j++){
	    		*myfile <<"<rect width="<<"\""<<small_height<<"\""<<" height="<<"\""<<small_width<<"\""<<" x="<<"\""<<x<<"\""<<" y="<<"\""<<y<<"\""<<" stroke="<< "\"green\""<<" fill=\"transparent\""<< " stroke-width="<<"\"1\""<<" />\n\t";
		    	num_rectengle+=1;    /*value of rectengle which drawed */		
	    		x+=small_height;			
			}
			x=0;
			y+=small_width;
		}
	}
	rect_area=width*height;		/*area of rectangle*/
	s_rect_area=(small_width*small_height)*num_rectengle;	/*area of small rectangle*/
	cout<<"I can fit at most "<< num_rectengle<<" small shapes into the main container. The empty area (red) in container is :"<<rect_area-s_rect_area<<endl;

}

void rectincirc(double &radius,double &width,double &height,ofstream *myfile){		/*I replace rectangle in circle*/
	int x=0,y=0,flag=0,num_rectangle=0;
	double rect_area,circ_area;
	
		while(y<=2*radius && x>=0){
			while(x<=2*radius){
	/*I checked point to point.I used this condition for every point of rectangle in circle or not*/
				if((((x-radius+width))*((x-radius+width))+((y-radius)*(y-radius))<=(radius*radius)) && ((x-radius)*(x-radius)+((y-radius+height)*(y-radius+height))<=(radius*radius)) && (x-radius)*(x-radius)+(y-radius)*(y-radius)<=(radius*radius) && ((x-radius+width)*(x-radius+width)+((y-radius+height))*(y-radius+height)<=(radius*radius)) ){
				   	*myfile <<"<rect width="<<"\""<<width<<"\""<<" height="<<"\""<<height<<"\""<<" x="<<"\""<<x<<"\""<<" y="<<"\""<<y<<"\""<<" stroke="<< "\"green\""<<" fill=\"transparent\""<< " stroke-width="<<"\"1\""<<" />\n\t";
				   	num_rectangle+=1;
					x+=width;		
					flag=1;
				}
				else{
				x++;
				}				
			}
			x=0;
			if(flag==0){
				y++;
			}	
			else{
				y+=height;}
			flag=0;
		}
	rect_area=(width*height)*num_rectangle;		/*area of rectangle*/
	circ_area=(radius*radius*3.14);				/*area of circle*/
	cout<<"I can fit at most "<< num_rectangle<<" small shapes into the main container. The empty area (red) in container is :"<<circ_area-rect_area<<endl;

}

void triincirc(double &radius,double &side,ofstream *myfile){		/*I replace triangle in circle*/
	int i;
	double x,y,circ_area,triangle_area,num_triangle=0;
	y=0;
	x=0;
	while(y<=2*radius && x>=0){
			for(i=0;i<2*radius;i++){
				/*I checked point to point.I used this condition for every point of triangle in circle or not*/
				if( (((x-radius)*(x-radius))+((y-radius)*(y-radius))<=(radius*radius)) && (((x+side/2)-radius)*(x+(side/2)-radius)+(y-((side/2)*sqrt(3))-radius)*(y-((side/2)*sqrt(3))-radius)<=(radius*radius)) && ((x+side-radius)*(x+side-radius)+(y-radius)*(y-radius)<=(radius*radius))  ){
				*myfile<< "<polygon points="<<"\""<<x<<","<<y<<","<<x+side<<","<<y<<","<<x+side/2<<","<<y-(side/2)*sqrt(3)<<"\""<<" stroke="<< "\"red\""<<" fill="<<"\"green\""<< " stroke-width="<<"\"1\""<<" />\n";
				num_triangle+=1;  	/*value of triangle*/
				x+=side;
				}
				else
				x++;				
			}

			x=0;
			y+=(side*sqrt(3))/2;			
		}		
	
	x=0;
	y=0;
	while(y<=2*radius && x>=0){
			for(i=0;i<2*radius;i++){
				/*I checked point to point.I used this condition for every point of reversing triangle in circle or not*/	
				if((((x-radius)*(x-radius))+((y-radius)*(y-radius))<=(radius*radius)) && (((x-radius+(3*side)/2)*(x+((3*side)/2)-radius))+((y-(side/2)*sqrt(3)-radius)*(y-(side/2)*sqrt(3)-radius))<=(radius*radius)) && (((x+side/2)-radius)*(x+(side/2)-radius)+(y-((side/2)*sqrt(3))-radius)*(y-((side/2)*sqrt(3))-radius)<=(radius*radius)) && ((x+side-radius)*(x+side-radius)+(y-radius)*(y-radius)<=(radius*radius)) ){
				
				*myfile<< "<polygon points="<<"\""<<x+side/2<<","<<y-(side/2)*sqrt(3)<<","<<x+side<<","<<y<<","<<x+(3*side)/2<<","<<y-(side/2)*sqrt(3)<<"\""<<" stroke="<< "\"red\""<<" fill="<<"\"green\""<< " stroke-width="<<"\"1\""<<" />\n";
				num_triangle+=1;		/*value of reversing triangle*/		
				x+=side;
				}
				else{			
				x++;
				}								
			}
			x=0;
			y+=(side*sqrt(3))/2;
	}
	circ_area=(radius*radius*3.14);		/*area of circle*/
	triangle_area=((side*side*sqrt(3))/4)*num_triangle;		/*area of triangle*/
	cout<<"I can fit at most "<<num_triangle<<" small shapes into the main container. The empty area (red) in container is :"<<circ_area-triangle_area<<endl;	
}

void circincirc(double &radius,double &s_radius,ofstream *myfile){		/*I replace circle in circle*/
	double x=0,y=0,flag=0,num_circ=0,circ_area,s_circ_area;
	while(y<2*radius && x<2*radius){
		while(x<=2*radius){	
				/*I checked point to point.I used this condition for some points of circle, in circle or not*/	
			if( 
			(((x-s_radius)-radius)*((x-s_radius)-radius)+((y-s_radius)-radius)*((y-s_radius)-radius)<=(radius*radius)) &&
			(((x-s_radius)-radius)*((x-s_radius)-radius)+((y+s_radius)-radius)*((y+s_radius)-radius)<=(radius*radius)) &&
			(((x+s_radius)-radius)*((x+s_radius)-radius)+((y+s_radius)-radius)*((y+s_radius)-radius)<=(radius*radius)) &&
			(((x+s_radius)-radius)*((x+s_radius)-radius)+((y-s_radius)-radius)*((y-s_radius)-radius)<=(radius*radius)) ){
				*myfile<<"<circle cx="<<"\""<<x<<"\""<<" cy="<<"\""<<y<<"\""<< " r="<<"\""<<s_radius<<"\"" <<" stroke="<<"\"transparent\""<<" fill="<<"\"green\""<<" stroke-width="<<"\"0\""<<" />\n";				num_circ+=1;	/*value of drawing circle for every loop*/
				flag=1;
				x+=2*s_radius;	
			}
			else{
			x++;
			}
		}	
		if(x>=2*radius){
			y++;
			x=0;
		}
		if(flag==1){
			y+=2*s_radius;
		}
		else{
			y++;
		}
		flag=0;		
		x=0;
	}
	circ_area=(radius*radius*3.14)*num_circ;		/*area of circle*/
	s_circ_area=(s_radius*s_radius*3.14)/4;			/*area of small circle*/
	cout<<"I can fit at most "<<num_circ<<" small shapes into the main container. The empty area (red) in container is :"<<circ_area-s_circ_area<<endl;
}

void rectintri(double &side,double &small_width,double &small_height,ofstream *myfile){		/*I replace rectangle in triangle*/
	double temp;
	double x=0,y=0,num_rectangle=0,rectangle_area,triangle_area;
	cout<<"Please enter the width";
	cin>>small_width;
	cout<<"Please enter the height";
	cin>>small_height;		/*I take value of rectangle width and height*/
	x=small_height/sqrt(3);	/*start point for x coorcinate*/
	temp=x;
	y=(side/2.0)*sqrt(3.0)-small_height;	/*start point for y coorcinate*/
	triangle_area=((side*side*sqrt(3))/4);		/*area of triangle*/
	side-=(small_height)/sqrt(3.0);	
	while(x<=side && y>0){
		if(x+small_width>=side){
	    	y-=small_height;
	   		x=small_height/sqrt(3.0)+temp;
	    	temp=x;
	    	side-=(small_height)/sqrt(3.0);		/*calculate for each line max width to end*/
	    }
	    else{	
			num_rectangle+=1;		/*value of rectangle for each drawed */
			*myfile <<"<rect width="<<"\""<<small_width<<"\""<<" height="<<"\""<<small_height<<"\""<<" x="<<"\""<<x<<"\""<<" y="<<"\""<<y<<"\""<<" stroke="<< "\"green\""<<" fill=\"green\""<< " stroke-width="<<"\"0.1\""<<" />\n\t";	
			x+=small_width;
		}
	}
	rectangle_area=(small_width*small_height)*num_rectangle;		/*area of rectangle*/
	cout<<"I can fit at most "<<num_rectangle<<" small shapes into the main container. The empty area (red) in container is :"<<triangle_area-rectangle_area<<endl;
}

void circintri(double &side,double &radius,ofstream *myfile){		/*I replace circle in triangle*/
	double x_k,y_k,temp,num_circle=0;
	double triangle_area,circle_area;
	x_k=radius*sqrt(3);						/*start point for radius center of x coordinate*/
	temp=x_k;
	y_k=((side*sqrt(3))/2)-radius;			/*start point for radius center of y coordinate*/
	triangle_area=(side*side*sqrt(3))/4;	/*area of triangle*/
	side=side-radius/sqrt(3);				/*circle triangle calculating variable max size for width */
	while(x_k<=side && y_k>=0){
		if(x_k+radius<side){
			*myfile<<"<circle cx="<<"\""<<x_k<<"\""<<" cy="<<"\""<<y_k<<"\""<< " r="<<"\""<<radius<<"\"" <<" stroke="<<"\"transparent\""<<" fill="<<"\"green\""<<" stroke-width="<<"\"0\""<<" />\n";
			num_circle+=1;					/*value of circle for each drawed */
			x_k+=2*radius;	
		}		
		if(x_k+radius>=side){
			x_k=temp+radius;
			temp=x_k;
			y_k-=radius*sqrt(3);
			side-=radius;
		}	
	}
	circle_area=(radius*radius*3.14)*num_circle;		//area of circle
	cout<<"I can fit at most "<<num_circle<<" small shapes into the main container. The empty area (red) in container is :"<<triangle_area-circle_area<<endl;
}

void triinttri(double &side,double &s_side,ofstream *myfile){		/*I replace triangle in triangle*/
	double x=0, y=0,temp=0,temp2=side,num_triangle=0,triangle_area,s_triangle_area;
	y=(side/2)*sqrt(3);						/*start point for y coordinate*/
	triangle_area=(side*side*sqrt(3))/4;	/*main shape area*/
	while(x<=side && y-(s_side/2)>=0){		
		if(x+s_side>side){
			side-=s_side/2;
			x=s_side/2+temp;
			temp=x;
			y-=s_side/2*sqrt(3);
		}
		else{	
			*myfile<< "<polygon points="<<"\""<<x<<","<<y<<","<<x+s_side<<","<<y<<","<<x+s_side/2<<","<<y-(s_side/2)*sqrt(3)<<"\""<<" stroke="<< "\"red\""<<" fill="<<"\"green\""<< " stroke-width="<<"\"0.4\""<<" />\n";
		num_triangle+=1;	/*value of triangle for each drawed */
		x+=s_side;
		}		
	}
	side=temp2;
	temp=s_side/2;
	//reversing small triangle writing code
	y=(side/2)*sqrt(3);
	x=s_side/2;
	side=side-s_side/2;
	while(x<=side && y-(s_side/2)>=0){
		if(x+s_side>side){
			side-=s_side/2;
			x=s_side/2+temp;
			temp=x;
			y-=s_side/2*sqrt(3);
		}
		else{	
			*myfile<< "<polygon points="<<"\""<<x<<","<<y-(s_side/2)*sqrt(3)<<","<<x+s_side<<","<<y-(s_side/2)*sqrt(3)<<","<<x+s_side/2<<","<<y<<"\""<<" stroke="<< "\"red\""<<" fill="<<"\"green\""<< " stroke-width="<<"\"0.4\""<<" />\n";
		num_triangle+=1;	/*value of triangle for each drawed */
		x+=s_side;
		}	
		
	}
	s_triangle_area=((s_side*s_side*sqrt(3))/4)*num_triangle;		//small triangle area
	cout<<"I can fit at most "<<num_triangle<<" small shapes into the main container. The empty area (red) in container is :"<<triangle_area-s_triangle_area<<endl;
}





