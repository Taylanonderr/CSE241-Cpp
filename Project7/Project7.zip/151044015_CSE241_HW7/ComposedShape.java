import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

import javax.swing.JPanel;



@SuppressWarnings("serial")
public class ComposedShape extends JPanel implements Shape{

	/**
	 * Rectangle inner object reference
	 */
	private Rectangle small_rectangle;
	/**
	 * Triangle container object reference
	 */
	private Triangle triang;
	/**
	 * Triangle inner object reference
	 */
	private Triangle small_triangle;	
	/**
	 * Rectangle container object reference
	 */
	private Rectangle rectang;
	/**
	 * Circle container object reference
	 */
	private Circle circ;
	/**
	 * Circle inner object reference
	 */
	private Circle small_circle;	
	/**
	 * Choise container shape
	 */
	private char main_char;
	/**
	 * Choise inner shape
	 */
	private char small_char;
	/**
	 * Keeps an array of Shape references for the shape elements.
	 */
	private Shape[]  shape_array;
	/**
	 * Composed Shape area
	 */
	private double area_shape;
	
	/**
	 * Optimalfit helper function for Rectangle-Rectangle shapes draw
	 */
	private void optimalfit_helper1(){
		int num_width,num_height,res1_x,res1_y,res1,i,j,w_1,h_1,x,y,temp1,temp2,control=0,rect_area,s_rect_area,num_rectengle=0;
		int small_width,small_height,width,height;
		ArrayList<Rectangle> shape_temp =new ArrayList<Rectangle>();
		//List<String> words = new ArrayList<String>();		
		res1=0;
		x=0;
		y=0;
		
		num_width=(rectang.getWidth())/(small_rectangle.getWidth());	/*get value in class obje and assign for any variable*/
		num_height=(rectang.getHeight())/(small_rectangle.getHeight());		/*get value in class obje and assign for any variable*/
		width=rectang.getWidth();	/*get value in class obje and assign for any variable*/
		height=rectang.getHeight();		/*get value in class obje and assign for any variable*/
		small_width=small_rectangle.getWidth();		/*get value in class obje and assign for any variable*/
		small_height=small_rectangle.getHeight();		/*get value in class obje and assign for any variable*/			
		if(((width)%(small_width))>=small_height){	/*it's for horizontal small rectangle*/
				if(width%small_width!=0){			
					res1_x=small_height/(width%small_width);
					res1_y=height/small_height;
					res1=res1_x*res1_y;
					control=0;
			}
		}
		else if(height%(small_height)>=small_width){		/*it's for vertical small rectangle*/
				if(height%small_height!=0 ){			
					res1_x=small_width/(height%small_height);
					res1_y=width/small_width;
					res1=res1_x*res1_y;
					control=1;
			}
		}

		temp1=num_width*num_height+res1;	/*This is for residual space.It calculates more space than width of height*/
		num_width=width/small_height;
		num_height=height/small_width;	
		temp2=num_width*num_height;		/*This is for except for residual space.It calculates smaller space than width of height*/
		if(temp1>temp2){	
			w_1=width/small_width;
			h_1=height/small_height;
			for(i=0;i<w_1;i++){
				for(j=0;j<h_1;j++){
					Rectangle small_rectangle=new Rectangle();
					small_rectangle.setPosition_x(x);	/*I assigned x coordinate in small_shape class*/
					small_rectangle.setPosition_y(y);	/*I assigned x coordinate in small_shape class*/
					small_rectangle.setWidth(small_width);	/*I assigned width in small_shape class*/
					small_rectangle.setHeight(small_height);	/*I assigned height in small_shape class*/
					shape_temp.add(small_rectangle);
					//Shape shape_obje=new Rectangle(small_rectangle);
					//shape_array[num_rectengle]=shape_obje;
					num_rectengle+=1;		/*value of rectengle which drawed for type 1*/
					y+=small_height;			
				}
				y=0;
				x+=small_width;
			}
			if(control==0 && res1!=0){	/*this condition for horizontal and more space than width of height*/
				while(x<=width){
					Rectangle small_rectangle=new Rectangle();					
					small_rectangle.setPosition_x(x);	/*I assigned x coordinate in small_shape class*/
					small_rectangle.setPosition_y(y);	/*I assigned x coordinate in small_shape class*/
					small_rectangle.setWidth(small_width);	/*I assigned width in small_shape class*/
					small_rectangle.setHeight(small_height);	/*I assigned height in small_shape class*/
					shape_temp.add(small_rectangle);

					num_rectengle+=1;			
					x+=small_height;		
				}

			}
	
			else if(control==1 && res1!=0) {  /*this condition for vertical and more space than width of height*/
				y=(h_1)*small_height;
				x=0;
				while(y<=height && x+small_height<=width){
					Rectangle small_rectangle=new Rectangle();				
					small_rectangle.setPosition_x(x);
					small_rectangle.setPosition_y(y);
					small_rectangle.setWidth(small_width);
					small_rectangle.setHeight(small_height);
					shape_temp.add(small_rectangle);

					num_rectengle+=1;	/*value of rectengle which drawed for type 2*/
					x+=small_height;
				}

			}
		}
		else{	/*This condition for except for residual space.It calculates smaller space than width of height*/
			w_1=width/small_height;
			h_1=height/small_width;
			for(i=0;i<h_1;i++){
				x=0;				
				for(j=0;j<w_1;j++){
					Rectangle small_rectangle=new Rectangle();					
					small_rectangle.setPosition_x(x);
					small_rectangle.setPosition_y(y);
					small_rectangle.setWidth(small_height);
					small_rectangle.setHeight(small_width);
					shape_temp.add(small_rectangle);
					num_rectengle+=1;    /*value of rectengle which drawed */		
					x+=small_height;			
			
				}
				y+=small_width;
			}
			if(	width%small_height>=small_width){
				i=width%small_height;
				y=0;
				while(i>=small_width && y<height){
					if(y+small_height>=height){
						y=0;
						x+=small_width;						
						i-=small_height;
					}
					else{
						Rectangle small_rectangle=new Rectangle();			
					small_rectangle.setPosition_x(x);
					small_rectangle.setPosition_y(y);
					small_rectangle.setWidth(small_width);
					small_rectangle.setHeight(small_height);
					shape_temp.add(small_rectangle);					
					num_rectengle+=1;    /*value of rectengle which drawed */		
					y+=small_height;	
					}
		
				}
				
			}
			else if(height%small_width>=small_height){
				i=height%small_width;
				x=0;
				while(i>=small_height && x<width){
					if(x+small_width>=width){
						x=0;
						y+=small_height;						
						i-=small_width;
					}
					else{
						Rectangle small_rectangle=new Rectangle();						
					small_rectangle.setPosition_x(x);
					small_rectangle.setPosition_y(y);
					small_rectangle.setWidth(small_width);
					small_rectangle.setHeight(small_height);
					shape_temp.add(small_rectangle);					
					num_rectengle+=1;    /*value of rectengle which drawed */		
					x+=small_width;	
					}
				}
			}
		}
		shape_array= new Rectangle [num_rectengle];
		shape_temp.toArray(shape_array);		
		
		rect_area=width*height;		/*area of rectangle*/
		s_rect_area=(small_width*small_height)*num_rectengle;	/*area of small rectangle*/
		System.out.printf("I can fit at most %d small shapes into the main container. The empty area (red) in container is %d: \n",num_rectengle,rect_area-s_rect_area);
		area_shape=s_rect_area;
	}
		
		
	/**
	 * 	Optimalfit helper function for Rectangle-Triangle shapes draw
	 */
	private void optimalfit_helper2(){
		int x=0, y=0,num_triangle=0,i,j,w_1,h_1;
		double triangle_area;
		double rect_area;
		ArrayList<Triangle> shape_temp =new ArrayList<Triangle>();		
		int width=rectang.getWidth();
		int height=rectang.getHeight();
		int side=(int)small_triangle.getSide();
		h_1=(int)(height/(side/2*Math.sqrt(3)));	/*I calculate num of triangle for every column*/
		w_1=width/side;		/*I calculate num of triangle for every line*/
		for(i=0;i<h_1;i++){
			for(j=0;j<w_1;j++){
				Triangle small_triangle=new Triangle();										
				small_triangle.setPosition_x(x);
				small_triangle.setPosition_y(y+(side/2)*Math.sqrt(3));
				small_triangle.setPosition_x2(x+side);
				small_triangle.setPosition_y2(y+(side/2)*Math.sqrt(3));
				small_triangle.setPosition_x3(x+side/2);
				small_triangle.setPosition_y3(y);								
				small_triangle.setSide(side);
				shape_temp.add(small_triangle);				
				num_triangle+=1;	/*count of triangle*/
				x+=side;
			}
			y+=side/2*Math.sqrt(3);
			j=0;
			x=0;
		}
				/*I write in file for reversing triangle in rectangle*/
		h_1=(int)(height/(side/2*Math.sqrt(3)));
		w_1=(width-side/2)/side;
		x=side/2;
		y=0;
		for(i=0;i<h_1;i++){
			for(j=0;j<w_1;j++){
				Triangle small_triangle=new Triangle();														
				small_triangle.setPosition_x(x);
				small_triangle.setPosition_y(y);
				small_triangle.setPosition_x2(x+side);
				small_triangle.setPosition_y2(y);
				small_triangle.setPosition_x3(x+side/2);
				small_triangle.setPosition_y3(y+(side/2)*Math.sqrt(3));								
				small_triangle.setSide(side);
				shape_temp.add(small_triangle);				
				
				x+=side;
				num_triangle+=1;	/*count of triangle*/
			}
			y+=side/2*Math.sqrt(3);
			j=0;
			x=side/2;
		}
		shape_array= new Triangle [num_triangle];		
		rect_area=width*height;		/*area of rectangle*/
		triangle_area=num_triangle*((side*side)*Math.sqrt(3)/4);		/*area of all of the triangle in rectangle*/
		shape_temp.toArray(shape_array);				
		System.out.printf("I can fit at most %d small shapes into the main container. The empty area (red) in container is %.2f: \n",num_triangle,rect_area-triangle_area);		
		//cout<<"I can fit at most "<< num_triangle<<" small shapes into the main container. The empty area (red) in container is :"<<rect_area-triangle_area<<endl;			
	}
	
	/**
	 * Optimalfit helper function for Rectangle-Circle shapes draw
	 */
	private void optimalfit_helper3(){
		int y1_a,y2_a,x_k,y_k,sayac=0,num_circle=0;		
		double rect_area, circ_area;
		ArrayList<Circle> shape_temp =new ArrayList<Circle>();				
		int width=rectang.getWidth();
		int height=rectang.getHeight();
		int radius=(int)small_circle.getRadius();		
		y1_a=height/(4*radius);					/*it's for first type sequence*/
		x_k=0;
		y_k=0;
		y2_a=(int)(height/(2*radius+(radius*Math.sqrt(3))));	/*it's for second type sequence*/
		if(y1_a<y2_a && y2_a<width && y2_a<height){
			while(y_k<=height){
				Circle small_circle=new Circle();														
				small_circle.setPosition_x(x_k);
				small_circle.setPosition_y(y_k);
				small_circle.setRadius(radius);
				shape_temp.add(small_circle);				
				num_circle+=1;		/*count of circle*/
				x_k+=2*radius;
				if(x_k+radius>width){
					sayac++;	
					if(sayac%2==1)
						x_k=2*radius;
					else
						x_k=0;
					y_k+=(radius*Math.sqrt(3));
				}
			}
		}
		else{
			while(y_k+radius<=height){
				Circle small_circle=new Circle();																	
				small_circle.setPosition_x(x_k);
				small_circle.setPosition_y(y_k);
				small_circle.setRadius(radius);
				shape_temp.add(small_circle);								
				num_circle+=1;		/*count of circle*/
				x_k+=2*radius;
				if(x_k+radius>width){
					x_k=0;
					y_k+=2*radius;
				}
			}
		
		}
		shape_array= new Circle [num_circle];		
		rect_area=width*height;
		circ_area=num_circle*(radius*radius*Math.sqrt(3));
		shape_temp.toArray(shape_array);				
		System.out.printf("I can fit at most %d small shapes into the main container. The empty area (red) in container is %.2f: \n",num_circle,rect_area-circ_area);				
		//cout<<"I can fit at most "<< num_circle<<" small shapes into the main container. The empty area (red) in container is :"<<rect_area-circ_area<<endl;	
		area_shape=rect_area-circ_area;
	}
	
	/**
	 * Optimalfit helper function for Triangle-Rectangle shapes draw
	 */
	private void optimalfit_helper4(){
		double rectangle_area,triangle_area,x,temp,y;
		double side=triang.getSide();
		ArrayList<Rectangle> shape_temp =new ArrayList<Rectangle>();		
		int num_rectangle=0;
		int small_width=small_rectangle.getWidth();
		int small_height=small_rectangle.getHeight();
		x=small_height/Math.sqrt(3);	/*start point for x coorcinate*/
		temp=x;
		y=(side/2.0)*Math.sqrt(3.0)-small_height;	/*start point for y coorcinate*/
		triangle_area=((side*side*Math.sqrt(3))/4);		/*area of triangle*/
		side-=(small_height)/Math.sqrt(3.0);	
		while(x<=side && y>0){
			if(x+small_width>=side){
				y-=small_height;
		   		x=small_height/Math.sqrt(3.0)+temp;
				temp=x;
				side-=(small_height)/Math.sqrt(3.0);		/*calculate for each line max width to end*/
			}
			else{	
				Rectangle small_rectangle=new Rectangle();							
				small_rectangle.setPosition_x(x);
				small_rectangle.setPosition_y(y);
				small_rectangle.setWidth(small_width);
				small_rectangle.setHeight(small_height);
				shape_temp.add(small_rectangle);								
				num_rectangle+=1;		/*value of rectangle for each drawed */
				x+=small_width;
			}
		}
		//draw_small(&(myfile),shape_v);	
		shape_array= new Rectangle [num_rectangle];		
		shape_temp.toArray(shape_array);				
		rectangle_area=(double)(small_width*small_height)*num_rectangle;		/*area of rectangle*/
		System.out.printf("I can fit at most %d small shapes into the main container. The empty area (red) in container is %.2f: \n",num_rectangle,triangle_area-rectangle_area);						
		area_shape=triangle_area-rectangle_area;
	}
	
	/**
	 * Optimalfit helper function for Triangle-Triangle shapes draw
	 */
	private void optimalfit_helper5(){
		double x=0, y=0,temp=0,temp2,triangle_area,s_triangle_area,side,s_side;
		int num_triangle=0;
		ArrayList<Triangle> shape_temp =new ArrayList<Triangle>();				
		side=triang.getSide();
		s_side=small_triangle.getSide();	
		temp2=side;	
		y=(side/2)*Math.sqrt(3);						/*start point for y coordinate*/
		triangle_area=(side*side*Math.sqrt(3))/4;	/*main shape area*/
		while(x<=side && y-(s_side/2)>=0){		
			if(x+s_side>side){
				side-=s_side/2;
				x=s_side/2+temp;
				temp=x;
				y-=s_side/2*Math.sqrt(3);
			}
			else{
				Triangle small_triangle=new Triangle();														
				small_triangle.setPosition_x(x);
				small_triangle.setPosition_y(y);
				small_triangle.setPosition_x2(x+s_side);
				small_triangle.setPosition_y2(y);
				small_triangle.setPosition_x3(x+s_side/2);
				small_triangle.setPosition_y3(y-(s_side/2)*Math.sqrt(3));								
				small_triangle.setSide(s_side);	
				shape_temp.add(small_triangle);								
			num_triangle+=1;	/*value of triangle for each drawed */
			x+=s_side;
			}		
		}
		side=temp2;
		temp=s_side/2;
		//reversing small triangle writing code
		y=(side/2)*Math.sqrt(3);
		x=s_side/2;
		side=side-s_side/2;
		while(x<=side && y-(s_side/2)>=0){
			if(x+s_side>side){
				side-=s_side/2;
				x=s_side/2+temp;
				temp=x;
				y-=s_side/2*Math.sqrt(3);
			}
			else{
				Triangle small_triangle=new Triangle();													
				small_triangle.setPosition_x(x);
				small_triangle.setPosition_y(y-(s_side/2)*Math.sqrt(3));
				small_triangle.setPosition_x2(x+s_side);
				small_triangle.setPosition_y2(y-(s_side/2)*Math.sqrt(3));
				small_triangle.setPosition_x3(x+s_side/2);
				small_triangle.setPosition_y3(y);								
				small_triangle.setSide(s_side);	
				shape_temp.add(small_triangle);				
				
			num_triangle+=1;	/*value of triangle for each drawed */
			x+=s_side;
			}	
		
		}
		shape_array= new Triangle [num_triangle];
		
		shape_temp.toArray(shape_array);				
		s_triangle_area=((s_side*s_side*Math.sqrt(3))/4)*num_triangle;		//small triangle area
		System.out.printf("I can fit at most %d small shapes into the main container. The empty area (red) in container is %.2f: \n",num_triangle,triangle_area-s_triangle_area);								
		area_shape=	triangle_area-s_triangle_area;
		
	}
	
	/**
	 * Optimalfit helper function for Triangle-Circle shapes draw
	 */
	private void optimalfit_helper6(){
		double x_k,y_k,temp,side,radius;
		double triangle_area,circle_area;
		ArrayList<Circle> shape_temp =new ArrayList<Circle>();						
		int num_circle=0;
		side=triang.getSide();
		radius=small_circle.getRadius();		
		x_k=radius*Math.sqrt(3)/2;						/*start point for radius center of x coordinate*/
		temp=x_k;
		y_k=(((side*Math.sqrt(3))/2)-(radius*2));			/*start point for radius center of y coordinate*/
		triangle_area=(side*side*Math.sqrt(3))/4;	/*area of triangle*/
		side=side-radius/Math.sqrt(3);				/*circle triangle calculating variable max size for width */
		while(x_k<=side && y_k>=0){
			if(x_k+radius<side){
				Circle small_circle=new Circle();																				
				small_circle.setPosition_x(x_k);
				small_circle.setPosition_y(y_k);
				small_circle.setRadius(radius);	
				shape_temp.add(small_circle);								
				num_circle+=1;					/*value of circle for each drawed */
				x_k+=2*radius;	
			}		
			if(x_k+radius>=side){
				x_k=temp+radius;
				temp=x_k;
				y_k-=radius*Math.sqrt(3);
				side-=radius;
			}	
		}
		shape_array= new Circle [num_circle];		
		shape_temp.toArray(shape_array);				
		circle_area=(radius*radius*3.14)*num_circle;		//area of circle
		System.out.printf("I can fit at most %d small shapes into the main container. The empty area (red) in container is %.2f: \n",num_circle,triangle_area-circle_area);								
		area_shape=	triangle_area-circle_area;
	}
	
	/**
	 * Optimalfit helper function for Circle-Rectangle shapes draw
	 */
	private void optimalfit_helper7(){
		int x=0,y=0,flag=0,num_rectangle=0;
		double rect_area,circ_area,radius;
		int width,height;
		radius=circ.getRadius();				
		width=small_rectangle.getWidth();
		height=small_rectangle.getHeight();
		ArrayList<Rectangle> shape_temp =new ArrayList<Rectangle>();

			while(y<=2*radius && x>=0){
				while(x<=2*radius){
		/*I checked point to point.I used this condition for every point of rectangle in circle or not*/
					if((((x-radius+width))*((x-radius+width))+((y-radius)*(y-radius))<=(radius*radius)) && ((x-radius)*(x-radius)+((y-radius+height)*(y-radius+height))<=(radius*radius)) && (x-radius)*(x-radius)+(y-radius)*(y-radius)<=(radius*radius) && ((x-radius+width)*(x-radius+width)+((y-radius+height))*(y-radius+height)<=(radius*radius)) ){
						Rectangle small_rectangle=new Rectangle();								
						small_rectangle.setPosition_x(x);
						small_rectangle.setPosition_y(y);
						small_rectangle.setWidth(width);
						small_rectangle.setHeight(height);	
						shape_temp.add(small_rectangle);										
					   	num_rectangle+=1;
						x+=width;		
						flag=1;
					}
					else{
					x++;
					}				
				}
				x=0;
				if(flag==0){
					y++;
				}	
				else{
					y+=height;}
				flag=0;
			}
			shape_array= new Rectangle [num_rectangle];			
			shape_temp.toArray(shape_array);					
		rect_area=(width*height)*num_rectangle;		/*area of rectangle*/
		circ_area=(radius*radius*3.14);				/*area of circle*/
		System.out.printf("I can fit at most %d small shapes into the main container. The empty area (red) in container is %.2f: \n",num_rectangle,circ_area-rect_area);										
		//cout<<"I can fit at most "<< num_rectangle<<" small shapes into the main container. The empty area (red) in container is :"<<circ_area-rect_area<<endl;			
		area_shape=circ_area-rect_area;
	}
	
	/**
	 * Optimalfit helper function for Circle-Triangle shapes draw
	 */
	private void optimalfit_helper8(){
		int i;
		double x,y,circ_area,triangle_area,side,radius;
		int num_triangle=0;
		ArrayList<Triangle> shape_temp =new ArrayList<Triangle>();				
		radius=circ.getRadius();
		side=small_triangle.getSide();		
		y=0;
		x=0;
		while(y<=2*radius && x>=0){
				for(i=0;i<2*radius;i++){
					/*I checked point to point.I used this condition for every point of triangle in circle or not*/
					if( (((x-radius)*(x-radius))+((y-radius)*(y-radius))<=(radius*radius)) && (((x+side/2)-radius)*(x+(side/2)-radius)+(y-((side/2)*Math.sqrt(3))-radius)*(y-((side/2)*Math.sqrt(3))-radius)<=(radius*radius)) && ((x+side-radius)*(x+side-radius)+(y-radius)*(y-radius)<=(radius*radius))  ){
					Triangle small_triangle=new Triangle();										
					small_triangle.setPosition_x(x);
					small_triangle.setPosition_y(y);
					small_triangle.setPosition_x2(x+side);
					small_triangle.setPosition_y2(y);
					small_triangle.setPosition_x3(x+side/2);
					small_triangle.setPosition_y3(y-(side/2)*Math.sqrt(3));										
					small_triangle.setSide(side);
					shape_temp.add(small_triangle);									
					num_triangle+=1;  	/*value of triangle*/
					x+=side;
					}
					else
					x++;				
				}

				x=0;
				y+=(side*Math.sqrt(3))/2;			
			}		
	
		x=0;
		y=0;
		while(y<=2*radius && x>=0){
				for(i=0;i<2*radius;i++){
					/*I checked point to point.I used this condition for every point of reversing triangle in circle or not*/	
					if((((x-radius)*(x-radius))+((y-radius)*(y-radius))<=(radius*radius)) && (((x-radius+(3*side)/2)*(x+((3*side)/2)-radius))+((y-(side/2)*Math.sqrt(3)-radius)*(y-(side/2)*Math.sqrt(3)-radius))<=(radius*radius)) && (((x+side/2)-radius)*(x+(side/2)-radius)+(y-((side/2)*Math.sqrt(3))-radius)*(y-((side/2)*Math.sqrt(3))-radius)<=(radius*radius)) && ((x+side-radius)*(x+side-radius)+(y-radius)*(y-radius)<=(radius*radius)) ){
						Triangle small_triangle=new Triangle();															
						small_triangle.setPosition_x(x+side/2);
						small_triangle.setPosition_y(y-(side/2)*Math.sqrt(3));
						small_triangle.setPosition_x2(x+side);
						small_triangle.setPosition_y2(y);
						small_triangle.setPosition_x3(x+(3*side)/2);
						small_triangle.setPosition_y3(y-(side/2)*Math.sqrt(3));										
						small_triangle.setSide(side);	
						shape_temp.add(small_triangle);										
						num_triangle+=1;		/*value of reversing triangle*/		
						x+=side;
					}
					else{			
					x++;
					}								
				}
				x=0;
				y+=(side*Math.sqrt(3))/2;
		}
		shape_array= new Triangle [num_triangle];		
		shape_temp.toArray(shape_array);				
		circ_area=(radius*radius*3.14);		/*area of circle*/
		triangle_area=((side*side*Math.sqrt(3))/4)*num_triangle;		/*area of triangle*/
		System.out.printf("I can fit at most %d small shapes into the main container. The empty area (red) in container is %.2f: \n",num_triangle,circ_area-triangle_area);												
		//cout<<"I can fit at most "<<num_triangle<<" small shapes into the main container. The empty area (red) in container is :"<<circ_area-triangle_area<<endl;		
		area_shape=circ_area-triangle_area;
	}
	
	
	/**
	 * Optimalfit helper function for Circle-Circle shapes draw
	 */
	private void optimalfit_helper9(){
		double x=0,y=0,flag=0,circ_area,s_circ_area,radius,s_radius;
		int num_circ=0;
		ArrayList<Circle> shape_temp =new ArrayList<Circle>();						
		radius=circ.getRadius();
		s_radius=small_circle.getRadius();			
		while(y<2*radius && x<2*radius){
			while(x<=2*radius){	
					/*I checked point to point.I used this condition for some points of circle, in circle or not*/	
				if( 
				(((x-(s_radius))-radius+s_radius)*((x-(s_radius))-radius+s_radius)+((y-(s_radius))-radius+s_radius)*((y-(s_radius))-radius+s_radius)<(radius*radius)) &&
				(((x-(s_radius))-radius+s_radius)*((x-(s_radius))-radius+s_radius)+((y+(s_radius))-radius+s_radius)*((y+(s_radius))-radius+s_radius)<(radius*radius)) &&
				(((x+(s_radius))-radius+s_radius)*((x+(s_radius))-radius+s_radius)+((y+(s_radius))-radius+s_radius)*((y+(s_radius))-radius+s_radius)<(radius*radius)) &&
				(((x+(s_radius))-radius+s_radius)*((x+(s_radius))-radius+s_radius)+((y-(s_radius))-radius+s_radius)*((y-(s_radius))-radius+s_radius)<(radius*radius)) ){
					Circle small_circle=new Circle();																						
					small_circle.setPosition_x(x);
					small_circle.setPosition_y(y);
					small_circle.setRadius(s_radius);
					shape_temp.add(small_circle);									
					flag=1;
					num_circ+=1;
					x+=2*s_radius;	
				}
				else{
				x++;
				}
			}	
			if(x>=2*radius){
				y++;
				x=0;
			}
			if(flag==1){
				y+=2*s_radius;
			}
			else{
				y++;
			}
			flag=0;		
			x=0;
		}
		shape_array= new Circle [num_circ];		
		shape_temp.toArray(shape_array);				
		circ_area=(radius*radius*3.14)*num_circ;		/*area of circle*/
		s_circ_area=(s_radius*s_radius*3.14)/4;			/*area of small circle*/
		System.out.printf("I can fit at most %d small shapes into the main container. The empty area (red) in container is %.2f: \n",num_circ,circ_area-s_circ_area);														
		//cout<<"I can fit at most "<<num_circ<<" small shapes into the main container. The empty area (red) in container is :"<<circ_area-s_circ_area<<endl;		
		area_shape=circ_area-s_circ_area;
	}	
	
	
	
	public ComposedShape(){
		
	}
	
	/**
	 * ComposedShape private rectangle-rectangle for inner and container object referance copying
	 * @param shape_rect
	 * @param small_shape
	 */
	public ComposedShape(Rectangle shape_rect,Rectangle small_shape){	/*this constructor for main container rectangle and small container rectangle assign the objes which create in main,to composedshape clas's objes*/	
		rectang=shape_rect;
		small_rectangle=small_shape;
		
	}
	
	/**
	 * ComposedShape private rectangle-triangle for inner and container object referance copying
	 * @param shape_rect
	 * @param small_shape
	 */
	public ComposedShape(Rectangle shape_rect,Triangle small_shape ){	/*this constructor for main container rectangle and small container triangle assign the objes which create in main,to composedshape clas's objes*/
		rectang=shape_rect;
		small_triangle=small_shape;
	}
	
	/**
	 * ComposedShape private rectangle-circle for inner and container object referance copying
	 * @param shape_rect
	 * @param small_shape
	 */
	public ComposedShape(Rectangle shape_rect,Circle small_shape){	/*this constructor for main container rectangle and small container circle assign the objes which create in main,to composedshape clas's objes*/	
		rectang=shape_rect;
		small_circle=small_shape;		
	}
	
	/**
	 * ComposedShape private triangle-rectangle for inner and container object referance copying
	 * @param shape_tri
	 * @param small_shape
	 */
	public ComposedShape(Triangle shape_tri,Rectangle small_shape ){	/*this constructor for main container triangle and small container rectangle assign the objes which create in main,to composedshape clas's objes*/
		triang=shape_tri;
		small_rectangle=small_shape	;	
	}
	
	/**
	 * ComposedShape private triangle-triangle for inner and container object referance copying
	 * @param shape_tri
	 * @param small_shape
	 */
	public ComposedShape(Triangle shape_tri,Triangle small_shape){	/*this constructor for main container triangle and small container triangle assign the objes which create in main,to composedshape clas's objes*/
		triang=shape_tri;
		small_triangle=small_shape;	
	}
	
	/**
	 * ComposedShape private triangle-circle for inner and container object referance copying
	 * @param shape_tri
	 * @param small_shape
	 */
	public ComposedShape(Triangle shape_tri,Circle small_shape){		/*this constructor for main container triangle and small container circle assign the objes which create in main,to composedshape clas's objes*/
		triang=shape_tri;
		small_circle=small_shape;		
	}
	
	/**
	 * ComposedShape private circle-rectangle for inner and container object referance copying
	 * @param shape_circ
	 * @param small_shape
	 */
	public ComposedShape(Circle shape_circ,Rectangle small_shape ){	/*this constructor for main container circle and small container rectangle assign the objes which create in main,to composedshape clas's objes*/
		circ=shape_circ;
		small_rectangle=small_shape;		
	}
	
	/**
	 * ComposedShape private circle-triangle for inner and container object referance copying
	 * @param shape_circ
	 * @param small_shape
	 */
	public ComposedShape(Circle shape_circ,Triangle small_shape){		/*this constructor for main container circle and small container triangle assign the objes which create in main,to composedshape clas's objes*/
		circ=shape_circ;
		small_triangle=small_shape;
	}	
	
	/**
	 * ComposedShape private circle-circle for inner and container object referance copying
	 * @param shape_circ
	 * @param small_shape
	 */
	public ComposedShape(Circle shape_circ,Circle small_shape){		/*this constructor for main container circle and small container circle assign the objes which create in main,to composedshape clas's objes*/		
		circ=shape_circ;
		small_circle=small_shape;	
	}
	
	/**
	 * Choose for which helper function work
	 */
	public void optimalfit(){
		/*I check the users input main container and small_container for draw this shapes*/
		if(main_char=='R' || main_char=='r'){
			if(small_char=='R' || small_char=='r'){
				optimalfit_helper1();	/*I wrote in Hw1 this fuction and get the member data in this class and draw rectangle in rectangle*/
			}
			if(small_char=='T' || small_char=='t'){		
				optimalfit_helper2();	/*I wrote in Hw1 this fuction and get the member data in this class and draw triangle in rectangle*/			
			}
			if(small_char=='C' || small_char=='c'){				
				optimalfit_helper3();	/*I wrote in Hw1 this fuction and get the member data in this class and draw circle in rectangle*/
			}						
		}
		
  		else if(main_char=='T' || main_char=='t'){															
			if(small_char=='R' || small_char=='r'){	
				optimalfit_helper4();	/*I wrote in Hw1 this fuction and get the member data in this class and draw rectangle in triangle*/
			}
			else if(small_char=='T' || small_char=='t'){				
				optimalfit_helper5();	/*I wrote in Hw1 this fuction and get the member data in this class and draw triangle in triangle*/				
			}
			else if(small_char=='C' || small_char=='c'){				
				optimalfit_helper6();	/*I wrote in Hw1 this fuction and get the member data in this class and draw circle in circle*/				
			}		  	
   		} 

		else if(main_char=='C' || main_char=='c'){																										
			if(small_char=='R' || small_char=='r'){	
				optimalfit_helper7();	/*I wrote in Hw1 this fuction and get the member data in this class and draw rectangle in circle*/				

			}
			if(small_char=='T' || small_char=='t'){				
				optimalfit_helper8();	/*I wrote in Hw1 this fuction and get the member data in this class and draw triangle in circle*/				

			}
			if(small_char=='C' || small_char=='c'){			
				optimalfit_helper9();	/*I wrote in Hw1 this fuction and get the member data in this class and draw circle in circle*/				
			}    			
		} 		
	}
	
	/**
	 * Container Choice getting with character
	 * @return Container Choice
	 */
	public char getMainchar(){
		return main_char;
	}
	
	/**
	 * Container Choice setting with character
	 * @param main_container
	 */
	public void setMainchar(char main_container){
		main_char=main_container;
	}
	
	/**
	 * Inner Choice getting with character
	 * @return small_char choise
	 */
	public char getSmallchar(){
		return small_char;
	}
	
	/**
	 * Inner Choice setting with character
	 * @param main_container
	 */
	public void setSmallchar(char main_container){
		small_char=main_container;
	}
	
	/**
	 * @return area of all inner shapes area
	 */
	public double area(){		/*I calculate each step my innershapes whole area and acces with cast my voi* variable*/	
		return area_shape;	
	}
	
	/**
	 * @return perimeter
	 */
	public double perimeter(){ /*I calculate each step my innershapes whole perimeter length and acces with cast my voi* variable*/
		return 1.0;
	}
	
	/**
	 * @return itself
	 * ComposedShape Coordinate x and Coordiate y increment 1
	 */
	public ComposedShape increment(){
		if(shape_array[0] instanceof Rectangle){
			System.out.printf("\n----Before Circle-Increment-Decrement Method Coord_x %.1f Coord_y %.1f ----\n",((Rectangle)shape_array[0]).getPosition_x(),((Rectangle)shape_array[0]).getPosition_y());					 
		 }	
		 if(shape_array[0] instanceof Triangle){
				System.out.printf("\n----Before Circle-Increment-Decrement Method Coord_x %.1f Coord_y %.1f ----\n",((Triangle)shape_array[0]).getPosition_x(),((Triangle)shape_array[0]).getPosition_y());	
		 }
		 if(shape_array[0] instanceof Circle){
				System.out.printf("\n----Before Circle-Increment-Decrement Method Coord_x %.1f Coord_y %.1f ----\n",((Circle)shape_array[0]).getPosition_x(),((Circle)shape_array[0]).getPosition_y());	
		 }	
				
		for(int i=0;i<shape_array.length;i++){
			 if(shape_array[i] instanceof Rectangle){
				((Rectangle)shape_array[i]).setPosition_x(((Rectangle)shape_array[i]).getPosition_x()+1);
			 }	
			 if(shape_array[i] instanceof Triangle){
				 ((Triangle)shape_array[i]).setPosition_x(((Triangle)shape_array[i]).getPosition_x()+1);
			 }
			 if(shape_array[i] instanceof Circle){
				((Circle)shape_array[i]).setPosition_x(((Circle)shape_array[i]).getPosition_x()+1);
			 }			 
		}			
		if(shape_array[0] instanceof Rectangle){
			System.out.printf("----ComposedShape-Increment Method Coord_x %.1f Coord_y %.1f ----\n",((Rectangle)shape_array[0]).getPosition_x(),((Rectangle)shape_array[0]).getPosition_y());				
		 }	
		 if(shape_array[0] instanceof Triangle){
			System.out.printf("----ComposedShape-Increment Method Coord_x %.1f Coord_y %.1f ----\n",((Triangle)shape_array[0]).getPosition_x(),((Triangle)shape_array[0]).getPosition_y());				
		 }
		 if(shape_array[0] instanceof Circle){
			System.out.printf("----ComposedShape-Increment Method Coord_x %.1f Coord_y %.1f ----\n",((Circle)shape_array[0]).getPosition_x(),((Circle)shape_array[0]).getPosition_y());				
		 }	
		
		return this;
	}
	
	/**
	 * @return itself
	 * ComposedShape object Coordinate x and Coordinate y decrement 1
	 */
	public ComposedShape decrement(){
		if(shape_array[0] instanceof Rectangle){
			System.out.printf("\n----Before Circle-Increment-Decrement Method Coord_x %.1f Coord_y %.1f ----\n",((Rectangle)shape_array[0]).getPosition_x(),((Rectangle)shape_array[0]).getPosition_y());					 
		 }	
		 if(shape_array[0] instanceof Triangle){
				System.out.printf("\n----Before Circle-Increment-Decrement Method Coord_x %.1f Coord_y %.1f ----\n",((Triangle)shape_array[0]).getPosition_x(),((Triangle)shape_array[0]).getPosition_y());	
		 }
		 if(shape_array[0] instanceof Circle){
				System.out.printf("\n----Before Circle-Increment-Decrement Method Coord_x %.1f Coord_y %.1f ----\n",((Circle)shape_array[0]).getPosition_x(),((Circle)shape_array[0]).getPosition_y());	
		 }			
		for(int i=0;i<shape_array.length;i++){
			 if(shape_array[i] instanceof Rectangle){
				((Rectangle)shape_array[i]).setPosition_x(((Rectangle)shape_array[i]).getPosition_x()-1);
			 }	
			 if(shape_array[i] instanceof Triangle){
				((Triangle)shape_array[i]).setPosition_x(((Triangle)shape_array[i]).getPosition_x()-1);
			 }
			 if(shape_array[i] instanceof Circle){
				((Circle)shape_array[i]).setPosition_x(((Circle)shape_array[i]).getPosition_x()-1);
			 }			 
		}	
		if(shape_array[0] instanceof Rectangle){
			System.out.printf("----ComposedShape-Decremment Method Coord_x %.1f Coord_y %.1f ----\n",((Rectangle)shape_array[0]).getPosition_x(),((Rectangle)shape_array[0]).getPosition_y());				
		 }	
		 if(shape_array[0] instanceof Triangle){
			 
			System.out.printf("----ComposedShape-Decremment Method Coord_x %.1f Coord_y %.1f ----\n",((Triangle)shape_array[0]).getPosition_x(),((Triangle)shape_array[0]).getPosition_y());				
		 }
		 if(shape_array[0] instanceof Circle){
			System.out.printf("----ComposedShape-Decremment Method Coord_x %.1f Coord_y %.1f ----\n",((Circle)shape_array[0]).getPosition_x(),((Circle)shape_array[0]).getPosition_y());				
		 }			
		return this;
	}
	
	/**
	 * draw composedshape object
	 * @param Obje Graphic obje for drawing gui
	 */
	public void draw(Graphics Obje){
		Obje.setColor(Color.GREEN);	
		//Obje.setBounds(100, 10, 1200, 1100);
		
		if(main_char=='R' || main_char=='r'){
			rectang.draw(Obje);
		}	
		else if(main_char=='T' || main_char=='t'){
			triang.draw(Obje);
		}
		else if(main_char=='C' || main_char=='c'){
			circ.draw(Obje);
		}		
		if(small_char=='R' || small_char=='r'){
	    	for(int i=0;i<shape_array.length;i++){
    		
	    		Obje.setColor(Color.RED);			    		
		    	Obje.fillRect((( (int)((Rectangle) shape_array[i]).getPosition_x())), ((int) ((Rectangle) shape_array[i]).getPosition_y()), ((int)((Rectangle) shape_array[i]).getWidth()), ((int)((Rectangle) shape_array[i]).getHeight()));
				Obje.setColor(Color.WHITE);				    	
		    	Obje.drawRect((( (int)((Rectangle) shape_array[i]).getPosition_x())), ((int) ((Rectangle) shape_array[i]).getPosition_y()), ((int)((Rectangle) shape_array[i]).getWidth()), ((int)((Rectangle) shape_array[i]).getHeight()));
		 
	    	}	    
		}
		else if(small_char=='T' || small_char=='t'){
	    	for(int i=0;i<shape_array.length;i++){
	    		Obje.setColor(Color.RED);			    		
	    		Obje.fillPolygon(new int[] { ((int)((Triangle) shape_array[i]).getPosition_x()), ((int)((Triangle) shape_array[i]).getPosition_x2()), ((int)((Triangle) shape_array[i]).getPosition_x3())}, new int[] {((int)((Triangle) shape_array[i]).getPosition_y()), ((int)((Triangle) shape_array[i]).getPosition_y2()), ((int)((Triangle) shape_array[i]).getPosition_y3())}, 3);
				Obje.setColor(Color.WHITE);				    	
	    		Obje.drawPolygon(new int[] { ((int)((Triangle) shape_array[i]).getPosition_x()), ((int)((Triangle) shape_array[i]).getPosition_x2()), ((int)((Triangle) shape_array[i]).getPosition_x3())}, new int[] {((int)((Triangle) shape_array[i]).getPosition_y()), ((int)((Triangle) shape_array[i]).getPosition_y2()), ((int)((Triangle) shape_array[i]).getPosition_y3())}, 3);
	   
	    	}
		}
		else if(small_char=='C' || small_char=='c'){
	    	for(int i=0;i<shape_array.length;i++){
	    		Obje.setColor(Color.RED);			    			    		
		    	Obje.fillOval((( (int)((Circle) shape_array[i]).getPosition_x())), ((int) ((Circle) shape_array[i]).getPosition_y()), ((int)((Circle) shape_array[i]).getRadius()*2),((int)((Circle) shape_array[i]).getRadius()*2));
				Obje.setColor(Color.WHITE);				    	
		    	Obje.drawOval((( (int)((Circle) shape_array[i]).getPosition_x())), ((int) ((Circle) shape_array[i]).getPosition_y()), ((int)((Circle) shape_array[i]).getRadius()*2),((int)((Circle) shape_array[i]).getRadius()*2));
		   
	    	}			
		}
	}
	
	/**
	 * @param Obje Graphic object for drawing gui
	 * overload method for calling draw function
	 */
	public void paintComponent(Graphics Obje){
		super.paintComponent(Obje);
		draw(Obje);
		
	}
	
	/**
	 * Compare area with two object
	 * @param object Comparable object type of shape it can change any shape of elements
	 */
	@Override
	public int compareTo(Shape object) {
		if(this.area()==object.area())
			return 1;
		return 0;
	}
	




}
