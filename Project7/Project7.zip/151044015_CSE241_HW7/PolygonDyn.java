import java.awt.Color;
import java.awt.Graphics;


@SuppressWarnings("serial")
public class PolygonDyn extends Polygon  {
	/**
	 * Point2d reference array
	 */
	private Point2D[] temp_obje;
	/**
	 * capacity of points
	 */
	private int capacity;
	/**
	 * Polygondyn area
	 */
	private double area_p;
	/**
	 * Polygondyn length
	 */
	private double perimeter_p;	
	
	
	/**
	 * PolygonDyn take rectangle object constructure
	 * @param obj_r rectangle object
	 */
	public PolygonDyn(Rectangle obj_r){
		capacity=4;		//point num
		temp_obje= new Point2D[]{	new Point2D(obj_r.getPosition_x(),   obj_r.getPosition_y()),
				new Point2D(obj_r.getWidth()+obj_r.getPosition_x(),    obj_r.getPosition_y()),
				new Point2D(obj_r.getWidth()+obj_r.getPosition_x(),    obj_r.getHeight()+obj_r.getPosition_y()),				
				new Point2D(obj_r.getPosition_x(),    obj_r.getHeight()+obj_r.getPosition_y()),
				
		};		
		//I allocate memory for our shape of rectangle points.It has four points.
		//I set coorc of all points	my array
					
		area_p=obj_r.getWidth()*obj_r.getHeight();			//calculating rectangle area
		perimeter_p=(2*obj_r.getWidth())+(2*obj_r.getHeight());		//calculating rectangle perimeter		
	}
	
	/**
	 * PolygonDyn take triangle object constructure
	 * @param obj_t	triangle object
	 */
	public PolygonDyn(Triangle obj_t){
		capacity=3;		//point num
		temp_obje= new Point2D[]{ new Point2D(obj_t.getPosition_x(),obj_t.getPosition_y()),
				new Point2D(obj_t.getPosition_x2(),obj_t.getPosition_y2()),
				new Point2D(obj_t.getPosition_x3(),obj_t.getPosition_y3()),
			
		};				//I allocate memory for our shape of triangle points.It has three points.
		//I set coorc of all points	my array
		area_p=obj_t.getSide()*obj_t.getSide()*Math.sqrt(3)/4;	//calculating triangle area
		perimeter_p=3*obj_t.getSide();						//calculating triangle perimeter		
	}
	
	/**
	 * PolygonDyn take circle object constructure
	 * @param obj_c circle object
	 */
	public PolygonDyn(Circle obj_c){
		double teta;		//angle
		int i;		//loop element
		capacity=100;			//point num
		temp_obje= new Point2D[capacity];			//allocation new shape points array
		for(i=0;i<100;i++){
			teta=i*(3.6)*3.14/180;														//calclating points angle
			//I set coorc of all points	my array
			Point2D object=new Point2D(obj_c.getRadius()*2+(obj_c.getRadius()*2*Math.cos((teta))),obj_c.getRadius()*2+(obj_c.getRadius()*2*Math.sin((teta))));
			temp_obje[i]=object;
		}	 
		area_p=obj_c.getRadius()*obj_c.getRadius()*3.14;		//calculating circle area
		perimeter_p=2*3.14*obj_c.getRadius();			
	}	
	
	/**
	 * @return area_p PolygonDyn object area
	 */
	public double area(){
		return area_p;		
	}
	
	/**
	 *  @return perimeter_p PolygonDyn object area
	 */
	public double perimeter(){
		return perimeter_p;		
	}	
	
	/**
	 * get private member acces
	 * @return temp_obje private member array
	 */
	public Point2D[]  getPolygonArray(){
		return temp_obje;		
	}

	/**
	 * get private capacity variable
	 * @return capacity
	 */
	public int getCapacity(){		//get private capacity variable
		return capacity;	
	}
	
	/**
	 * draw PolygonDyn object in panel
	 * @param Obje garphic obje for draw in gui
	 */
	public void draw(Graphics Obje){

		int x_array[]=new int[capacity];
		int y_array[]=new int[capacity];
		for(int i=0;i<capacity;i++){
			x_array[i]=(int)temp_obje[i].getCoord_x();
			y_array[i]=(int)temp_obje[i].getCoord_y();
		}
		Obje.setColor(Color.RED);			    		
		Obje.fillPolygon( x_array,y_array,capacity);
		Obje.setColor(Color.WHITE);			    		
		Obje.drawPolygon( x_array,y_array,capacity);			
		
	}
	
	/**
	 * override function to call draw polygon method
	 */
	public void paintComponent(Graphics Obje){
		super.paintComponent(Obje);
		draw(Obje);

	}
	
	/**
	 * Polygondyn object coordinate x and y increment 1
	 * @return this itself
	 */
	@Override
	public Shape increment() {
		for(int i=0;i<capacity;i++){		
			temp_obje[i].setCoord_x(temp_obje[i].getCoord_x()+1);
			temp_obje[i].setCoord_y(temp_obje[i].getCoord_y()+1);
		}
		return this;
	}
	
	/**
	 * Polygondyn object coordinate x and y decrement 1
	 * return this itself
	 */
	@Override
	public Shape decrement() {
		for(int i=0;i<capacity;i++){		
			temp_obje[i].setCoord_x(temp_obje[i].getCoord_x()-1);
			temp_obje[i].setCoord_y(temp_obje[i].getCoord_y()-1);
		}
		return this;
	}


	/**
	 * Override for compare areas with PolygonDyn and object of Shape
	 */
	@Override
	public int compareTo(Shape object) {
		if(this.area_p==object.area())
			return 1;
		return 0;
	}
				


};
