import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public class Circle extends JPanel implements Shape {
	
	/**
	 * Circle radius
	 */
	private	double radius;
	/**
	 * Circle x coordinate
	 */
	private	double x;
	/**
	 * Circle y coordinate
	 */
	private	double y;		
	/**
	 * static class area
	 */
	private	static double area_c; 
	/**
	 * static class length
	 */
	private	static double length_c;	

	
	public Circle(){
		
	}
	/**
	 * Find Circle area method
	 * @return area circle area
	 */
	public double area(){
		double area;
		area=3.14*radius*radius;
		return area;
	}
	
	/**
	 * Find Circle perimeter method
	 * @return perimeter circle perimeter
	 */
	public double perimeter(){
		double perimeter;
		perimeter=3.14*2*radius;
		return perimeter;		
	}
	
	/**
	 * Increment x and y coordinate 1
	 * @return this return itself 
	 */
	public Circle increment(){
 		x+=1;	
		y+=1;	
		return this;		/*return adding 1 coordinates value */		
	}
	
	/**
	 * Decrement x and y coordinate 1
	 * @return this return itself 
	 */
	public Circle decrement(){
 		x-=1;	
		y-=1;	
		return this;		/*return subbed 1 coordinates value */		
	}
	
	/**
	 * Draw circle object with gui
	 * @param Obje Graphic obje
	 */
	public void draw(Graphics Obje){
		Obje.setColor(Color.BLUE);						
    	Obje.fillOval( ( (int)getPosition_x()), ((int) getPosition_y()), ((int)getRadius()*2),((int)getRadius()*2));
		
	}	
	/**
	 * JPanel method overloaded
	 * @param Obje Graphic obje
	 */
	public void paintComponent(Graphics Obje){
		super.paintComponent(Obje);
		draw(Obje);

	}	
	/**
	 * Circle Constructure for take radius
	 * @param f_radius
	 */
	public Circle(double f_radius)throws IllegalArgumentException{	
		if(f_radius>0.0){
			setRadius(f_radius);
			setPosition_x(0.0);
			setPosition_y(0.0);				
		}
		else
			throw new IllegalArgumentException("Only Positive Numbers & no Letters Please!");
	}
	/**
	 * Circle Constructure for take X and Y coordinate
	 * @param first Coordinate X
	 * @param second Coordinate Y
	 */
	public Circle(double first,double second)throws IllegalArgumentException{
		if(first>=0.0 && second>=0.0){
			x=first;
			y=second;
		}
		else
			throw new IllegalArgumentException("Only Positive Numbers & no Letters Please!");	
	}	
	
	/**
	 * Circle Constructure
	 * @param x_k Coordinate X
	 * @param y_k Coordinate Y
	 * @param radius_c Cycle Radius
	 */
	public Circle(double x_k,double y_k,double radius_c)throws IllegalArgumentException{
		if(x_k>=0.0 && y_k>=0.0){
			x=x_k;
			y=y_k;
			radius=radius_c;
			area_c+=(radius*radius*3.14);
			length_c+=(2*radius*3.14);		
		}
		else
			throw new IllegalArgumentException("Only Positive Numbers & no Letters Please!");	
		
	}	
	/**
	 * private radius variable get
	 * @return radius 
	 */
	public double getRadius(){
		return radius;
	}
	
	/**
	 * private radius variable set
	 * @param radius_c
	 */
	public void setRadius(double radius_c){
		radius=radius_c;
	}
	/**
	 * private coordinate x variable get
	 * @return x Coordinate x
	 */
	public double getPosition_x(){
		return x;
	}
	
	/**
	 * private coordinate x variable set
	 * @param x_koordinat
	 */
	public void setPosition_x(double x_koordinat){
		x=x_koordinat;		
	}
	
	/**
	 * private coordinate x variable get
	 * @return y Coordinate y
	 */
	public double getPosition_y(){
		return y;		
	}
	
	/**
	 * private coordinate y variable set
	 * @param y_koordinat
	 */
	public void setPosition_y(double y_koordinat){
		y=y_koordinat;
	}	
	
	/**
	 * Fınd whole circle area
	 * @return area_c class variable static member
	 */
	public static double total_areas(){
		return area_c;
	}
	
	/**
	 * Fınd whole circles perimeter
	 * @return length_c class variable static member
	 */
	public static double perimeter_length(){
		return length_c;
	}
	
	/**
	 * Compare areas 
	 * @param object Type of Shape object for polymorphsm 
	 */
	@Override
	public int compareTo(Shape object) {
		if(this.area()==object.area())
			return 1;
		return 0;
	}


		
}
