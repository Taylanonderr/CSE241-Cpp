import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;




@SuppressWarnings("serial")
public class PolygonVect extends Polygon {
	/**
	 * point2D class object
	 */
	private Point2D temp_obje;
	/**
	 * Point2d reference Arraylist
	 */
	private ArrayList<Point2D> shape_polygon;	
	/**
	 * capacity
	 */
	private int capacity;
	/**
	 * Polygonvect area
	 */
	private double area_p;
	/**
	 * Polygonvect length
	 */
	private double perimeter_p;
	
	/**
	 * PolygonDyn take rectangle object constructure
	 * @param obj_r	rectangle object
	 */
	public PolygonVect(Rectangle obj_r){
		capacity=4;		//point num
		//I set coorc of all points	my array
		shape_polygon=new ArrayList<Point2D>();
		
		temp_obje= new Point2D(obj_r.getPosition_x(),obj_r.getPosition_y());	//left
		shape_polygon.add(temp_obje);			
		temp_obje= new Point2D(obj_r.getWidth()+obj_r.getPosition_x(),obj_r.getPosition_y());		//right
		shape_polygon.add(temp_obje);	
		temp_obje= new Point2D(obj_r.getWidth()+obj_r.getPosition_x(),obj_r.getHeight()+obj_r.getPosition_y());		//right and under			
		shape_polygon.add(temp_obje);	
		temp_obje= new Point2D(obj_r.getPosition_x(),obj_r.getHeight()+obj_r.getPosition_y());		//left under		
		shape_polygon.add(temp_obje);
		area_p=obj_r.getWidth()*obj_r.getHeight();
		perimeter_p=(2*obj_r.getWidth())+(2*obj_r.getHeight());		
	}
	
	/**
	 * PolygonDyn take triangle object constructure
	 * @param obj_t	triangle object
	 */
	public PolygonVect(Triangle obj_t){
		capacity=3;		//point num
		//I set coorc of all points	my array
		shape_polygon=new ArrayList<Point2D>();		
		temp_obje= new Point2D(obj_t.getPosition_x(),obj_t.getPosition_y());	
		shape_polygon.add(temp_obje);
		temp_obje= new Point2D(obj_t.getPosition_x2(),obj_t.getPosition_y2());
		shape_polygon.add(temp_obje);	
		temp_obje= new Point2D(obj_t.getPosition_x3(),obj_t.getPosition_y3());
		shape_polygon.add(temp_obje);			
		area_p=obj_t.getSide()*obj_t.getSide()*Math.sqrt(3)/4;
		perimeter_p=3*obj_t.getSide();		
	}
	
	/**
	 * PolygonDyn take circle object constructure
	 * @param obj_c	circle object
	 */
	public PolygonVect(Circle obj_c){
		double teta;		//angle
		int i;		//loop element
		capacity=100;			//point num
		shape_polygon=new ArrayList<Point2D>();
		for(i=0;i<100;i++){
			teta=i*(3.6)*3.14/180;														//calclating points angle
			//I set coorc of all points	my array
			temp_obje= new Point2D(obj_c.getRadius()*2+obj_c.getRadius()*2*Math.cos((teta)),obj_c.getRadius()*2+obj_c.getRadius()*2*Math.sin((teta)));	
	    	shape_polygon.add(temp_obje);
		}	
		area_p=obj_c.getRadius()*obj_c.getRadius()*3.14;
		perimeter_p=2*3.14*obj_c.getRadius();		
	}
	
	/**
	 * @return area_p PolygonVect object area
	 */
	public double area(){
		return area_p;
		
	}
	
	/**
	 * @return perimeter_p PolygonVect object area
	 */
	public double perimeter(){
		return perimeter_p;
		
	}
	
	/**
	 * get private member acces
	 * @return shape_polygon private member ArrayList
	 */
	public ArrayList<Point2D>  getPolygonArray(){
		return shape_polygon;		
	}
	
	/**
	 * draw PolygonVect object in panel
	 * @param Obje garphic obje for draw in gui
	 */
	public void draw(Graphics Obje){

		int x_array[]=new int[capacity];
		int y_array[]=new int[capacity];
		for(int i=0;i<capacity;i++){
			x_array[i]=(int)shape_polygon.get(i).getCoord_x();
			y_array[i]=(int)shape_polygon.get(i).getCoord_y();
		}
		Obje.setColor(Color.RED);			    		
		Obje.fillPolygon( x_array,y_array,capacity);
		Obje.setColor(Color.WHITE);			    		
		Obje.drawPolygon( x_array,y_array,capacity);			
		
	}
	
	/**
	 * override function to call draw polygon method
	 */
	public void paintComponent(Graphics Obje){
		super.paintComponent(Obje);
		draw(Obje);
	}
	
	
	/**
	 * PolygonVect object coordinate x and y increment 1
	 * @return this itself
	 */	
	@Override
	public Shape increment() {
		for(int i=0;i<capacity;i++){
			shape_polygon.get(i).setCoord_x(shape_polygon.get(i).getCoord_x()+1);
			shape_polygon.get(i).setCoord_y(shape_polygon.get(i).getCoord_y()+1);
			
		}	
		return this;
	}
	
	/**
	 * PolygonVect object coordinate x and y decrement 1
	 * return this itself
	 */	
	@Override
	public Shape decrement() {
		for(int i=0;i<capacity;i++){
			shape_polygon.get(i).setCoord_x(shape_polygon.get(i).getCoord_x()-1);
			shape_polygon.get(i).setCoord_y(shape_polygon.get(i).getCoord_y()-1);
			
		}	
		return this;
	}

	
	/**
	 * Override for compare areas with PolygonDyn and object of Shape
	 */
	@Override
	public int compareTo(Shape object) {
		if(this.area_p==object.area())
			return 1;
		return 0;		
	}			



}
