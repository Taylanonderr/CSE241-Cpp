import java.awt.Graphics;


public interface Shape extends Comparable<Shape> {
	/**
	 * abstract method for calculate area the other class
	 */
	public double area();
	
	/**
	 * abstract method for calculate perimeter the other class
	 */
	public double perimeter();
	
	/**
	 * abstract method for increment coordinates 1 the other class
	 */
	public Shape increment();
	
	/**
	 * abstract method for decrement coordinates 1 the other class
	 */	
	public Shape decrement();
	
	/**
	 * abstract method for drawing shapes with gui other class
	 */	
	public void draw(Graphics Obje);
	
	/**
	 * abstract method for compare according to areas the other class
	 */	
	public int compareTo(Shape arg0);	
	//- area that returns the area of the shape
	//- perimeter that returns the perimeter
	//- Method increment and decrement for incrementing and decrementing the shape positions by 1.0.
	//- This interface implements the Comparable interface to compare shapes with respect to their areas.
	//- Draw takes a Graphics object as parameter and draws the shape. This method will be called from the paintComponent method of a JPanel object.
	
}
