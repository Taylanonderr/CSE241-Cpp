import java.util.ArrayList;

import javax.swing.JFrame;


public class StaticMethods {
	
	/**
	 * Sort shape array elements
	 * @param obje Shape of array include shape elements
	 */
	public static void sortShapes(Shape [] obje){
		ArrayList<Shape> temp=new ArrayList<Shape> ();
		int counter=0;		
		for(int i=0;i<obje.length;i++){
			for(int j=0;j<obje.length;j++){
				if(obje[i].area()<obje[j].area()){
					temp.add(obje[i]);
					obje[i]=obje[j];
					obje[j]=temp.get(counter);
					counter++;
				}
			}
		}		
	}
	
	/**
	 * Convert all of shape array type to Polygon
	 * @param obje	Shape of array include shape elements
	 * @return temp All object type Polygon array
	 */
	public static Shape[] convertAll(Shape [] obje){
		Shape[] temp=new Shape[obje.length];
		for(int i=0;i<obje.length;i++){
			if( obje[i] instanceof Rectangle){
				PolygonDyn poly1 = new PolygonDyn((Rectangle)obje[i]);
				temp[i]=(Shape) poly1;
			}
			if( obje[i] instanceof Triangle){
				PolygonDyn poly2 = new PolygonDyn((Triangle)obje[i]);
				temp[i]=(Shape) poly2;
				
			}	
			if( obje[i] instanceof Circle){
				PolygonDyn poly3 = new PolygonDyn((Circle)obje[i]);
				temp[i]=(Shape) poly3;				
			}		
		}

		return temp;
	}
	
	/**
	 * draw all shape array of element with gui
	 * @param obje	Shape of array include shape elements
	 */
	public static void drawAll(Shape [] obje){		
		for(int i=0;i<obje.length;i++){		
			if( obje[i] instanceof Rectangle){
				JFrame Frame=new JFrame();
				Frame.setTitle("DrawAll-Rectangle");					
				Frame.setSize(1000,1000);
				Frame.add((Rectangle)obje[i]);				
				Frame.setVisible(true);
			}
			if( obje[i] instanceof Triangle){
				JFrame Frame=new JFrame();
				Frame.setTitle("DrawAll-Triangle");									
				Frame.setSize(1000,1000);
				Frame.add((Triangle)obje[i]);				
				Frame.setVisible(true);		
			}	
			if( obje[i] instanceof Circle){
				JFrame Frame=new JFrame();
				Frame.setTitle("DrawAll-Circle");					
				Frame.setSize(1000,1000);
				Frame.add((Circle)obje[i]);				
				Frame.setVisible(true);			
			}
			if( obje[i] instanceof ComposedShape){
				JFrame Frame=new JFrame();
				Frame.setTitle("DrawAll-ComposedShape");					
				Frame.setSize(1000,1000);				
				Frame.add((ComposedShape)obje[i]);				
				Frame.setVisible(true);			
			}
			if( obje[i] instanceof PolygonDyn){
				JFrame Frame=new JFrame();
				Frame.setTitle("DrawAll-PolygonDyn");					
				Frame.setSize(1000,1000);				
				Frame.add((PolygonDyn)obje[i]);				
				Frame.setVisible(true);			
			}
			if( obje[i] instanceof PolygonVect){
				JFrame Frame=new JFrame();
				Frame.setTitle("DrawAll-PolygonVect");					
				Frame.setSize(1000,1000);				
				Frame.add((PolygonVect)obje[i]);				
				Frame.setVisible(true);			
			}			
			
		}
		
	}
}
