import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;


@SuppressWarnings("serial")
public class Rectangle extends JPanel implements Shape {
	/**
	 * rectangle width
	 */
	private int width;
	/**
	 * rectangle height
	 */
	private int height;
	/**
	 * rectangle x coordinate
	 */
	private double x;
	/**
	 * rectangley coordinate
	 */
	private double y;
	/**
	 * static class area
	 */
	private static double area_r=0; 
	/**
	 * static class length
	 */
	private static double length_r=0;	
	
	/**
	 * rectangle default constructure
	 */
	public Rectangle(){}	/*default constructure*/
	
	/**
	 * setting rectangle width and height value
	 * @param x for rectangle width
	 * @param y	for rectangle height
	 */
	public Rectangle(int x, int y )throws IllegalArgumentException 
	{	/*setting rectangle width and height value*/
		if(x>0 && y>0){
			setWidth(x);
			setHeight(y);				
		}
		else{
			throw new IllegalArgumentException("Only Positive Numbers & no Letters Please!");		
			}
		setPosition_x(0);
		setPosition_y(0);
	}
	
	/**
	 * this constructure for assign member value in new rectangle object
	 * @param x_k	Coordinate X
	 * @param y_k	Coordinate Y
	 * @param r_width	width rectangle
	 * @param r_height	height rectangle
	 */
	public Rectangle(double x_k,double y_k ,double r_width,double r_height)throws IllegalArgumentException{	
			if(x_k<0 || y_k<0 || r_width<0 || r_height<0)
				throw new IllegalArgumentException("Only Positive Numbers & no Letters Please!");		

			x=x_k;
			y=y_k;
			width=(int)r_width;
			height=(int)r_height;
			area_r+=width*height;
			length_r+=(2*width+2*height);				
		

	}		
	
	/**
	 * get width for rectangle objes for another class or methods which in not this class
	 * @return width rectangle width value
	 */
	public int getWidth(){		/*get width for rectangle objes for another class or methods which in not this class*/
		return width;
	}
	
	/**
	 * set width for rectangle objes for another class or methods which in not this class
	 * @param width_r 	set rectangle with value
	 */
	public void setWidth(int width_r)throws IllegalArgumentException{		/*set width for rectangle objes for another class or methods which in not this class*/
		if(width_r<0)
			throw new IllegalArgumentException("Only Positive Numbers for width Please!");
		width=width_r;
	}		
	
	/**
	 * get height for rectangle objes for another class or methods which in not this class
	 * @return height rectangle height value
	 */
	public int getHeight(){		/*get height for rectangle objes for another class or methods which in not this class*/
		return height;
	}
	
	/**
	 * set height for rectangle objes for another class or methods which in not this class
	 * @param height_r rectangle new height value
	 */
	public void setHeight(int height_r)throws IllegalArgumentException{		/*set height for rectangle objes for another class or methods which in not this class*/
		if(height_r<0)
			throw new IllegalArgumentException("Only Positive Numbers for height Please!");			
		height=height_r;
	}
	
	/**
	 * get coordinate x for circle objes for another class or methods which in not this class
	 * @return x Coordinate of Rectangle x
	 */
	public double getPosition_x(){		/*get coordinate x for circle objes for another class or methods which in not this class*/
		return x;
	}
	
	/**
	 * set coordinate y for circle objes for another class or methods which in not this class
	 * @param x_koordinat set Rectangle x coordinate
	 */
	public void setPosition_x(double x_koordinat){		/*set coordinate y for circle objes for another class or methods which in not this class*/
		x=x_koordinat;
	}
	
	/**
	 * get coordinate y for circle objes for another class or methods which in not this class
	 * @return y Rectangle y value
	 */
	public double getPosition_y(){		/*get coordinate y for circle objes for another class or methods which in not this class*/
		return y;
	}
	
	/**
	 * set coordinate y for circle objes for another class or methods which in not this class
	 * @param y_koordinat rectangle of y coordinate 
	 */
	public void setPosition_y(double y_koordinat){		/*set coordinate y for circle objes for another class or methods which in not this class*/
		y=y_koordinat;
	}												
	
	/**
	 * this method return area of the shape
	 * @return area Return rectangle area value 
	 */
	public double area(){	/*this method return area of the shape*/
		double area;
		area=width*height;
		return area;
	}
	
	/**
	 * this method return the perimeter length
	 * return perimeter_length rectangle perimeter_length
	 */
	public double perimeter(){	/*this method return the perimeter length*/
		double perimeter_length;
		perimeter_length=2*width+2*height;
		return perimeter_length;
	}
	
	/**
	  * @return	area_r return static area of class
	 */
	public static double total_areas(){
		return area_r;
	}
	
	/**
	 * 
	 * @return length_r return static perimeter_length of class
	 */
	public static double perimeter_length(){
		return length_r;
	}	
	
	/**
	 * return adding 1 x,y value
	 * @return this return itself
	 */
	public Rectangle increment(){
		x+=1;
		y+=1;
		return this;	/*return adding 1 x,y value */		
	}
	
	/**
	 * return subbed 1 x,y value
	 * @return this return itself
	 */
	public Rectangle decrement(){
		x-=1;
		y-=1;
		return this;			/*return subbed 1 x,y value */		
	}
	
	/**
	 * draw Rectangle object with gui
	 * @param Obje draw garphic gui object 
	 */
	public void draw(Graphics Obje){
		Obje.setColor(Color.BLUE);						
	    Obje.fillRect((int)getPosition_x(),(int) getPosition_y(), getWidth(), getHeight()); 	    
	}
	
	/**
	 * override JPanel method for call draw method and draw gui
	 * @param Obje Graphic object
	 */
	public void paintComponent(Graphics Obje){
		super.paintComponent(Obje);
		draw(Obje);

	}
	
	/**
	 * Compare areas rectangle with shape elements
	 * @param object Shape elements
	 */
	@Override
	public int compareTo(Shape object) {
		if(this.area()==object.area())
			return 1;
		return 0;
	}
	
}
