import javax.swing.JPanel;


@SuppressWarnings("serial")
public abstract class Polygon extends JPanel implements Shape{
	/**
	 * default constructure
	 */
	public Polygon(){}
	/**
	 * abstract area method
	 */
	public abstract double area();
	
	/**
	 * abstract perimeter method
	 */
	public abstract double perimeter();	

	public void draw() {
	}		
		public class Point2D{			
			private double coord_x;
			private double coord_y;
			
			/**
			 * Point2D class constructure set x and y coordinate
			 * @param x Coordinate x
			 * @param y Coordinate y
			 */
			public Point2D(double x,double y){
				coord_x=x;
				coord_y=y;
			}
			
			/**
			 * Get Coordinate x
			 * @return coord_x
			 */
			public double getCoord_x(){
				return coord_x;				
			}
			
			/**
			 * Set Coordinate x
			 * @param new_coordinate
			 */
			public void setCoord_x(double new_coordinate){
				coord_x=new_coordinate;				
			}
			
			/**
			 * Get Coordinate y
			 * @return coord_y
			 */
			public double getCoord_y(){
				return coord_y;				
			}
			
			/**
			 * Set Coordinate y
			 * @param new_coordinate
			 */
			public void setCoord_y(double new_coordinate){
				coord_y=new_coordinate;				
			}				

		}
		
}
