import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;


@SuppressWarnings("serial")
public class Triangle extends JPanel implements Shape {
	/**
	 * Triangle side
	 */
	private double side;
	/**
	 * Triangle x1 coordinate
	 */
	private double x;
	/**
	 * Triangle x2 coordinate
	 */
	private double x2;
	/**
	 * Triangle x3 coordinate
	 */
	private double x3;
	/**
	 * Triangle y coordinate
	 */
	private double y;
	/**
	 * Triangle y2 coordinate
	 */
	private double y2;
	/**
	 * Triangle y3 coordinate
	 */
	private double y3;
	/**
	 * Triangle area
	 */
	private static double area_t; 
	/**
	 * Triangle length
	 */
	private static double length_t;	
	
	/**
	 * default triangle class constructure
	 */
	public Triangle(){
		
	}
	/**
	 * Take side of triangle Constructure
	 * @param f_side side of Triangle
	 */
	public Triangle(double f_side)throws IllegalArgumentException{
		  if(f_side>0){
			  setSide(f_side);			
		   	  x=0;
		   	  y=(f_side*Math.sqrt(3))/2;
		   	  
		   	  x2=f_side/2;
		   	  y2=0;
		   	  
		   	  x3=f_side;
		   	  y3=(f_side*Math.sqrt(3))/2;  		  	
		  }
			else
				throw new IllegalArgumentException("Only Positive Numbers & no Letters Please!");
	}		
	
	/**
	 * take all coordinates of triangle constructure
	 * @param first		x1 coordinate
	 * @param second	y1 coordinate
	 * @param third		x2 coordinate
	 * @param fourth	y2 coordinate
	 * @param fifth		x3 coordinate	
	 * @param sixth		y3 coordinate
	 */
	public Triangle(double first,double second,double third, double fourth, double fifth,double sixth )throws IllegalArgumentException{
		if(first<0 || second <0 || third<0 || fourth<0 || fifth<0 || sixth<0)
			throw new IllegalArgumentException("Only Positive Numbers & no Letters Please!");
		x=first;
		y=second;
		x2=third;
		y2=fourth;
		x3=fifth;
		y3=sixth;		
	}	
	
	/**
	 * take all coordinates and side triangle constructure
	 * @param first		x1 coorcinate
	 * @param second	y1 coordinate
	 * @param third		x2 coordinate
	 * @param fourth	y2 coordinate
	 * @param fifth		x3 coordinate
	 * @param sixth		y3 coordinate	
	 * @param side_t	side of triangle
	 */
	public Triangle(double first,double second,double third, double fourth, double fifth,double sixth,double side_t )throws IllegalArgumentException{
		if(side_t>0){
			x=first;	
			y=second;
			x2=third;
			y2=fourth;
			x3=fifth;
			y3=sixth;
			side=side_t;
			area_t+=(side*side*Math.sqrt(3))/4;
			length_t+=3*side;				
		}
		else
			throw new IllegalArgumentException("Only Positive Numbers & no Letters Please!");
	}	
	
	/**
	 * Calculate and return triangle area
	 * @return area return triangle area
	 */
	public double area(){
		double area;
		area=(side*side*Math.sqrt(3))/4;
		return area;
	}
	
	/**
	 * Calculate and return triangle perimeter
	 * @return perimeter_lengtth return triangle perimeter length
	 */
	public double perimeter(){
		double perimeter_length;
		perimeter_length=3*side;
		return perimeter_length;		
	}
	
	/**
	 * triangle coordinate increment 1
	 * @return this return itself
	 */
	public Triangle increment(){
		x+=1;	//helper funcitons
		y+=1;
		x2+=1;
		y2+=1;
		x3+=1;
		y3+=1;
		return this;	/*return adding 1 coordinates value */		
	}
	
	/**
	 * triangle coordinate decrement 1
	 * @return this return itself
	 */
	public Triangle decrement(){
		x-=1;	//helper funcitons
		y-=1;
		x2-=1;
		y2-=1;
		x3-=1;
		y3-=1;
		return this;	/*return subbed 1 coordinates value */		
	}
	
	/**
	 * draw triangle in panel
	 * @param Obje Graphic object for draw with gui
	 */
	public void draw(Graphics Obje){
		Obje.setColor(Color.BLUE);						
		Obje.fillPolygon(new int[] { ((int)getPosition_x()), ((int)getPosition_x2()), ((int)getPosition_x3())}, new int[] {((int)getPosition_y()), ((int)getPosition_y2()), ((int)getPosition_y3())}, 3);
		
	}
	
	/**
	 * override JPanel method for called draw method 
	 * @param Obje Graphic object for draw with gui
	 */
	public void paintComponent(Graphics Obje){
		super.paintComponent(Obje);
		draw(Obje);

	}	
	
	/**
	 * get side for triangle objes for another class or methods which in not this class
	 * @return side triangle side
	 */
	public double getSide(){
		return side;		
	}
	
	/**
	 * set side for triangle objes for another class or methods which in not this class
	 * @param side_t new triangle side
	 */
	public void setSide(double side_t){
		side=side_t;		
	}
	
	/**
	 * get coordinate x1 for triangle objes for another class or methods which in not this class
	 * @return x coordinate of x1
	 */
	public double getPosition_x(){
		return x;
	}
	
	/**
	 * set coordinate x1 for triangle objes for another class or methods which in not this class
	 * @param x_koordinat new coordinate x1
	 */
	public void setPosition_x(double x_koordinat){
		x=x_koordinat;
	}
	
	/**
	 * get coordinate y1 for triangle objes for another class or methods which in not this class
	 * @return y coordinate
	 */
	public double getPosition_y(){
		return y;
	}		
	
	/**
	 * set y1 for triangle objes for another class or methods which in not this class
	 * @param y_koordinat new y1 coordinate
	 */
	public void setPosition_y(double y_koordinat){
		y=y_koordinat;
	}
	
	/**
	 * get x2 for triangle objes for another class or methods which in not this class
	 * @return x2 coordinate of x2
	 */
	public double getPosition_x2(){
		return x2;
	}
	
	/**
	 * set x2 for triangle objes for another class or methods which in not this class
	 * @param x_koordinat new x2 coordinate
	 */
	public void setPosition_x2(double x_koordinat){
		x2=x_koordinat;
	}
	
	/**
	 * get y2 for triangle objes for another class or methods which in not this class
	 * @return y2 coordinate of y2
	 */
	public double getPosition_y2(){
		return y2;
	}	
	
	/**
	 * set y2 for triangle objes for another class or methods which in not this class
	 * @param y_koordinat new y2 coordinate
	 */
	public void setPosition_y2(double y_koordinat){
		y2=y_koordinat;
	}
	
	/**
	 * get x3 for triangle objes for another class or methods which in not this class
	 * @return x3 coordinate of x3
	 */
	public double getPosition_x3(){
		return x3;
	}
	
	/**
	 * set x3 for triangle objes for another class or methods which in not this class
	 * @param x_koordinat new x3 coordinate
	 */
	public void setPosition_x3(double x_koordinat){
		x3=x_koordinat;
	}
	
	/**
	 * get y3 for triangle objes for another class or methods which in not this class
	 * @return y3 coordinate of y3
	 */
	public double getPosition_y3(){
		return y3;
	}			
	
	/**
	 * set y3 for triangle objes for another class or methods which in not this class
	 * @param y_koordinat coordinate of y3
	 */
	public void setPosition_y3(double y_koordinat){
		y3=y_koordinat;
	}		
	
	/** 
	 * @return area_t return static area of class 
	 */
	public static double total_areas(){
		return area_t;
	}
	
	/**
	 * @return length_t return static perimeter_length of class
	 */
	public static double perimeter_length(){
		return length_t;
	}

	/**
	 * Compare areas triangle with shape elements
	 * @param object Shape elements
	 */
	@Override
	public int compareTo(Shape object) {
		if(this.area()==object.area())
			return 1;
		return 0;
	}
	

	
}
