

public interface List<E> extends Collection<E>{

}
