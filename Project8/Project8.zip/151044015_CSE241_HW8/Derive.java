

public class Derive{
	public static void main(String[] arg){
		try{
		System.out.printf("\n------------ArrayList String------------\n");	
		Object[] string_list_array1={"Taylan","GTÜ","Selam"};
		Object[] string_list_array2={"Taylan","Saglık","Huzur"};		
		ArrayList list_set1=new ArrayList(string_list_array1);
		list_set1.add("Hello");
		Object [] temp_list_string=list_set1.get_collection();
		Iterator iterate= new Iterator (temp_list_string);	
		int i=0;
		System.out.printf("Add method --->    ");		
		while(iterate.hasNext()){
			System.out.printf("%s ",iterate.next());
		}
		System.out.printf("\n");	
		
		
		list_set1.addAll(string_list_array2);
		temp_list_string=list_set1.get_collection();
		iterate= new Iterator (temp_list_string);	
		i=0;
		System.out.printf("AddAll method --->    ");				
		while(iterate.hasNext()){
			System.out.printf("%s ",iterate.next());
		}
		System.out.printf("\n");	
		System.out.printf("Contain method --->    ");				
		if(list_set1.contains("Saglık")){
			System.out.printf("Include Element\n");
		}
		else{
			System.out.printf("Not include Element\n");			
		}
		if(list_set1.contains("Yok")){
			System.out.printf("Include Element\n");
		}
		else{
			System.out.printf("Not include Element\n");			
		}
		
		System.out.printf("ContainsAll method --->    ");						
		if(list_set1.containsAll(string_list_array2)){
			System.out.printf("Contains All Element\n");
		}
		else{
			System.out.printf("Not Contains All Element\n");			
		}	
		System.out.printf("Remove method --->    ");				
		
		list_set1.remove("Saglık");	
		temp_list_string=list_set1.get_collection();
		iterate= new Iterator (temp_list_string);	
		i=0;
		while(iterate.hasNext()){
			System.out.printf("%s ",iterate.next());
		}
		System.out.printf("\n");	
		
		System.out.printf("RemoveAll method --->    ");				
	
		list_set1.removeAll(string_list_array1);
		temp_list_string=list_set1.get_collection();
		iterate= new Iterator (temp_list_string);	
		i=0;
		while(iterate.hasNext()){
			System.out.printf("%s ",iterate.next());
		}
		System.out.printf("\n");	
		
		System.out.printf("RetainAll method --->    ");				
	
		list_set1.retainAll(string_list_array2);
		temp_list_string=list_set1.get_collection();
		iterate= new Iterator (temp_list_string);	
		i=0;
		while(iterate.hasNext()){
			System.out.printf("%s ",iterate.next());
		}
		System.out.printf("\n");			
		System.out.printf("Size method --->    %d \n",list_set1.size());
		System.out.printf("-----Clear and isEmpty methods----- \n");				
		System.out.printf("Before Clear function collection  :");					
		if(list_set1.isEmpty()){
			System.out.printf("Empty \n");
		}
		else{
			System.out.printf("Not Empty \n");			
		}		
		list_set1.clear();
		temp_list_string=list_set1.get_collection();
		iterate= new Iterator (temp_list_string);	
		System.out.printf("After Clear function elements :");	
		while(iterate.hasNext()){
			System.out.printf(" %s ",iterate.next());
		}	
		System.out.printf("\nAfter Clear function collection  :");			
		if(list_set1.isEmpty()){
			System.out.printf("Empty \n");
		}
		else{
			System.out.printf("Not Empty \n");			
		}
		if(list_set1.containsAll(string_list_array2)){
			System.out.printf("Contains All Element\n");
		}
		else{
			System.out.printf("Not Contains All Element\n");			
		}		
		
//-----------------------------LinkedList String--------------------------------		
		System.out.printf("\n------------LinkedList String------------\n");	
		
		Object[] string_linked_list_array1={"Taylan","GTÜ","Selam"};
		Object[] string_linked_list_array2={"Taylan","Saglık","Huzur"};		
		LinkedList linked_list_set1=new LinkedList(string_linked_list_array1);
		//Iterator<E> Collection= new Iterator<E> (C_element);
		linked_list_set1.add("Hello");
		Object [] temp_linked_list_string=linked_list_set1.get_collection();
		iterate= new Iterator (temp_linked_list_string);	
		i=0;
		System.out.printf("Add method --->    ");		
		while(iterate.hasNext()){
			System.out.printf("%s ",iterate.next());
		}
		System.out.printf("\n");	
		
		
		linked_list_set1.addAll(string_linked_list_array2);
		temp_linked_list_string=linked_list_set1.get_collection();
		iterate= new Iterator (temp_linked_list_string);	
		i=0;
		System.out.printf("AddAll method --->    ");						
		while(iterate.hasNext()){
			System.out.printf("%s ",iterate.next());
		}
		System.out.printf("\n");	
		System.out.printf("Contain method --->    ");					
		if(linked_list_set1.contains("Saglık")){
			System.out.printf("Include Element\n");
		}
		else{
			System.out.printf("Not include Element\n");			
		}
		if(linked_list_set1.contains("Yok")){
			System.out.printf("Include Element\n");
		}
		else{
			System.out.printf("Not include Element\n");			
		}
		
		System.out.printf("ContainsAll method --->    ");							
		if(linked_list_set1.containsAll(string_linked_list_array2)){
			System.out.printf("Contains All Element\n");
		}
		else{
			System.out.printf("Not Contains All Element\n");			
		}		
		
		System.out.printf("Offer method --->    ");				
		linked_list_set1.offer("Son");
		temp_linked_list_string=linked_list_set1.get_collection();
		iterate= new Iterator (temp_linked_list_string);	
		i=0;
		while(iterate.hasNext()){
			System.out.printf("%s ",iterate.next());
		}
		System.out.printf("\n");	

		System.out.printf("Element method --->    %s\n",linked_list_set1.element());
		temp_linked_list_string=linked_list_set1.get_collection();
		iterate= new Iterator (temp_linked_list_string);	
		i=0;
		System.out.printf("Collection --->    ");		
		while(iterate.hasNext()){
			System.out.printf("%s ",iterate.next());
		}			
		System.out.printf("\nPoll method --->    %s\n",linked_list_set1.poll());
		temp_linked_list_string=linked_list_set1.get_collection();
		iterate= new Iterator (temp_linked_list_string);	
		i=0;
		System.out.printf("Collection --->    ");				
		while(iterate.hasNext()){
			System.out.printf("%s ",iterate.next());
		}		
		System.out.printf("\nRemove method --->    ");				
		
		linked_list_set1.remove("Saglık");	
		temp_linked_list_string=linked_list_set1.get_collection();
		iterate= new Iterator (temp_linked_list_string);	
		i=0;
		while(iterate.hasNext()){
			System.out.printf("%s ",iterate.next());
		}
		System.out.printf("\n");	
		
		System.out.printf("RemoveAll method --->    ");					
		linked_list_set1.removeAll(string_linked_list_array1);
		temp_linked_list_string=linked_list_set1.get_collection();
		iterate= new Iterator (temp_linked_list_string);	
		i=0;
		while(iterate.hasNext()){
			System.out.printf("%s ",iterate.next());
		}
		System.out.printf("\n");	
		
		System.out.printf("RetainAll method --->    ");					
		linked_list_set1.retainAll(string_linked_list_array2);
		temp_linked_list_string=linked_list_set1.get_collection();
		iterate= new Iterator (temp_linked_list_string);	
		i=0;
		while(iterate.hasNext()){
			System.out.printf("%s ",iterate.next());
		}
		System.out.printf("\n");			
		System.out.printf("Size method --->    %d \n",linked_list_set1.size());			
		System.out.printf("-----Clear and isEmpty methods----- \n");				

		System.out.printf("Before Clear function collection  :");					
		if(linked_list_set1.isEmpty()){
			System.out.printf("Empty \n");
		}
		else{
			System.out.printf("Not Empty \n");			
		}		
		linked_list_set1.clear();
		temp_linked_list_string=linked_list_set1.get_collection();
		iterate= new Iterator (temp_linked_list_string);	
		System.out.printf("After Clear function elements :");	
		while(iterate.hasNext()){
			System.out.printf(" %s ",iterate.next());
		}	
		System.out.printf("\nAfter Clear function collection  :");			
		if(linked_list_set1.isEmpty()){
			System.out.printf("Empty \n");
		}
		else{
			System.out.printf("Not Empty \n");			
		}
		
		
		
		//-----------------------------HashSet String--------------------------------		
				System.out.printf("\n------------HashSet String------------\n");			
		
		Object[] string_hash_set_array1={"Taylan","GTÜ","Selam"};
		Object[] string_hash_set_array2={"Taylan","Saglık","Huzur"};		
		HashSet hash_set_set1=new HashSet(string_hash_set_array1);
		//Iterator<E> Collection= new Iterator<E> (C_element);
		hash_set_set1.add("Hello");
		Object [] temp_hash_set_string=hash_set_set1.get_collection();
		iterate= new Iterator (temp_hash_set_string);	
		i=0;
		System.out.printf("Add method --->    ");		
		while(iterate.hasNext()){
			System.out.printf("%s ",iterate.next());
		}
		System.out.printf("\n");	
		
		
		hash_set_set1.addAll(string_hash_set_array2);
		temp_hash_set_string=hash_set_set1.get_collection();
		iterate= new Iterator (temp_hash_set_string);	
		i=0;
		System.out.printf("AddAll method --->    ");						
		while(iterate.hasNext()){
			System.out.printf("%s ",iterate.next());
		}
		System.out.printf("\n");	
		System.out.printf("Contain method --->    ");				
		
		if(hash_set_set1.contains("Saglık")){
			System.out.printf("Include Element\n");
		}
		else{
			System.out.printf("Not include Element\n");			
		}
		if(hash_set_set1.contains("Yok")){
			System.out.printf("Include Element\n");
		}
		else{
			System.out.printf("Not include Element\n");			
		}
		
		System.out.printf("ContainsAll method --->    ");								
		if(hash_set_set1.containsAll(string_hash_set_array2)){
			System.out.printf("Contains All Element\n");
		}
		else{
			System.out.printf("Not Contains All Element\n");			
		}
		
		System.out.printf("Remove method --->    ");					
		hash_set_set1.remove("Saglık");	
		temp_hash_set_string=hash_set_set1.get_collection();
		iterate= new Iterator (temp_hash_set_string);	
		i=0;
		while(iterate.hasNext()){
			System.out.printf("%s ",iterate.next());
		}
		System.out.printf("\n");	
		
		System.out.printf("RemoveAll method --->    ");					
		hash_set_set1.removeAll(string_hash_set_array1);
		temp_hash_set_string=hash_set_set1.get_collection();
		iterate= new Iterator (temp_hash_set_string);	
		i=0;
		while(iterate.hasNext()){
			System.out.printf("%s ",iterate.next());
		}
		System.out.printf("\n");	
		
		System.out.printf("RetainAll method --->    ");						
		hash_set_set1.retainAll(string_hash_set_array2);
		temp_hash_set_string=hash_set_set1.get_collection();
		iterate= new Iterator (temp_hash_set_string);	
		i=0;
		while(iterate.hasNext()){
			System.out.printf("%s ",iterate.next());
		}
		System.out.printf("\n");			
		System.out.printf("Size method --->    %d \n",hash_set_set1.size());		
		System.out.printf("-----Clear and isEmpty methods----- \n");				

		
		System.out.printf("Before Clear function collection  :");					
		if(hash_set_set1.isEmpty()){
			System.out.printf("Empty \n");
		}
		else{
			System.out.printf("Not Empty \n");			
		}		
		hash_set_set1.clear();
		temp_hash_set_string=hash_set_set1.get_collection();
		iterate= new Iterator (temp_hash_set_string);	
		System.out.printf("After Clear function elements :");	
		while(iterate.hasNext()){
			System.out.printf(" %s ",iterate.next());
		}	
		System.out.printf("\nAfter Clear function collection  :");			
		if(hash_set_set1.isEmpty()){
			System.out.printf("Empty \n");
		}
		else{
			System.out.printf("Not Empty \n");			
		}
		
		
		//-----------------------------HashSet int--------------------------------		
		System.out.printf("\n------------HashSet Int------------\n");	
		
		Object[] int_hash_set_array1={10,100,30,45,3,12,5,7};
		Object[] int_hash_set_array2={3,5,9,45,12,44,56};		
		HashSet hash_set_set1_int=new HashSet(int_hash_set_array1);
		//Iterator<E> Collection= new Iterator<E> (C_element);
		hash_set_set1_int.add(5);
		Object [] temp_hash_set_int=hash_set_set1_int.get_collection();
		iterate= new Iterator (temp_hash_set_int);	
		i=0;
		System.out.printf("Add method --->    ");		
		while(iterate.hasNext()){
			System.out.printf("%d ",iterate.next());
		}
		System.out.printf("\n");	
		
		
		hash_set_set1_int.addAll(int_hash_set_array2);
		temp_hash_set_int=hash_set_set1_int.get_collection();
		iterate= new Iterator (temp_hash_set_int);	
		i=0;
		System.out.printf("AddAll method --->    ");						
		while(iterate.hasNext()){
			System.out.printf("%d ",iterate.next());
		}
		System.out.printf("\n");	
		System.out.printf("Contain method --->    ");				

		
		
		if(hash_set_set1_int.contains(5)){
			System.out.printf("Include Element\n");
		}
		else{
			System.out.printf("Not include Element\n");			
		}
		if(hash_set_set1_int.contains(6)){
			System.out.printf("Include Element\n");
		}
		else{
			System.out.printf("Not include Element\n");			
		}
		
		System.out.printf("ContainsAll method --->    ");							
		if(hash_set_set1_int.containsAll(int_hash_set_array2)){
			System.out.printf("Contains All Element\n");
		}
		else{
			System.out.printf("Not Contains All Element\n");			
		}
		
		System.out.printf("Remove method --->    ");						
		hash_set_set1_int.remove(45);	
		temp_hash_set_int=hash_set_set1_int.get_collection();
		iterate= new Iterator (temp_hash_set_int);	
		i=0;
		while(iterate.hasNext()){
			System.out.printf("%d ",iterate.next());
		}
		System.out.printf("\n");	
		
		System.out.printf("RemoveAll method --->    ");					
		hash_set_set1_int.removeAll(int_hash_set_array1);
		temp_hash_set_int=hash_set_set1_int.get_collection();
		iterate= new Iterator (temp_hash_set_int);	
		i=0;
		while(iterate.hasNext()){
			System.out.printf("%d ",iterate.next());
		}
		System.out.printf("\n");	
		
		System.out.printf("RetainAll method --->    ");						
		hash_set_set1_int.retainAll(int_hash_set_array2);
		temp_hash_set_int=hash_set_set1_int.get_collection();
		iterate= new Iterator (temp_hash_set_int);	
		i=0;
		while(iterate.hasNext()){
			System.out.printf("%d ",iterate.next());
		}
		System.out.printf("\n");			
		System.out.printf("Size method --->    %d \n",hash_set_set1_int.size());	
		System.out.printf("-----Clear and isEmpty methods----- \n");				

		System.out.printf("Before Clear function collection  :");					
		if(hash_set_set1.isEmpty()){
			System.out.printf("Empty \n");
		}
		else{
			System.out.printf("Not Empty \n");			
		}		
		hash_set_set1.clear();
		temp_hash_set_int=hash_set_set1.get_collection();
		iterate= new Iterator (temp_hash_set_int);	
		System.out.printf("After Clear function elements :");	
		while(iterate.hasNext()){
			System.out.printf(" %d ",iterate.next());
		}	
		System.out.printf("\nAfter Clear function collection  :");			
		if(hash_set_set1.isEmpty()){
			System.out.printf("Empty \n");
		}
		else{
			System.out.printf("Not Empty \n");			
		}
		
		
		//-----------------------------ArrayList int--------------------------------		
		System.out.printf("\n------------ArrayList Int------------\n");			
		
		Object[] int_array_list_array1={10,100,30,45,3,12,5,7};
		Object[] int_array_list_array2={3,5,9,45,12,44,56};		
		ArrayList array_list_set1_int=new ArrayList(int_array_list_array1);
		//Iterator<E> Collection= new Iterator<E> (C_element);
		array_list_set1_int.add(5);
		Object [] temp_array_list_int=array_list_set1_int.get_collection();
		iterate= new Iterator (temp_array_list_int);	
		i=0;
		System.out.printf("Add method --->    ");		
		while(iterate.hasNext()){
			System.out.printf("%d ",iterate.next());
		}
		System.out.printf("\n");	
		
		
		array_list_set1_int.addAll(int_array_list_array2);
		temp_array_list_int=array_list_set1_int.get_collection();
		iterate= new Iterator (temp_array_list_int);	
		i=0;
		System.out.printf("AddAll method --->    ");						
		while(iterate.hasNext()){
			System.out.printf("%d ",iterate.next());
		}
		System.out.printf("\n");	
		System.out.printf("Contain method --->    ");				
	
		if(array_list_set1_int.contains(5)){
			System.out.printf("Include Element\n");
		}
		else{
			System.out.printf("Not include Element\n");			
		}
		if(array_list_set1_int.contains(6)){
			System.out.printf("Include Element\n");
		}
		else{
			System.out.printf("Not include Element\n");			
		}
		
		System.out.printf("ContainsAll method --->    ");							
		if(array_list_set1_int.containsAll(int_array_list_array2)){
			System.out.printf("Contains All Element\n");
		}
		else{
			System.out.printf("Not Contains All Element\n");			
		}	
		
		System.out.printf("Remove method --->    ");					
		array_list_set1_int.remove(45);	
		temp_array_list_int=array_list_set1_int.get_collection();
		iterate= new Iterator (temp_array_list_int);	
		i=0;
		while(iterate.hasNext()){
			System.out.printf("%d ",iterate.next());
		}
		System.out.printf("\n");	
		
		System.out.printf("RemoveAll method --->    ");					
		array_list_set1_int.removeAll(int_array_list_array1);
		temp_array_list_int=array_list_set1_int.get_collection();
		iterate= new Iterator (temp_array_list_int);	
		i=0;
		while(iterate.hasNext()){
			System.out.printf("%d ",iterate.next());
		}
		System.out.printf("\n");	
		
		System.out.printf("RetainAll method --->    ");					
		array_list_set1_int.retainAll(int_array_list_array2);
		temp_array_list_int=array_list_set1_int.get_collection();
		iterate= new Iterator (temp_array_list_int);	
		i=0;
		while(iterate.hasNext()){
			System.out.printf("%d ",iterate.next());
		}
		System.out.printf("\n");			
		System.out.printf("Size method --->    %d \n",array_list_set1_int.size());	
		System.out.printf("-----Clear and isEmpty methods----- \n");				
		
		System.out.printf("Before Clear function collection  :");					
		if(array_list_set1_int.isEmpty()){
			System.out.printf("Empty \n");
		}
		else{
			System.out.printf("Not Empty \n");			
		}		
		array_list_set1_int.clear();
		temp_array_list_int=array_list_set1_int.get_collection();
		iterate= new Iterator (temp_hash_set_int);	
		System.out.printf("After Clear function elements :");	
		while(iterate.hasNext()){
			System.out.printf(" %d ",iterate.next());
		}	
		System.out.printf("\nAfter Clear function collection  :");			
		if(array_list_set1_int.isEmpty()){
			System.out.printf("Empty \n");
		}
		else{
			System.out.printf("Not Empty \n");			
		}
		
		
		//-----------------------------LinkedList int--------------------------------		
		System.out.printf("\n------------LinkedList Int------------\n");		
		
		
		Object[] int_linked_list_array1={10,100,30,45,3,12,5,7};
		Object[] int_linked_list_array2={3,5,9,45,12,44,56};		
		LinkedList linked_list_set1_int=new LinkedList(int_linked_list_array1);
		//Iterator<E> Collection= new Iterator<E> (C_element);
		linked_list_set1_int.add(5);
		Object [] temp_linked_list_int=linked_list_set1_int.get_collection();
		iterate= new Iterator (temp_linked_list_int);	
		i=0;
		System.out.printf("Add method --->    ");		
		while(iterate.hasNext()){
			System.out.printf("%d ",iterate.next());
		}
		System.out.printf("\n");	
		
		
		linked_list_set1_int.addAll(int_linked_list_array2);
		temp_linked_list_int=linked_list_set1_int.get_collection();
		iterate= new Iterator (temp_linked_list_int);	
		i=0;
		System.out.printf("AddAll method --->    ");						
		while(iterate.hasNext()){
			System.out.printf("%d ",iterate.next());
		}
		System.out.printf("\n");	
		System.out.printf("Contain method --->    ");				

		if(linked_list_set1_int.contains(5)){
			System.out.printf("Include Element\n");
		}
		else{
			System.out.printf("Not include Element\n");			
		}
		if(linked_list_set1_int.contains(6)){
			System.out.printf("Include Element\n");
		}
		else{
			System.out.printf("Not include Element\n");			
		}
		
		System.out.printf("ContainsAll method --->    ");							
		if(linked_list_set1_int.containsAll(int_linked_list_array2)){
			System.out.printf("Contains All Element\n");
		}
		else{
			System.out.printf("Not Contains All Element\n");			
		}			

		System.out.printf("Offer method --->    ");				
		linked_list_set1_int.offer(1000);
		temp_linked_list_int=linked_list_set1_int.get_collection();
		iterate= new Iterator (temp_linked_list_int);	
		i=0;
		while(iterate.hasNext()){
			System.out.printf("%d ",iterate.next());
		}
		System.out.printf("\n");	

		System.out.printf("Element method --->    %d\n",linked_list_set1_int.element());
		temp_linked_list_int=linked_list_set1_int.get_collection();
		iterate= new Iterator (temp_linked_list_int);	
		i=0;
		System.out.printf("Collection --->    ");		
		while(iterate.hasNext()){
			System.out.printf("%d ",iterate.next());
		}			
		System.out.printf("\nPoll method --->    %d\n",linked_list_set1_int.poll());
		temp_linked_list_int=linked_list_set1_int.get_collection();
		iterate= new Iterator (temp_linked_list_int);	
		i=0;
		System.out.printf("Collection --->    ");				
		while(iterate.hasNext()){
			System.out.printf("%d ",iterate.next());
		}		
		System.out.printf("\nRemove method --->    ");				
				
		
		linked_list_set1_int.remove(45);	
		temp_linked_list_int=linked_list_set1_int.get_collection();
		iterate= new Iterator (temp_linked_list_int);	
		i=0;
		while(iterate.hasNext()){
			System.out.printf("%d ",iterate.next());
		}
		System.out.printf("\n");	
		
		System.out.printf("RemoveAll method --->    ");					
		linked_list_set1_int.removeAll(int_linked_list_array1);
		temp_linked_list_int=linked_list_set1_int.get_collection();
		iterate= new Iterator (temp_linked_list_int);	
		i=0;
		while(iterate.hasNext()){
			System.out.printf("%d ",iterate.next());
		}
		System.out.printf("\n");	
		
		System.out.printf("RetainAll method --->    ");					
		linked_list_set1_int.retainAll(int_linked_list_array2);
		temp_linked_list_int=linked_list_set1_int.get_collection();
		iterate= new Iterator (temp_linked_list_int);	
		i=0;
		while(iterate.hasNext()){
			System.out.printf("%d ",iterate.next());
		}
		System.out.printf("\n");			
		System.out.printf("Size method --->    %d \n",linked_list_set1_int.size());
		System.out.printf("-----Clear and isEmpty methods----- \n");				
	
		
		System.out.printf("Before Clear function collection  :");					
		if(linked_list_set1_int.isEmpty()){
			System.out.printf("Empty \n");
		}
		else{
			System.out.printf("Not Empty \n");			
		}		
		linked_list_set1_int.clear();
		temp_linked_list_int=linked_list_set1_int.get_collection();
		iterate= new Iterator (temp_linked_list_int);	
		System.out.printf("After Clear function elements :");	
		while(iterate.hasNext()){
			System.out.printf(" %d ",iterate.next());
		}	
		System.out.printf("\nAfter Clear function collection  :");			
		if(linked_list_set1_int.isEmpty()){
			System.out.printf("Empty \n");
		}
		else{
			System.out.printf("Not Empty \n");			
		}
		System.out.printf("Exception situaiton IllegalArgument \n");			
		linked_list_set1_int.clear();
		linked_list_set1_int.poll();		
	}
		
		catch(IllegalArgumentException i){
			System.out.printf("Exception ----> IllegalArgumentException!\n");
		}
	    catch(ArithmeticException ex) 
	    { 
	        // getMessage will print description of exception(here / by zero) 
	        System.out.println(ex.getMessage()); 
	    } 	
	    catch(NullPointerException ex) 
	    { 
	       System.out.println("Exception ----> NullPointerException..!\n");  
	    }
	}
}
