

public class Iterator<E> {
	/**
	 * generic e type collection array
	 */
	private E [] my_obje;
	
	/**
	 * gemeric e type collection array of iterator object
	 */
	private int index=-1;
	
	/**
	 * collection capacity
	 */
	private int capacity;
	
	
	
	/**
	 * iterator constructure for take array of generic type object
	 * @param obje generic type obje
	 */
	public Iterator(E[] obje){
		int i=0;

		capacity=obje.length;
		my_obje=(E[])new Object[capacity];		
		for(;i<capacity;i++){
			my_obje[i]=obje[i];
		}
		//my_obje=obje;
		
		index=-1;
		
	}
	
	/**
	 * this method for control next element null or not
	 * @return boolean true or not
	 */
	public boolean hasNext(){
		if(capacity>index+1){
			//index--;
			return true;
		}	
		return false;
	}
	
	/**
	 * this method for array index increment and return element
	 * @return my_obje[index] index of array's element
	 */
	public E next(){
		if(capacity>index+1){
			
			index++;
			return my_obje[index];			
		}
		else
			throw new IllegalArgumentException("Illegal Argument didn't access this element");

	}

	/**
	 * remove the last element of array
	 */
	@SuppressWarnings("unchecked")
	public void remove(){
		int i=0;
		capacity-=1;
		E[] temp_obje=(E[])new Object[capacity];		
		for(;i<capacity;i++){
			temp_obje[i]=my_obje[i];
		}		
		my_obje=(E[])new Object[capacity];
		my_obje=temp_obje;
	}
	
	/**
	 * @return my_obje private member field get method
	 */
	public E[] get_obje(){
		return my_obje;
	}
	
	/**
	 * @return capacity array's the last index get
	 */
	public int end(){
		return capacity;
	}
	
	/**
	 * return index of element 
	 * @return index array's element of index
	 */
	public int get_iter(){
		return index;
	}

	/** 
	 * @return iterator begin for array and restart index
	 */
	public int begin(){
		index=-1;
		return index;
	}
}
