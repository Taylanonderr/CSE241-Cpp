
public class ArrayList<E> implements List<E> {

		/**
		 * generic e type collection array
		 */
		private E[] set_obje;
		
		/**
		 * gemeric e type collection array of iterator object
		 */
		private Iterator<E> iterate;
		
		/**
		 * collection capacity
		 */
		private int capacity;
		
		
		
		/**
		 * ArrayList class constructure
		 * @param obje set array of need iterator
		 */	
		public ArrayList(E[] obje){
			capacity=obje.length;
			set_obje=(E[])new Object[obje.length]; 
			for(int i=0;i<obje.length;i++){
				set_obje[i]=obje[i];
			}
			//System.out.print(set_obje);
		}	
		
		/**
		 * add element in collection 
		 * @param element generic e type element
		 */
		public void add(E element){		//add specified element in collection
			int i=0;
				capacity=set_obje.length;
				E[] temp=(E[]) new Object[capacity+1]; 
				for(;i<set_obje.length;i++){
					temp[i]=set_obje[i];
				}
				temp[i]=element;
				set_obje=(E[]) new Object[capacity+1];
				set_obje=temp;
			
			
		}

		
		/**
		 * addAll element in collections element 
		 * @param C_element generic e type array
		 */
		public void addAll(E[] C_element){		//	Adds all of the elements in the specified collection to this collection
			int flag=0;

			iterate=iterator();
			Iterator<E> Collection= new Iterator<E> (C_element);
			E element=(E) new Object(); 
			E specified=(E) new Object(); 				

			while(Collection.hasNext()){
				element=Collection.next();
				flag=0;			
				while(iterate.hasNext()){
					specified=(E) new Object();
					specified=iterate.next();
				}
				this.add(element);
				iterate=new Iterator<E>(set_obje);
			}		
		}


		/**
		 * clear of iterator obje and collection array
		 */
		public void clear(){				//clear collection elements
			iterate=iterator();
			while(iterate.begin()!=iterate.get_iter()){
				iterate.remove();
			}
			set_obje=(E[]) new Object[1];		
		}


		/**
		 * generic e type element include colection or not
		 * @param element generic e type element
		 * @return boolean true or false
		 */
		public boolean contains(E element){		//check for same element in a collection if collection has same element return true,if has not same elemnt return false
			iterate=new Iterator<E>(set_obje);		
			while(iterate.hasNext()){			//check with iterator class functions base condition
				if(element==iterate.next()){
					return true;
				}
			}
			return false;			
		}

		/**
		 * generic e type array elements all of them include colection or not
		 * @param C_element array generic e type array
		 *  @return boolean true or false
		 */
		public boolean containsAll(E[] C_element){	//Returns true if this collection contains all of the elements in the specified collection.
			int flag=0;
			iterate=iterator();
			Iterator<E> Collection= new Iterator<E> (C_element);
			int iter=iterate.begin();
			int iter_collection=Collection.begin();
			while(Collection.hasNext()){
				E element=Collection.next();
				while(iterate.hasNext()){				
					if(element==iterate.next()){
						flag=1;
					}
				}

				if(flag==0){					
					return false;		//this concidition for collection does not have any element of container 
				}
				iterate.begin();
				flag=0;
			}
			return true;				
		}

		
		/**
		 * check collection empty or not
		 * return boolean true or false
		 */
		public boolean isEmpty(){		//Returns true if this collection contains no elements.
			iterate=iterator();
			if(iterate.next()==null)
				return true;
			return false;
		}

		/**
		 * remove elements in collection E type generic element if it include
		 * @param e generic e type element
		 */
		public void remove(E e){		//remove(E e) Removes a single instance of the specified element from this collection, if it is present
			iterate=iterator();
			int counter=0;
			E[] temp=(E[]) new Object[set_obje.length];
			E element=(E) new Object(); 
			
			while(iterate.hasNext()){  	//check with iterator class functions base condition returns true if the iteration has more elements.
				element=iterate.next();
				if(e!=element){
					temp[counter]=element;
					counter++;				
				}			
			}	
			set_obje=(E[]) new Object[counter];
			for(int i=0;i<counter;i++){
				set_obje[i]=temp[i];		
			}
				
		}

		/**
		 * Removes all of this collection's elements that are also contained in the specified collection
		 * @param C_element array generic e type array
		 */
		public void removeAll(E[] C_element){	//Removes all of this collection's elements that are also contained in the specified collection
			int flag=0;
			iterate=iterator();
			Iterator<E> Collection= new Iterator<E> (C_element);
			E element=(E)new Object();
			while(Collection.hasNext()){				//check with iterator class functions returns true if the iteration has more elements in collection.
				if(flag==0){
					element=Collection.next();
				}
				flag=0;
				while(iterate.hasNext()){				//check with iterator class functions returns true if the iteration has more elements in specified collection.
					if(element==iterate.next()){				
						flag=1;		//it won't erase
					}	
				}
				if(flag==1){	
					this.remove(element);
				}
				iterate.begin();
			}
			
		}

		
		/**
		 * Retains only the elements in this collection that are contained in the specified Collection
		 * @param C_element array generic e type array
		 */
		public void retainAll(E[] C_element){		//Retains only the elements in this collection that are contained in the specified Collection
			int flag=0;
			int counter=0;
			E[] temp=(E[]) new Object[set_obje.length];	
			iterate=iterator();
			Iterator<E> Collection= new Iterator<E> (C_element);
			E element=(E)new Object();
			E element2=(E)new Object();	
			while(Collection.hasNext()){				//check with iterator class functions returns true if the iteration has more elements in collection.
				element=Collection.next();
				flag=0;
				while(iterate.hasNext()){  	//check with iterator class functions base condition returns true if the iteration has more elements.
					element2=(E)new Object();
					element2=iterate.next();
					if(element2==element){
						flag=1;
					}
				}	
				if(flag==1){
					temp[counter]=element;
					counter++;				
				}			
				iterate.begin();
			}
			set_obje=(E[]) new Object[counter];
			for(int i=0;i<counter;i++){
				set_obje[i]=temp[i];		
			}			
		}

		
		/**
		 * Returns the number of elements in this collection.
		 * @return size 
		 */
		public int size(){			//Returns the number of elements in this collection.																									
			int counter=1;
			iterate=iterator();
			iterate.next();
			while(iterate.hasNext()){			//check with iterator class functions base condition
				counter++;
				iterate.next();
			}
			return counter;				
		}

		
		/**
		 * new iterator creating for collectiob
		 * @return iteration class object
		 */
		public Iterator<E> iterator(){
			Iterator<E> iter=new Iterator<E> (set_obje);
			return iter;
		}

		
		/**
		 * get collection
		 * @return collection
		 */
		public E[] get_collection(){
			return set_obje;
		}

	}


