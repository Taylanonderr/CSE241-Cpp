

public interface Set<E> extends Collection<E> {

}
