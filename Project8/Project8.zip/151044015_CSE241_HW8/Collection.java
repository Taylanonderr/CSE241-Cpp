

public interface Collection<E> {

	//public Collection();
	public Iterator<E> iterator();
	public void add(E element);
	public void addAll(E[] C_element);
	public void clear();
	public boolean contains(E element);
	public boolean containsAll(E[] C_element);
	public boolean isEmpty();
	public void remove(E e);
	public void removeAll(E[] C_element);
	public void retainAll(E[] C_element);
	public int size();
}
