#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <vector>
#include "composedshape.h"
#include "rectangle.h"
#include "circle.h"
#include "triangle.h"
using namespace std;


int main(){
	int i=0,r=0,t=0,c=0;
	double width,height;
	double radius,side,small_side,s_radius,small_width,small_height;
	ComposedShape test;
	ComposedShape::ShapeElem objeee;	/*for testing*/
	vector<ComposedShape::ShapeElem> test_v;
	string file[10];	/*for output filenames*/
	char choose[9][2],second_choose[9][2];		
	rectangle	rect_obj[1];	/*this array for main conventer*/
	rectangle	small_rect_obj[3];	/*this array obje for small shapes using in loop*/
	triangle tri_obj[1];	/*this array for main conventer*/
	triangle small_tri_obj[3];	/*this array obje for small shapes using in loop*/	
	circle	circ_obj[1];	/*this array for main conventer*/
	circle	small_circ_obj[3];	/*this array obje for small shapes using in loop*/

	rect_obj[0]=rectangle (1000.0,800.0);	/*it's for trying main rectangle obj*/
	small_rect_obj[0]=rectangle (52.0,30.0);	/*it's for trying small rectangle obj*/
	small_rect_obj[1]=rectangle (100.0,78.0);	/*it's for trying small rectangle obj*/
	small_rect_obj[2]=rectangle (80.0,70.0);	/*it's for trying small rectangle obj*/	

	tri_obj[0]=triangle (800.0);		/*it's for trying main triangle obj*/
	small_tri_obj[0]=triangle (90.0);		/*it's for trying small rectangle obj*/
	small_tri_obj[1]=triangle (56.0);		/*it's for trying small rectangle obj*/
	small_tri_obj[2]=triangle (150.0);	/*it's for trying small rectangle obj*/


	circ_obj[0]=circle (300.0);		/*it's for trying main circle obj*/
	small_circ_obj[0]=circle (82.0);		/*it's for trying small circle obj*/
	small_circ_obj[1]=circle (100.0);		/*it's for trying small circle obj*/
	small_circ_obj[2]=circle (25.0);		/*it's for trying small circle obj*/
	/*I compare two object when I didn't write anyting*/
	cout<<endl;
	if(small_rect_obj[0]==small_rect_obj[1]){		/*== operator testing*/
		cout<<"Two object is equal     --Fisrt step"<<endl;
	}
	else if(small_rect_obj[0]!=small_rect_obj[1]){		/*!= operator testing*/
		cout<<"Two object is not equal --First step "<<endl;
	}

	small_rect_obj[0]=small_rect_obj[0]+48;		/*I send a value to adding and check this area --- operator + with double*/
	cout<<"*I send a value to adding size width :"<<small_rect_obj[0].getWidth()<<"  height :  " <<small_rect_obj[0].getHeight()<<endl;

	if(small_rect_obj[0]==small_rect_obj[1]){		/*== operator testing*/
		cout<<"Two object is equal    --Second step"<<endl;
	}
	else if(small_rect_obj[0]!=small_rect_obj[1]){		/*!= operator testing*/
		cout<<"Two object is not equal--Second step"<<endl;
	}

	small_rect_obj[0]=small_rect_obj[0]-48;		/*I send a value to subbing and check this area--- operator - with double*/
	cout<<"*I send a value to subbing size width :"<<small_rect_obj[0].getWidth()<<"  height :  " <<small_rect_obj[0].getHeight()<<endl;
	if(small_rect_obj[0]>small_rect_obj[1]){
		cout<<"First obje bigger than second obje"<<endl;
	}
	else if(small_rect_obj[0]<small_rect_obj[1]){
		cout<<"First obje smaller than second obje"<<endl;
	}	
		cout<<endl;

	if(small_tri_obj[0]==small_tri_obj[1]){
		cout<<"Two object is equal "<<endl;
	}
	else if(small_tri_obj[0]!=small_tri_obj[1]){
		cout<<"Two object is not equal  "<<endl;
	}
	if(small_tri_obj[0]>small_tri_obj[1]){
		cout<<"First obje bigger than second obje"<<endl;
	}
	else if(small_tri_obj[0]<small_tri_obj[1]){
		cout<<"First obje smaller than second obje"<<endl;
	}
		cout<<endl;

	if(small_circ_obj[0]==small_circ_obj[1]){
		cout<<"Two object is equal"<<endl;
	}
	else if(small_circ_obj[0]!=small_circ_obj[1]){
		cout<<"Two object is not equal "<<endl;
	}
	if(small_circ_obj[0]>small_circ_obj[1]){
		cout<<"First obje bigger than second obje"<<endl;
	}
	else if(small_circ_obj[0]<small_circ_obj[1]){
		cout<<"First obje smaller than second obje"<<endl;
	}	
		cout<<endl;				
	objeee=ComposedShape::ShapeElem(&small_tri_obj[0]);
	cout<<"I access my ShapeElem class and print my area of object :"<<objeee.shape_area()<<endl;		/*testing ShapeElem class function*/
	cout<<"I access my ShapeElem class and print my length of object :"<<objeee.perimeter_l()<<endl<<endl;		/*testing ShapeElem class function*/

	small_rect_obj[0]++;
	cout<<"Prefix ++ koordinate x :"<<small_rect_obj[0].getPosition_x()<<"  koordinate y : "<<small_rect_obj[0].getPosition_y()<<endl;
	++small_rect_obj[0];
	cout<<"Postfix ++ koordinate x :"<<small_rect_obj[0].getPosition_x()<<"  koordinate y : "<<small_rect_obj[0].getPosition_y()<<endl;	
	small_rect_obj[0]--;
	cout<<"Prefix -- koordinate x :"<<small_rect_obj[0].getPosition_x()<<"  koordinate y : "<<small_rect_obj[0].getPosition_y()<<endl;	
	--small_rect_obj[0];
	cout<<"Postfix -- koordinate x :"<<small_rect_obj[0].getPosition_x()<<"  koordinate y : "<<small_rect_obj[0].getPosition_y()<<endl;	

/*it's for users choise*/
	choose[0][0]='r',second_choose[0][0]='r';
	choose[1][0]='r',second_choose[1][0]='t';             
	choose[2][0]='r',second_choose[2][0]='c';
	choose[3][0]='t',second_choose[3][0]='r';				
	choose[4][0]='t',second_choose[4][0]='t';				
	choose[5][0]='t',second_choose[5][0]='c';				
	choose[6][0]='c',second_choose[6][0]='r';
	choose[7][0]='c',second_choose[7][0]='t';
	choose[8][0]='c',second_choose[8][0]='c';
/*it's for nine situation different file name*/	
	file[0]="output.svg";										
	file[1]="output1.svg";
	file[2]="output2.svg";	
	file[3]="output3.svg";
	file[4]="output4.svg";
	file[5]="output5.svg";
	file[6]="output6.svg";
	file[7]="output7.svg";
	file[8]="output8.svg";

	while(i<9){		/*all of the about all situation print*/
	  	ofstream myfile;
	  	myfile.open(file[i]);	/*I open the file which get the main for many result output file */
	    myfile <<"<svg version=\"1.1\"\n\t\t"<<"baseProfile=\"full\"\n\t\t"
	    <<"xmlns=\"http://www.w3.org/2000/svg\">\n\n\t"  ;		/*it's for file svg format*/			
		if(choose[i][0]=='R' || choose[i][0]=='r'){
			if(second_choose[i][0]=='R' || second_choose[i][0]=='r'){
				ComposedShape ornek(rect_obj[0],small_rect_obj[r]);	
				myfile<<rect_obj[0];	/*rect << overload*/	
				ornek.setMainchar(choose[i][0]);	/*it's for main container choose set in composedshape class */
				ornek.setSmallchar(second_choose[i][0]);	/*it's for small shape choose set in composedshape class */
				ornek.optimalfit();		/*this class member function for draw and optimize small shapes coordinate and set in vector small shapes*/
				myfile<<ornek;	/*composedshape overload*/
				cout<<"Total area : "<<small_rect_obj[r].total_areas()<<endl;
				cout<<"Perimeter length : "<<small_rect_obj[r].perimeter_length()<<endl<<endl;								
			}
			if(second_choose[i][0]=='T' || second_choose[i][0]=='t'){
				ComposedShape  ornek(rect_obj[0],small_tri_obj[r]);
				myfile<<rect_obj[0];
				ornek.setMainchar(choose[i][0]);
				ornek.setSmallchar(second_choose[i][0]);				
				ornek.optimalfit();	
				myfile<<ornek;		/*composedshape overload*/	
			}
			if(second_choose[i][0]=='C' || second_choose[i][0]=='c'){
				ComposedShape  ornek(rect_obj[0],small_circ_obj[r]);
				myfile<<rect_obj[0];
				ornek.setMainchar(choose[i][0]);
				ornek.setSmallchar(second_choose[i][0]);					
				ornek.optimalfit();
				myfile<<ornek;		/*composedshape overload*/
			}
			r++;
		}
		
  		else if(choose[i][0]=='T' || choose[i][0]=='t'){
			if(second_choose[i][0]=='R' || second_choose[i][0]=='r'){	
				ComposedShape  ornek(tri_obj[0],small_rect_obj[t]);
				myfile<<tri_obj[0];	/*triangle << overload*/
				ornek.setMainchar(choose[i][0]);
				ornek.setSmallchar(second_choose[i][0]);				
				ornek.optimalfit();
				myfile<<ornek;		/*composedshape overload*/
			}
			else if(second_choose[i][0]=='T' || second_choose[i][0]=='t'){		
				ComposedShape  ornek(tri_obj[0],small_tri_obj[t]);
				myfile<<tri_obj[0];
				ornek.setMainchar(choose[i][0]);
				ornek.setSmallchar(second_choose[i][0]);				
				ornek.optimalfit();
				myfile<<ornek;		/*composedshape overload*/			
			}
			else if(second_choose[i][0]=='C' || second_choose[i][0]=='c'){
				ComposedShape  ornek(tri_obj[0],small_circ_obj[t]);
				myfile<<tri_obj[0];
				ornek.setMainchar(choose[i][0]);
				ornek.setSmallchar(second_choose[i][0]);				
				ornek.optimalfit();		/*composedshape overload*/			
				myfile<<ornek;
				cout<<"Total area : "<<small_circ_obj[t].total_areas()<<endl;
				cout<<"Perimeter length : "<<small_circ_obj[t].perimeter_length()<<endl<<endl;			
			}
			t++;		  	
   		} 

		else if(choose[i][0]=='C' || choose[i][0]=='c'){	
			if(second_choose[i][0]=='R' || second_choose[i][0]=='r'){
				ComposedShape  ornek(circ_obj[0],small_rect_obj[c]);
				myfile<<circ_obj[0];	/*circle << overload*/
				ornek.setMainchar(choose[i][0]);
				ornek.setSmallchar(second_choose[i][0]);				
				ornek.optimalfit();		/*composedshape overload*/			
				myfile<<ornek;
			}
			if(second_choose[i][0]=='T' || second_choose[i][0]=='t'){
				ComposedShape  ornek(circ_obj[0],small_tri_obj[c]);
				myfile<<circ_obj[0];
				ornek.setMainchar(choose[i][0]);
				ornek.setSmallchar(second_choose[i][0]);				
				ornek.optimalfit();		/*composedshape overload*/
				myfile<<ornek;	
				cout<<"Total area : "<<small_tri_obj[c].total_areas()<<endl;
				cout<<"Perimeter length : "<<small_tri_obj[c].perimeter_length()<<endl<<endl;							

			}
			if(second_choose[i][0]=='C' || second_choose[i][0]=='c'){		
				ComposedShape  ornek(	circ_obj[0],small_circ_obj[c]);
				myfile<<circ_obj[0];
				ornek.setMainchar(choose[i][0]);
				ornek.setSmallchar(second_choose[i][0]);				
				ornek.optimalfit();					
				myfile<<ornek;		/*composedshape overload*/
			}
			c++;    			
		} 
		myfile.close(); 
		i++; 				
	}	
	return 0;	
}