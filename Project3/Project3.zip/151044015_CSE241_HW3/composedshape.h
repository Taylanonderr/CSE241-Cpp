#ifndef COMPOSEDSHAPE_H_
#define COMPOSEDSHAPE_H_
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <vector>
#include "rectangle.h"
#include "circle.h"
#include "triangle.h"

using namespace std;

class ComposedShape{
	public:
		enum class shape{
			rectangle_type,
			triangle_type,
			circle_type 
		};		

		class ShapeElem{
			public:			
				ShapeElem(){}
				ShapeElem(rectangle* r_obje);
				ShapeElem(triangle* t_obje);
				ShapeElem(circle* c_obje);
				double shape_area();
				double perimeter_l();
		
				void *obje;
				shape obje_type;
				friend ostream& operator <<(ostream& outputStream, const ComposedShape::ShapeElem& obje);	
			private:
		};		

		ComposedShape();
		ComposedShape(rectangle &shape,rectangle &small_shape);	/*this constructor for main container rectangle and small container rectangle assign the objes which create in main,to composedshape clas's objes*/
		ComposedShape(rectangle &shape,triangle &small_shape );	/*this constructor for main container rectangle and small container triangle assign the objes which create in main,to composedshape clas's objes*/
		ComposedShape(rectangle &shape,circle &small_shape);	/*this constructor for main container rectangle and small container circle assign the objes which create in main,to composedshape clas's objes*/	
		ComposedShape(triangle &shape,rectangle &small_shape );	/*this constructor for main container triangle and small container rectangle assign the objes which create in main,to composedshape clas's objes*/
		ComposedShape(triangle &shape,triangle &small_shape);	/*this constructor for main container triangle and small container triangle assign the objes which create in main,to composedshape clas's objes*/
		ComposedShape(triangle &shape,circle &small_shape);		/*this constructor for main container triangle and small container circle assign the objes which create in main,to composedshape clas's objes*/
		ComposedShape(circle &shape,rectangle &small_shape );	/*this constructor for main container circle and small container rectangle assign the objes which create in main,to composedshape clas's objes*/
		ComposedShape(circle &shape,triangle &small_shape);		/*this constructor for main container circle and small container triangle assign the objes which create in main,to composedshape clas's objes*/
		ComposedShape(circle &shape,circle &small_shape);		/*this constructor for main container circle and small container circle assign the objes which create in main,to composedshape clas's objes*/		
		void optimalfit();
		inline char getMainchar()const;
		void setMainchar(char main_container);
		inline char getSmallchar()const;
		void setSmallchar(char main_container);
		vector<ShapeElem> getVector_Shapelem()const;
		void setVector_Shapelem(ShapeElem shape_obje);		
		rectangle getobje(){return small_rectangle; }	
		friend vector<ComposedShape::ShapeElem> operator +=(vector<ShapeElem>obj_v,const ComposedShape& shape);		
		ShapeElem& operator[](int index);
		friend ostream& operator <<(ostream& outputStream,const ComposedShape& obje);


	private:
	rectangle small_rectangle;
	ShapeElem shape_obje;
	ofstream myfile;				/*I initiliza file variabe for writing*/		
	triangle triang;
	triangle small_triangle;	
	rectangle rectang;
	circle circ;
	circle small_circle;		
	char main_char;
	char small_char;
	vector <ShapeElem> shape_v;	
	void optimalfit_helper1();
	void optimalfit_helper2();
	void optimalfit_helper3();
	void optimalfit_helper4();
	void optimalfit_helper5();
	void optimalfit_helper6();
	void optimalfit_helper7();
	void optimalfit_helper8();
	void optimalfit_helper9();
};

#endif	
