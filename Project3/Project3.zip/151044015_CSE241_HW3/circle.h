#ifndef CIRCLE_H_
#define CIRCLE_H_
#include <iostream>
#include <fstream>

using namespace std;

class circle{
	public:
		circle();
		circle(double f_radius);	
		circle(double first,double second);	
		circle(double x_k,double y_k,double radius_c);	
		double getRadius()const;
		void setRadius(double radius_c);	
		double getPosition_x()const;
		void setPosition_x(double x_koordinat);
		double getPosition_y()const;
		void setPosition_y(double y_koordinat);				
		void setShape(char choise);
		double circle_area();
		double perimeter_l();		
		friend ostream& operator <<(ostream& outputStream, const circle& shape);	
		const circle operator +( const double adding_size);		
		const circle operator -( const double subbing_size);		
		const circle operator++(); //Prefix version	
		const circle operator++(int ); //Postfix version	
		const circle operator--(); //Prefix version	
		const circle operator--(int ); //Postfix version				
		friend bool operator!=(  circle& obj1, circle& obj2);
		friend bool operator ==(  circle& obj1, circle& obj2);	
		friend bool operator >(  circle& obj1, circle& obj2);	
		friend bool operator <(  circle& obj1, circle& obj2);
		static double total_areas();
		static double perimeter_length();

	private:
		char main_shape;
		double radius;
		double x;
		double y;		
		static double area; 
		static double length;		
	
};


#endif
