#ifndef RECTANGLE_H_
#define RECTANGLE_H_
#include <iostream>
#include <fstream>

using namespace std;

class rectangle{
	public:
		rectangle();
		rectangle(double x,double y );
		int getWidth()const;
		void setWidth(double width_r);		
		int getHeight()const;
		
		void setHeight(double height_r);
		double getPosition_x()const;
		void setPosition_x(double x_koordinat);		
		double getPosition_y()const;
		void setPosition_y(double y_koordinat);											

		void draw(ofstream *dosya)const;
		
	private:
		int width;
		int height;
		double x;
		double y;
};	

#endif
