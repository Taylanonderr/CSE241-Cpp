
#include "composedshape.h"

	ComposedShape::ComposedShape(){}	/*default constructure*/
	
	ComposedShape::ComposedShape(rectangle &shape,rectangle &small_shape) {	/*this constructor for main container rectangle and small container rectangle assign the objes which create in main,to composedshape clas's objes*/
		rectang=shape;
		small_rectangle=small_shape;
	}
	ComposedShape::ComposedShape(rectangle &shape,triangle &small_shape ){	/*this constructor for main container rectangle and small container triangle assign the objes which create in main,to composedshape clas's objes*/
		rectang=shape;
		small_triangle=small_shape;
	}
	ComposedShape::ComposedShape(rectangle &shape,circle &small_shape){	/*this constructor for main container rectangle and small container circle assign the objes which create in main,to composedshape clas's objes*/
		rectang=shape;
		small_circle=small_shape;
	}		
	ComposedShape::ComposedShape(triangle &shape,rectangle &small_shape ){	/*this constructor for main container triangle and small container rectangle assign the objes which create in main,to composedshape clas's objes*/
		triang=shape;
		small_rectangle=small_shape	;
	}
	ComposedShape::ComposedShape(triangle &shape,triangle &small_shape){	/*this constructor for main container triangle and small container triangle assign the objes which create in main,to composedshape clas's objes*/
		triang=shape;
		small_triangle=small_shape;
	}
	ComposedShape::ComposedShape(triangle &shape,circle &small_shape){	/*this constructor for main container triangle and small container circle assign the objes which create in main,to composedshape clas's objes*/
		triang=shape;
		small_circle=small_shape;
	}
	ComposedShape::ComposedShape(circle &shape,rectangle &small_shape ){	/*this constructor for main container circle and small container rectangle assign the objes which create in main,to composedshape clas's objes*/
		circ=shape;
		small_rectangle=small_shape;	
	}	
	ComposedShape::ComposedShape(circle &shape,triangle &small_shape){	/*this constructor for main container circle and small container triangle assign the objes which create in main,to composedshape clas's objes*/
		circ=shape;
		small_triangle=small_shape;
	}
	ComposedShape::ComposedShape(circle &shape,circle &small_shape){	/*this constructor for main container circle and small container circle assign the objes which create in main,to composedshape clas's objes*/
		circ=shape;
		small_circle=small_shape;
	}		
	void ComposedShape::optimalfit(){
		/*I check the users input main container and small_container for draw this shapes*/
		if(main_char=='R' || main_char=='r'){
			if(small_char=='R' || small_char=='r'){
				rectang.draw(&myfile);												
				optimalfit_helper1();	/*I wrote in Hw1 this fuction and get the member data in this class and draw rectangle in rectangle*/
			}
			if(small_char=='T' || small_char=='t'){		
				rectang.draw(&myfile);									
				optimalfit_helper2();	/*I wrote in Hw1 this fuction and get the member data in this class and draw triangle in rectangle*/			
			}
			if(small_char=='C' || small_char=='c'){				
				rectang.draw(&myfile);										
				optimalfit_helper3();	/*I wrote in Hw1 this fuction and get the member data in this class and draw circle in rectangle*/
			}						
		}
		
  		else if(main_char=='T' || main_char=='t'){															
			if(small_char=='R' || small_char=='r'){	
				triang.draw(&myfile);																
				optimalfit_helper4();	/*I wrote in Hw1 this fuction and get the member data in this class and draw rectangle in triangle*/
			}
			else if(small_char=='T' || small_char=='t'){				
				triang.draw(&myfile);												
				optimalfit_helper5();	/*I wrote in Hw1 this fuction and get the member data in this class and draw triangle in triangle*/				
			}
			else if(small_char=='C' || small_char=='c'){				
				triang.draw(&myfile);												
				optimalfit_helper6();	/*I wrote in Hw1 this fuction and get the member data in this class and draw circle in circle*/				
			}		  	
   		} 

		else if(main_char=='C' || main_char=='c'){																										
			if(small_char=='R' || small_char=='r'){	
				circ.draw(&myfile);							
				optimalfit_helper7();	/*I wrote in Hw1 this fuction and get the member data in this class and draw rectangle in circle*/				

			}
			if(small_char=='T' || small_char=='t'){				
				circ.draw(&myfile);			
				optimalfit_helper8();	/*I wrote in Hw1 this fuction and get the member data in this class and draw triangle in circle*/				

			}
			if(small_char=='C' || small_char=='c'){			
				circ.draw(&myfile);			
				optimalfit_helper9();	/*I wrote in Hw1 this fuction and get the member data in this class and draw circle in circle*/				
			}    			
		} 
	}
	void ComposedShape::filename(string filename){
	  	myfile.open(filename);	/*I open the file which get the main for many result output file */
	    myfile <<"<svg version=\"1.1\"\n\t\t"<<"baseProfile=\"full\"\n\t\t"
	    <<"xmlns=\"http://www.w3.org/2000/svg\">\n\n\t"  ;		/*it's for file svg format*/		
	}
	void ComposedShape::draw_small(ofstream *myfile, vector<rectangle> &rectangle_v)const{	/*this draw function for small_rectangle objes in rectangle vector*/
			for(int i=0;i<rectangle_v.size();i++){
	 			*myfile <<"<rect width="<<"\""<<rectangle_v[i].getWidth()<<"\""<<" height="<<"\""<<rectangle_v[i].getHeight()<<"\""<<" x="<<"\""<<rectangle_v[i].getPosition_x()<<"\""<<" y="<<"\""<<rectangle_v[i].getPosition_y()<<"\""<<" stroke="<< "\"red\""<<" fill=\"green\""<< " stroke-width="<<"\"0.1\""<<" />\n\t";				
			}
	  			
	    *myfile	<<"	</svg>"	;
		(*myfile).close();	/*close file*/
	}

	void ComposedShape::draw_small(ofstream *myfile, vector<triangle> &triangle_v)const{	/*this draw function for small_triangle objes in triangle vector*/
			for(int i=0;i<triangle_v.size();i++){
				*myfile<< "<polygon points="<<"\""<<triangle_v[i].getPosition_x()<<","<<triangle_v[i].getPosition_y()<<","<<triangle_v[i].getPosition_x2()<<","<<triangle_v[i].getPosition_y2()<<","<<triangle_v[i].getPosition_x3()<<","<<triangle_v[i].getPosition_y3()<<"\""<<" stroke="<< "\"green\""<<" fill="<<"\"transparent\""<< " stroke-width="<<"\"1\""<<" />\n";
			}

	    *myfile	<<"	</svg>"	;
		(*myfile).close();	/*close file*/

	}

	void ComposedShape::draw_small(ofstream *myfile, vector<circle> &circle_v)const{	/*this draw function for small_circle objes in circle vector*/
			for(int i=0;i<circle_v.size();i++){
		  		*myfile<<"<circle cx="<<"\""<<circle_v[i].getPosition_x() <<"\""<<" cy="<<"\""<<circle_v[i].getPosition_y()<<"\""<< " r="<<"\""<<circle_v[i].getRadius()<<"\"" <<" stroke="<<"\"green\""<<" fill="<<"\"transparent\""<<" stroke-width="<<"\"0\""<<" />\n";
			}

	    *myfile	<<"	</svg>"	;
		(*myfile).close();	/*close file*/
	}						

	inline char ComposedShape::getMainchar()const{	/*get user main char for main shapes*/
		return main_char;
	}

	void ComposedShape::setMainchar(char main_container){	/*set user main char for main shapes*/
		main_char=main_container;
	}

	inline char ComposedShape::getSmallchar()const{	/*get user small char for small shapes*/
		return small_char;
	}

	void ComposedShape::setSmallchar(char main_container){	/*get user small char for small shapes*/
		small_char=main_container;
	}
	

	vector<rectangle> ComposedShape::getVector_Rect()const{		/*get vector for rectangle objes for another class or functions which in not this class*/
		return rectangle_v;
	}
	void ComposedShape::setVector_Rect(rectangle shape){		/*set vector for triiangle objes for another class or functions which in not this class*/
		rectangle_v.push_back(shape);
	}			
		
	vector<triangle> ComposedShape::getVector_Triangle()const{		/*get vector for triiangle objes for another class or functions which in not this class*/
		return triangle_v;
	}
	void ComposedShape::setVector_Triangle(triangle shape){		/*set vector for triiangle objes for another class or functions which in not this class*/
		triangle_v.push_back(shape);
	}		

	vector<circle> ComposedShape::getVector_Circle()const{		/*get vector for triiangle objes for another class or functions which in not this class*/
		return circle_v;
	}
	void ComposedShape::setVector_Circle(circle shape){		/*set vector for triiangle objes for another class or functions which in not this class*/
		circle_v.push_back(shape);
	}	

	void ComposedShape::optimalfit_helper1(){		/*rectangle in rectangle helper function for optimalfit function*/
		int num_width,num_height,res1_x,res1_y,res1,i,j,w_1,h_1,x,y,temp1,temp2,control,rect_area,s_rect_area,num_rectengle=0;
		int small_width,small_height,width,height;
		res1=0,x=0,y=0;
		num_width=(rectang.getWidth())/(small_rectangle.getWidth());	/*get value in class obje and assign for any variable*/
		num_height=(rectang.getHeight())/(small_rectangle.getHeight());		/*get value in class obje and assign for any variable*/
		width=rectang.getWidth();	/*get value in class obje and assign for any variable*/
		height=rectang.getHeight();		/*get value in class obje and assign for any variable*/
		small_width=small_rectangle.getWidth();		/*get value in class obje and assign for any variable*/
		small_height=small_rectangle.getHeight();		/*get value in class obje and assign for any variable*/			
		if(((width)%(small_width))>=small_height){	/*it's for horizontal small rectangle*/
				if(width%small_width!=0){			
					res1_x=small_height/(width%small_width);
					res1_y=height/small_height;
					res1=res1_x*res1_y;
					control=0;
			}
		}
		else if(height%(small_height)>=small_width){		/*it's for vertical small rectangle*/
				if(height%small_height!=0 ){			
					res1_x=small_width/(height%small_height);
					res1_y=width/small_width;
					res1=res1_x*res1_y;
					control=1;
			}
		}

		temp1=num_width*num_height+res1;	/*This is for residual space.It calculates more space than width of height*/
		num_width=width/small_height;
		num_height=height/small_width;	
		temp2=num_width*num_height;		/*This is for except for residual space.It calculates smaller space than width of height*/
		if(temp1>temp2){	
			w_1=width/small_width;
			h_1=height/small_height;
			for(i=0;i<w_1;i++){
				for(j=0;j<h_1;j++){
					small_rectangle.setPosition_x(x);	/*I assigned x coordinate in small_shape class*/
					small_rectangle.setPosition_y(y);	/*I assigned x coordinate in small_shape class*/
					small_rectangle.setWidth(small_width);	/*I assigned width in small_shape class*/
					small_rectangle.setHeight(small_height);	/*I assigned height in small_shape class*/
					rectangle_v.push_back(small_rectangle);	/*I send an small_obj in vector*/
					num_rectengle+=1;		/*value of rectengle which drawed for type 1*/
					y+=small_height;			
				}
				y=0;
				x+=small_width;
			}
			if(control==0 && res1!=0){	/*this condition for horizontal and more space than width of height*/
				while(x<=width){
					small_rectangle.setPosition_x(x);	/*I assigned x coordinate in small_shape class*/
					small_rectangle.setPosition_y(y);	/*I assigned x coordinate in small_shape class*/
					small_rectangle.setWidth(small_width);	/*I assigned width in small_shape class*/
					small_rectangle.setHeight(small_height);	/*I assigned height in small_shape class*/
					rectangle_v.push_back(small_rectangle);	/*I send an small_obj in vector*/
					num_rectengle+=1;			
					x+=small_height;		
				}

			}
	
			else if(control==1 && res1!=0) {  /*this condition for vertical and more space than width of height*/
				y=(h_1)*small_height;
				x=0;
				while(y<=height && x+small_height<=width){
					small_rectangle.setPosition_x(x);
					small_rectangle.setPosition_y(y);
					small_rectangle.setWidth(small_width);
					small_rectangle.setHeight(small_height);
					rectangle_v.push_back(small_rectangle);
					num_rectengle+=1;	/*value of rectengle which drawed for type 2*/
					x+=small_height;
				}

			}
		}
		else{	/*This condition for except for residual space.It calculates smaller space than width of height*/
			w_1=width/small_height;
			h_1=height/small_width;
			for(i=0;i<h_1;i++){
				x=0;				
				for(j=0;j<w_1;j++){
					small_rectangle.setPosition_x(x);
					small_rectangle.setPosition_y(y);
					small_rectangle.setWidth(small_height);
					small_rectangle.setHeight(small_width);
					rectangle_v.push_back(small_rectangle);	/*I send an small_obj in vector*/
					num_rectengle+=1;    /*value of rectengle which drawed */		
					x+=small_height;			
			
				}
				y+=small_width;
			}
			if(	width%small_height>=small_width){
				i=width%small_height;
				y=0;
				while(i>=small_width && y<height){
					if(y+small_height>=height){
						y=0;
						x+=small_width;						
						i-=small_height;
					}
					else{
					small_rectangle.setPosition_x(x);
					small_rectangle.setPosition_y(y);
					small_rectangle.setWidth(small_width);
					small_rectangle.setHeight(small_height);
					rectangle_v.push_back(small_rectangle);	/*I send an small_obj in vector*/
					num_rectengle+=1;    /*value of rectengle which drawed */		
					y+=small_height;	
					}
		
				}
				
			}
			else if(height%small_width>=small_height){
				i=height%small_width;
				x=0;
				while(i>=small_height && x<width){
					if(x+small_width>=width){
						x=0;
						y+=small_height;						
						i-=small_width;
					}
					else{
					small_rectangle.setPosition_x(x);
					small_rectangle.setPosition_y(y);
					small_rectangle.setWidth(small_width);
					small_rectangle.setHeight(small_height);
					rectangle_v.push_back(small_rectangle);	/*I send an small_obj in vector*/
					num_rectengle+=1;    /*value of rectengle which drawed */		
					x+=small_width;	
					}
				}
			}
		}
		rect_area=width*height;		/*area of rectangle*/
		s_rect_area=(small_width*small_height)*num_rectengle;	/*area of small rectangle*/
		cout<<"I can fit at most "<< num_rectengle<<" small shapes into the main container. The empty area (red) in container is :"<<rect_area-s_rect_area<<endl;
		draw_small(&(myfile),rectangle_v);	/*I send a file and vector for wrting in file with svg format*/
	}

	void ComposedShape::optimalfit_helper2(){		/*triangle in rectangle helper function for optimalfit function*/
		int x=0, y=0,num_triangle=0,i,j,w_1,h_1;
		double triangle_area;
		decltype(triangle_area) rect_area;
		auto width=rectang.getWidth();
		auto height=rectang.getHeight();
		auto side=small_triangle.getSide();
		h_1=height/(side/2*sqrt(3));	/*I calculate num of triangle for every column*/
		w_1=width/side;		/*I calculate num of triangle for every line*/
		for(i=0;i<h_1;i++){
			for(j=0;j<w_1;j++){
				small_triangle.setPosition_x(x);
				small_triangle.setPosition_y(y+(side/2)*sqrt(3));
				small_triangle.setPosition_x2(x+side);
				small_triangle.setPosition_y2(y+(side/2)*sqrt(3));
				small_triangle.setPosition_x3(x+side/2);
				small_triangle.setPosition_y3(y);								
				small_triangle.setSide(side);
				triangle_v.push_back(small_triangle);
				/**myfile<< "<polygon points="<<"\""<<x<<","<<y+(side/2)*sqrt(3)<<","<<x+side<<","<<y+(side/2)*sqrt(3)<<","<<x+side/2<<","<<y<<"\""<<" stroke="<< "\"green\""<<" fill="<<"\"transparent\""<< " stroke-width="<<"\"1\""<<" />\n";*/
				num_triangle+=1;	/*count of triangle*/
				x+=side;
			}
			y+=side/2*sqrt(3);
			j=0;
			x=0;
		}
				/*I write in file for reversing triangle in rectangle*/
		h_1=height/(side/2*sqrt(3));
		w_1=(width-side/2)/side;
		x=side/2;
		y=0;
		for(i=0;i<h_1;i++){
			for(j=0;j<w_1;j++){
				small_triangle.setPosition_x(x);
				small_triangle.setPosition_y(y);
				small_triangle.setPosition_x2(x+side);
				small_triangle.setPosition_y2(y);
				small_triangle.setPosition_x3(x+side/2);
				small_triangle.setPosition_y3(y+(side/2)*sqrt(3));								
				small_triangle.setSide(side);
				triangle_v.push_back(small_triangle);			
				/**myfile<< "<polygon points="<<"\""<<x<<","<<y<<","<<x+side<<","<<y<<","<<x+side/2<<","<<y+(side/2)*sqrt(3)<<"\""<<" stroke="<< "\"green\""<<" fill="<<"\"transparent\""<< " stroke-width="<<"\"1\""<<" />\n";*/
				x+=side;
				num_triangle+=1;	/*count of triangle*/
			}
			y+=side/2*sqrt(3);
			j=0;
			x=side/2;
		}
		draw_small(&(myfile),triangle_v);				
		rect_area=width*height;		/*area of rectangle*/
		triangle_area=num_triangle*((side*side)*sqrt(3)/4);		/*area of all of the triangle in rectangle*/
		cout<<"I can fit at most "<< num_triangle<<" small shapes into the main container. The empty area (red) in container is :"<<rect_area-triangle_area<<endl;		
	}

	void ComposedShape::optimalfit_helper3(){		/*circle in rectangle helper function for optimalfit function*/
		int y1_a,y2_a,x_k,y_k,sayac=0,num_circle=0,rect_area,circ_area;
		auto width=rectang.getWidth();
		auto height=rectang.getHeight();
		auto radius=small_circle.getRadius();		
		y1_a=height/(4*radius);					/*it's for first type sequence*/
		x_k=radius;
		y_k=radius;
		y2_a=height/(2*radius+(radius*sqrt(3)));	/*it's for second type sequence*/
		if(y1_a<y2_a && y2_a<width && y2_a<height){
			while(y_k<=height){
				small_circle.setPosition_x(x_k);
				small_circle.setPosition_y(y_k);
				small_circle.setRadius(radius);
				circle_v.push_back(small_circle);			
		  		/**myfile<<"<circle cx="<<"\""<<x_k<<"\""<<" cy="<<"\""<<y_k<<"\""<< " r="<<"\""<<radius<<"\"" <<" stroke="<<"\"green\""<<" fill="<<"\"transparent\""<<" stroke-width="<<"\"0\""<<" />\n";	*/
				num_circle+=1;		/*count of circle*/
				x_k+=2*radius;
				if(x_k+radius>width){
					sayac++;	
					if(sayac%2==1)
						x_k=2*radius;
					else
						x_k=radius;
					y_k+=(radius*sqrt(3));
				}
			}
		}
		else{
			while(y_k+radius<=height){
				small_circle.setPosition_x(x_k);
				small_circle.setPosition_y(y_k);
				small_circle.setRadius(radius);
				circle_v.push_back(small_circle);			
		  		/**myfile<<"<circle cx="<<"\""<<x_k<<"\""<<" cy="<<"\""<<y_k<<"\""<< " r="<<"\""<<radius<<"\"" <<" stroke="<<"\"green\""<<" fill="<<"\"transparent\""<<" stroke-width="<<"\"1\""<<" />\n";	*/
				num_circle+=1;		/*count of circle*/
				x_k+=2*radius;
				if(x_k+radius>width){
					x_k=radius;
					y_k+=2*radius;
				}
			}
		}
		draw_small(&(myfile),circle_v);								
		rect_area=width*height;
		circ_area=num_circle*(radius*radius*sqrt(3));
		cout<<"I can fit at most "<< num_circle<<" small shapes into the main container. The empty area (red) in container is :"<<rect_area-circ_area<<endl;	
	}
	
	void ComposedShape::optimalfit_helper4(){		/*rectangle in triangle helper function for optimalfit function*/
		double num_rectangle=0,rectangle_area,triangle_area,x,temp,y;
		auto side=triang.getSide();
		auto small_width=small_rectangle.getWidth();
		auto small_height=small_rectangle.getHeight();
		x=small_height/sqrt(3);	/*start point for x coorcinate*/
		temp=x;
		y=(side/2.0)*sqrt(3.0)-small_height;	/*start point for y coorcinate*/
		triangle_area=((side*side*sqrt(3))/4);		/*area of triangle*/
		side-=(small_height)/sqrt(3.0);	
		while(x<=side && y>0){
			if(x+small_width>=side){
				y-=small_height;
		   		x=small_height/sqrt(3.0)+temp;
				temp=x;
				side-=(small_height)/sqrt(3.0);		/*calculate for each line max width to end*/
			}
			else{	
				small_rectangle.setPosition_x(x);
				small_rectangle.setPosition_y(y);
				small_rectangle.setWidth(small_width);
				small_rectangle.setHeight(small_height);				
				rectangle_v.push_back(small_rectangle);			
				num_rectangle+=1;		/*value of rectangle for each drawed */
				/**myfile <<"<rect width="<<"\""<<small_width<<"\""<<" height="<<"\""<<small_height<<"\""<<" x="<<"\""<<x<<"\""<<" y="<<"\""<<y<<"\""<<" stroke="<< "\"green\""<<" fill=\"green\""<< " stroke-width="<<"\"0.1\""<<" />\n\t";*/	
				x+=small_width;
			}
		}
		draw_small(&(myfile),rectangle_v);		
		rectangle_area=(small_width*small_height)*num_rectangle;		/*area of rectangle*/
		cout<<"I can fit at most "<<num_rectangle<<" small shapes into the main container. The empty area (red) in container is :"<<triangle_area-rectangle_area<<endl;	
	}	
	
	void ComposedShape::optimalfit_helper5(){		/*triangle in triangle helper function for optimalfit function*/
		double x=0, y=0,temp=0,temp2,num_triangle=0,triangle_area,s_triangle_area,side,s_side;
		side=triang.getSide();
		s_side=small_triangle.getSide();	
		temp2=side;	
		y=(side/2)*sqrt(3);						/*start point for y coordinate*/
		triangle_area=(side*side*sqrt(3))/4;	/*main shape area*/
		while(x<=side && y-(s_side/2)>=0){		
			if(x+s_side>side){
				side-=s_side/2;
				x=s_side/2+temp;
				temp=x;
				y-=s_side/2*sqrt(3);
			}
			else{
				small_triangle.setPosition_x(x);
				small_triangle.setPosition_y(y);
				small_triangle.setPosition_x2(x+s_side);
				small_triangle.setPosition_y2(y);
				small_triangle.setPosition_x3(x+s_side/2);
				small_triangle.setPosition_y3(y-(s_side/2)*sqrt(3));								
				small_triangle.setSide(s_side);				
				triangle_v.push_back(small_triangle);					
				/**myfile<< "<polygon points="<<"\""<<x<<","<<y<<","<<x+s_side<<","<<y<<","<<x+s_side/2<<","<<y-(s_side/2)*sqrt(3)<<"\""<<" stroke="<< "\"red\""<<" fill="<<"\"green\""<< " stroke-width="<<"\"0.4\""<<" />\n";*/
			num_triangle+=1;	/*value of triangle for each drawed */
			x+=s_side;
			}		
		}
		side=temp2;
		temp=s_side/2;
		//reversing small triangle writing code
		y=(side/2)*sqrt(3);
		x=s_side/2;
		side=side-s_side/2;
		while(x<=side && y-(s_side/2)>=0){
			if(x+s_side>side){
				side-=s_side/2;
				x=s_side/2+temp;
				temp=x;
				y-=s_side/2*sqrt(3);
			}
			else{
				small_triangle.setPosition_x(x);
				small_triangle.setPosition_y(y-(s_side/2)*sqrt(3));
				small_triangle.setPosition_x2(x+s_side);
				small_triangle.setPosition_y2(y-(s_side/2)*sqrt(3));
				small_triangle.setPosition_x3(x+s_side/2);
				small_triangle.setPosition_y3(y);								
				small_triangle.setSide(s_side);				
				triangle_v.push_back(small_triangle);				
				/**myfile<< "<polygon points="<<"\""<<x<<","<<y-(s_side/2)*sqrt(3)<<","<<x+s_side<<","<<y-(s_side/2)*sqrt(3)<<","<<x+s_side/2<<","<<y<<"\""<<" stroke="<< "\"red\""<<" fill="<<"\"green\""<< " stroke-width="<<"\"0.4\""<<" />\n";*/
			num_triangle+=1;	/*value of triangle for each drawed */
			x+=s_side;
			}	
		
		}
		draw_small(&(myfile),triangle_v);				
		s_triangle_area=((s_side*s_side*sqrt(3))/4)*num_triangle;		//small triangle area
		cout<<"I can fit at most "<<num_triangle<<" small shapes into the main container. The empty area (red) in container is :"<<triangle_area-s_triangle_area<<endl;	
	}
	
	void ComposedShape::optimalfit_helper6(){		/*circle in triangle helper function for optimalfit function*/
		double x_k,y_k,temp,num_circle=0,side,radius;
		double triangle_area,circle_area;
		side=triang.getSide();
		radius=small_circle.getRadius();		
		x_k=radius*sqrt(3);						/*start point for radius center of x coordinate*/
		temp=x_k;
		y_k=((side*sqrt(3))/2)-radius;			/*start point for radius center of y coordinate*/
		triangle_area=(side*side*sqrt(3))/4;	/*area of triangle*/
		side=side-radius/sqrt(3);				/*circle triangle calculating variable max size for width */
		while(x_k<=side && y_k>=0){
			if(x_k+radius<side){
				small_circle.setPosition_x(x_k);
				small_circle.setPosition_y(y_k);
				small_circle.setRadius(radius);				
				circle_v.push_back(small_circle);			
				/**myfile<<"<circle cx="<<"\""<<x_k<<"\""<<" cy="<<"\""<<y_k<<"\""<< " r="<<"\""<<radius<<"\"" <<" stroke="<<"\"transparent\""<<" fill="<<"\"green\""<<" stroke-width="<<"\"0\""<<" />\n";*/
				num_circle+=1;					/*value of circle for each drawed */
				x_k+=2*radius;	
			}		
			if(x_k+radius>=side){
				x_k=temp+radius;
				temp=x_k;
				y_k-=radius*sqrt(3);
				side-=radius;
			}	
		}
		draw_small(&(myfile),circle_v);						
		circle_area=(radius*radius*3.14)*num_circle;		//area of circle
		cout<<"I can fit at most "<<num_circle<<" small shapes into the main container. The empty area (red) in container is :"<<triangle_area-circle_area<<endl;		
	}	
					
	void ComposedShape::optimalfit_helper7(){		/*rectangle in circle helper function for optimalfit function*/
		int x=0,y=0,flag=0,num_rectangle=0;
		double rect_area,circ_area,width,height,radius;
		radius=circ.getRadius();				
		width=small_rectangle.getWidth();
		height=small_rectangle.getHeight();

			while(y<=2*radius && x>=0){
				while(x<=2*radius){
		/*I checked point to point.I used this condition for every point of rectangle in circle or not*/
					if((((x-radius+width))*((x-radius+width))+((y-radius)*(y-radius))<=(radius*radius)) && ((x-radius)*(x-radius)+((y-radius+height)*(y-radius+height))<=(radius*radius)) && (x-radius)*(x-radius)+(y-radius)*(y-radius)<=(radius*radius) && ((x-radius+width)*(x-radius+width)+((y-radius+height))*(y-radius+height)<=(radius*radius)) ){
						small_rectangle.setPosition_x(x);
						small_rectangle.setPosition_y(y);
						small_rectangle.setWidth(width);
						small_rectangle.setHeight(height);										
						rectangle_v.push_back(small_rectangle);					
					   /*	*myfile <<"<rect width="<<"\""<<width<<"\""<<" height="<<"\""<<height<<"\""<<" x="<<"\""<<x<<"\""<<" y="<<"\""<<y<<"\""<<" stroke="<< "\"green\""<<" fill=\"transparent\""<< " stroke-width="<<"\"1\""<<" />\n\t";*/
					   	num_rectangle+=1;
						x+=width;		
						flag=1;
					}
					else{
					x++;
					}				
				}
				x=0;
				if(flag==0){
					y++;
				}	
				else{
					y+=height;}
				flag=0;
			}
		draw_small(&(myfile),rectangle_v);					
		rect_area=(width*height)*num_rectangle;		/*area of rectangle*/
		circ_area=(radius*radius*3.14);				/*area of circle*/
		cout<<"I can fit at most "<< num_rectangle<<" small shapes into the main container. The empty area (red) in container is :"<<circ_area-rect_area<<endl;	
	}	
	
	void ComposedShape::optimalfit_helper8(){		/*triangle in circle helper function for optimalfit function*/
		int i;
		double x,y,circ_area,triangle_area,num_triangle=0,side,radius;
		radius=circ.getRadius();
		side=small_triangle.getSide();		
		y=0;
		x=0;
		while(y<=2*radius && x>=0){
				for(i=0;i<2*radius;i++){
					/*I checked point to point.I used this condition for every point of triangle in circle or not*/
					if( (((x-radius)*(x-radius))+((y-radius)*(y-radius))<=(radius*radius)) && (((x+side/2)-radius)*(x+(side/2)-radius)+(y-((side/2)*sqrt(3))-radius)*(y-((side/2)*sqrt(3))-radius)<=(radius*radius)) && ((x+side-radius)*(x+side-radius)+(y-radius)*(y-radius)<=(radius*radius))  ){
					small_triangle.setPosition_x(x);
					small_triangle.setPosition_y(y);
					small_triangle.setPosition_x2(x+side);
					small_triangle.setPosition_y2(y);
					small_triangle.setPosition_x3(x+side/2);
					small_triangle.setPosition_y3(y-(side/2)*sqrt(3));										
					small_triangle.setSide(side);				
					triangle_v.push_back(small_triangle);					
					/**myfile<< "<polygon points="<<"\""<<x<<","<<y<<","<<x+side<<","<<y<<","<<x+side/2<<","<<y-(side/2)*sqrt(3)<<"\""<<" stroke="<< "\"red\""<<" fill="<<"\"green\""<< " stroke-width="<<"\"1\""<<" />\n";*/
					num_triangle+=1;  	/*value of triangle*/
					x+=side;
					}
					else
					x++;				
				}

				x=0;
				y+=(side*sqrt(3))/2;			
			}		
	
		x=0;
		y=0;
		while(y<=2*radius && x>=0){
				for(i=0;i<2*radius;i++){
					/*I checked point to point.I used this condition for every point of reversing triangle in circle or not*/	
					if((((x-radius)*(x-radius))+((y-radius)*(y-radius))<=(radius*radius)) && (((x-radius+(3*side)/2)*(x+((3*side)/2)-radius))+((y-(side/2)*sqrt(3)-radius)*(y-(side/2)*sqrt(3)-radius))<=(radius*radius)) && (((x+side/2)-radius)*(x+(side/2)-radius)+(y-((side/2)*sqrt(3))-radius)*(y-((side/2)*sqrt(3))-radius)<=(radius*radius)) && ((x+side-radius)*(x+side-radius)+(y-radius)*(y-radius)<=(radius*radius)) ){
					small_triangle.setPosition_x(x+side/2);
					small_triangle.setPosition_y(y-(side/2)*sqrt(3));
					small_triangle.setPosition_x2(x+side);
					small_triangle.setPosition_y2(y);
					small_triangle.setPosition_x3(x+(3*side)/2);
					small_triangle.setPosition_y3(y-(side/2)*sqrt(3));										
					small_triangle.setSide(side);				
					triangle_v.push_back(small_triangle);				
					/**myfile<< "<polygon points="<<"\""<<x+side/2<<","<<y-(side/2)*sqrt(3)<<","<<x+side<<","<<y<<","<<x+(3*side)/2<<","<<y-(side/2)*sqrt(3)<<"\""<<" stroke="<< "\"red\""<<" fill="<<"\"green\""<< " stroke-width="<<"\"1\""<<" />\n";*/
					num_triangle+=1;		/*value of reversing triangle*/		
					x+=side;
					}
					else{			
					x++;
					}								
				}
				x=0;
				y+=(side*sqrt(3))/2;
		}
		draw_small(&(myfile),triangle_v);				
		circ_area=(radius*radius*3.14);		/*area of circle*/
		triangle_area=((side*side*sqrt(3))/4)*num_triangle;		/*area of triangle*/
		cout<<"I can fit at most "<<num_triangle<<" small shapes into the main container. The empty area (red) in container is :"<<circ_area-triangle_area<<endl;	
	}
	
	void ComposedShape::optimalfit_helper9(){		/*circle in circle helper function for optimalfit function*/
		double x=0,y=0,flag=0,num_circ=0,circ_area,s_circ_area,radius,s_radius;
		radius=circ.getRadius();
		s_radius=small_circle.getRadius();			
		while(y<2*radius && x<2*radius){
			while(x<=2*radius){	
					/*I checked point to point.I used this condition for some points of circle, in circle or not*/	
				if( 
				(((x-s_radius)-radius)*((x-s_radius)-radius)+((y-s_radius)-radius)*((y-s_radius)-radius)<=(radius*radius)) &&
				(((x-s_radius)-radius)*((x-s_radius)-radius)+((y+s_radius)-radius)*((y+s_radius)-radius)<=(radius*radius)) &&
				(((x+s_radius)-radius)*((x+s_radius)-radius)+((y+s_radius)-radius)*((y+s_radius)-radius)<=(radius*radius)) &&
				(((x+s_radius)-radius)*((x+s_radius)-radius)+((y-s_radius)-radius)*((y-s_radius)-radius)<=(radius*radius)) ){
					small_circle.setPosition_x(x);
					small_circle.setPosition_y(y);
					small_circle.setRadius(s_radius);				
					circle_v.push_back(small_circle);				
					/**myfile<<"<circle cx="<<"\""<<x<<"\""<<" cy="<<"\""<<y<<"\""<< " r="<<"\""<<s_radius<<"\"" <<" stroke="<<"\"transparent\""<<" fill="<<"\"green\""<<" stroke-width="<<"\"0\""<<" />\n";	*/			num_circ+=1;	/*value of drawing circle for every loop*/
					flag=1;
					x+=2*s_radius;	
				}
				else{
				x++;
				}
			}	
			if(x>=2*radius){
				y++;
				x=0;
			}
			if(flag==1){
				y+=2*s_radius;
			}
			else{
				y++;
			}
			flag=0;		
			x=0;
		}
		draw_small(&(myfile),circle_v);						
		circ_area=(radius*radius*3.14)*num_circ;		/*area of circle*/
		s_circ_area=(s_radius*s_radius*3.14)/4;			/*area of small circle*/
		cout<<"I can fit at most "<<num_circ<<" small shapes into the main container. The empty area (red) in container is :"<<circ_area-s_circ_area<<endl;	
	}			