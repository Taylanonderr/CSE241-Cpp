#include <iostream>
#include <fstream>
#include "rectangle.h"
using namespace std;

		rectangle::rectangle(){}
		rectangle::rectangle(double x,double y ){
			setWidth(x);
			setHeight(y);
		}
		int rectangle::getWidth()const{		/*get width for rectangle objes for another class or functions which in not this class*/
			return width;
		}
		void rectangle::setWidth(double width_r){		/*set width for rectangle objes for another class or functions which in not this class*/
			width=width_r;
		}		
		int rectangle::getHeight()const{		/*get height for rectangle objes for another class or functions which in not this class*/
			return height;
		}
		void rectangle::setHeight(double height_r){		/*set height for rectangle objes for another class or functions which in not this class*/
			height=height_r;
		}
		double rectangle::getPosition_x()const{		/*get coordinate x for circle objes for another class or functions which in not this class*/
			return x;
		}
		void rectangle::setPosition_x(double x_koordinat){		/*set coordinate y for circle objes for another class or functions which in not this class*/
			x=x_koordinat;
		}		
		double rectangle::getPosition_y()const{		/*get coordinate y for circle objes for another class or functions which in not this class*/
			return y;
		}
		void rectangle::setPosition_y(double y_koordinat){		/*set coordinate y for circle objes for another class or functions which in not this class*/
			y=y_koordinat;
		}												

		void rectangle::draw(ofstream *dosya)const{		/*this draw function for main_triangle objes */
				/*I initiliza file variabe for writing*/
	 			*dosya <<"<rect width="<<"\""<<getWidth()<<"\""<<" height="<<"\""<<getHeight()<<"\""<<" x="<<"\""<<0<<"\""<<" y="<<"\""<<0<<"\""<<" stroke="<< "\"red\""<<" fill=\"red\""<< " stroke-width="<<"\"0.1\""<<" />\n\t";				

		
		}	
		

