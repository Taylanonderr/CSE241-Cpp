#ifndef COMPOSEDSHAPE_H_
#define COMPOSEDSHAPE_H_
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <vector>
#include "rectangle.h"
#include "circle.h"
#include "triangle.h"

using namespace std;

class ComposedShape{
	public:
	ComposedShape();
	ComposedShape(rectangle &shape,rectangle &small_shape);	/*this constructor for main container rectangle and small container rectangle assign the objes which create in main,to composedshape clas's objes*/
	ComposedShape(rectangle &shape,triangle &small_shape );	/*this constructor for main container rectangle and small container triangle assign the objes which create in main,to composedshape clas's objes*/
	ComposedShape(rectangle &shape,circle &small_shape);	/*this constructor for main container rectangle and small container circle assign the objes which create in main,to composedshape clas's objes*/	
	ComposedShape(triangle &shape,rectangle &small_shape );	/*this constructor for main container triangle and small container rectangle assign the objes which create in main,to composedshape clas's objes*/
	ComposedShape(triangle &shape,triangle &small_shape);	/*this constructor for main container triangle and small container triangle assign the objes which create in main,to composedshape clas's objes*/
	ComposedShape(triangle &shape,circle &small_shape);		/*this constructor for main container triangle and small container circle assign the objes which create in main,to composedshape clas's objes*/
	ComposedShape(circle &shape,rectangle &small_shape );	/*this constructor for main container circle and small container rectangle assign the objes which create in main,to composedshape clas's objes*/
	ComposedShape(circle &shape,triangle &small_shape);		/*this constructor for main container circle and small container triangle assign the objes which create in main,to composedshape clas's objes*/
	ComposedShape(circle &shape,circle &small_shape);		/*this constructor for main container circle and small container circle assign the objes which create in main,to composedshape clas's objes*/		
	void optimalfit();
	void filename(string filename);
	void draw_small(ofstream *myfile, vector<rectangle> &rectangle_v)const;
	void draw_small(ofstream *myfile, vector<triangle> &triangle_v)const;
	void draw_small(ofstream *myfile, vector<circle> &circle_v)const;
	inline char getMainchar()const;
	void setMainchar(char main_container);
	inline char getSmallchar()const;
	void setSmallchar(char main_container);
	vector<rectangle> getVector_Rect()const;
	void setVector_Rect(rectangle shape);				
	vector<triangle> getVector_Triangle()const;
	void setVector_Triangle(triangle shape);	
	vector<circle> getVector_Circle()const;
	void setVector_Circle(circle shape);	
	

	private:
	ofstream myfile;				/*I initiliza file variabe for writing*/		
	triangle triang;
	triangle small_triangle;	
	rectangle rectang;
	rectangle small_rectangle;
	circle circ;
	circle small_circle;		
	char main_char;
	char small_char;
	vector <rectangle> rectangle_v;
	vector <triangle> triangle_v;
	vector <circle> circle_v;
	void optimalfit_helper1();
	void optimalfit_helper2();
	void optimalfit_helper3();
	void optimalfit_helper4();
	void optimalfit_helper5();
	void optimalfit_helper6();
	void optimalfit_helper7();
	void optimalfit_helper8();
	void optimalfit_helper9();
};
#endif	
