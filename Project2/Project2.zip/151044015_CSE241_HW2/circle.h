#ifndef CIRCLE_H_
#define CIRCLE_H_
#include <iostream>
#include <fstream>

using namespace std;

class circle{
	public:
		circle();
		circle(double f_radius);	
		double getRadius()const;
		void setRadius(double radius_c);	
		double getPosition_x()const;
		void setPosition_x(double x_koordinat);
		double getPosition_y()const;
		void setPosition_y(double y_koordinat);				
		void setShape(char choise);
		void draw(ofstream *myfile)const;

	private:
		char main_shape;
		double radius;
		double x;
		double y;		
	
};

#endif
