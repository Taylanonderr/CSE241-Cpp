#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <vector>
#include "composedshape.h"
#include "rectangle.h"
#include "circle.h"
#include "triangle.h"
using namespace std;


int main(){
	int i=0,r=0,t=0,c=0;
	double width,height;
	double radius,side,small_side,s_radius,small_width,small_height;
	string file[10];
	char choose[9][2],second_choose[9][2];		
	rectangle	rect_obj[1];	/*this array for main conventer*/
	rectangle	small_rect_obj[3];	/*this array obje for small shapes using in loop*/
	triangle tri_obj[1];	/*this array for main conventer*/
	triangle small_tri_obj[3];	/*this array obje for small shapes using in loop*/	
	circle	circ_obj[1];	/*this array for main conventer*/
	circle	small_circ_obj[3];	/*this array obje for small shapes using in loop*/

	rectangle obj1(1000.0,800.0);	/*it's for trying main rectangle obj*/
	rectangle s_obj1(42.0,30.0);	/*it's for trying small rectangle obj*/
	rectangle s_obj2(100.0,68.0);	/*it's for trying small rectangle obj*/
	rectangle s_obj3(80.0,70.0);	/*it's for trying small rectangle obj*/	

	triangle t_obj1(800.0);		/*it's for trying main triangle obj*/
	triangle ts_obj1(55.0);		/*it's for trying small rectangle obj*/
	triangle ts_obj2(86.0);		/*it's for trying small rectangle obj*/
	triangle ts_obj3(150.0);	/*it's for trying small rectangle obj*/


	circle  c_obj1(1000.0);		/*it's for trying main circle obj*/
	circle  cs_obj1(42.0);		/*it's for trying small circle obj*/
	circle  cs_obj2(100.0);		/*it's for trying small circle obj*/
	circle  cs_obj3(80.0);		/*it's for trying small circle obj*/
	rect_obj[0]=obj1;
	
/*it's for array obje*/	
	small_rect_obj[0]=s_obj1;	
	small_rect_obj[1]=s_obj2;	
	small_rect_obj[2]=s_obj3;

	tri_obj[0]=t_obj1;
	small_tri_obj[0]=ts_obj1;
	small_tri_obj[1]=ts_obj2;
	small_tri_obj[2]=ts_obj3;


	circ_obj[0]=c_obj1;
	small_circ_obj[0]=cs_obj1;
	small_circ_obj[1]=cs_obj2;
	small_circ_obj[2]=cs_obj3;			

/*it's for users choise*/
	choose[0][0]='r',second_choose[0][0]='r';
	choose[1][0]='r',second_choose[1][0]='t';
	choose[2][0]='r',second_choose[2][0]='c';
	choose[3][0]='t',second_choose[3][0]='r';
	choose[4][0]='t',second_choose[4][0]='t';
	choose[5][0]='t',second_choose[5][0]='c';
	choose[6][0]='c',second_choose[6][0]='r';
	choose[7][0]='c',second_choose[7][0]='t';
	choose[8][0]='c',second_choose[8][0]='c';
/*it's for nine situation different file name*/	
	file[0]="output.svg";										
	file[1]="output1.svg";
	file[2]="output2.svg";	
	file[3]="output3.svg";
	file[4]="output4.svg";
	file[5]="output5.svg";
	file[6]="output6.svg";
	file[7]="output7.svg";
	file[8]="output8.svg";

	while(i<9){		/*all of the about all situation print*/
		if(choose[i][0]=='R' || choose[i][0]=='r'){
			if(second_choose[i][0]=='R' || second_choose[i][0]=='r'){
				ComposedShape ornek(rect_obj[0],small_rect_obj[r]);
				ornek.filename(file[i]);	/*file opening and set file name in composedshape class*/
				ornek.setMainchar(choose[i][0]);	/*it's for main container choose set in composedshape class */
				ornek.setSmallchar(second_choose[i][0]);	/*it's for small shape choose set in composedshape class */
				ornek.optimalfit();		/*this class member function for draw and optimize small shapes coordinate and set in vector small shapes*/
			}
			if(second_choose[i][0]=='T' || second_choose[i][0]=='t'){
				ComposedShape  ornek(rect_obj[0],small_tri_obj[r]);
				ornek.filename(file[i]);
				ornek.setMainchar(choose[i][0]);
				ornek.setSmallchar(second_choose[i][0]);				
				ornek.optimalfit();				
			}
			if(second_choose[i][0]=='C' || second_choose[i][0]=='c'){
				ComposedShape  ornek(rect_obj[0],small_circ_obj[r]);
				ornek.filename(file[i]);
				ornek.setMainchar(choose[i][0]);
				ornek.setSmallchar(second_choose[i][0]);					
				ornek.optimalfit();
			}
			r++;
		}
		
  		else if(choose[i][0]=='T' || choose[i][0]=='t'){
			if(second_choose[i][0]=='R' || second_choose[i][0]=='r'){			
				ComposedShape  ornek(tri_obj[0],small_rect_obj[t]);
				ornek.filename(file[i]);
				ornek.setMainchar(choose[i][0]);
				ornek.setSmallchar(second_choose[i][0]);				
				ornek.optimalfit();
			}
			else if(second_choose[i][0]=='T' || second_choose[i][0]=='t'){		
				ComposedShape  ornek(tri_obj[0],small_tri_obj[t]);
				ornek.filename(file[i]);
				ornek.setMainchar(choose[i][0]);
				ornek.setSmallchar(second_choose[i][0]);				
				ornek.optimalfit();					
			}
			else if(second_choose[i][0]=='C' || second_choose[i][0]=='c'){
				ComposedShape  ornek(tri_obj[0],small_circ_obj[t]);
				ornek.filename(file[i]);
				ornek.setMainchar(choose[i][0]);
				ornek.setSmallchar(second_choose[i][0]);				
				ornek.optimalfit();					
			}
			t++;		  	
   		} 

		else if(choose[i][0]=='C' || choose[i][0]=='c'){	
			if(second_choose[i][0]=='R' || second_choose[i][0]=='r'){
				ComposedShape  ornek(circ_obj[0],small_rect_obj[c]);
				ornek.filename(file[i]);
				ornek.setMainchar(choose[i][0]);
				ornek.setSmallchar(second_choose[i][0]);				
				ornek.optimalfit();					

			}
			if(second_choose[i][0]=='T' || second_choose[i][0]=='t'){
				ComposedShape  ornek(circ_obj[0],small_tri_obj[c]);
				ornek.filename(file[i]);
				ornek.setMainchar(choose[i][0]);
				ornek.setSmallchar(second_choose[i][0]);				
				ornek.optimalfit();					

			}
			if(second_choose[i][0]=='C' || second_choose[i][0]=='c'){		
				ComposedShape  ornek(	circ_obj[0],small_circ_obj[c]);
				ornek.filename(file[i]);
				ornek.setMainchar(choose[i][0]);
				ornek.setSmallchar(second_choose[i][0]);				
				ornek.optimalfit();					
			}
			c++;    			
		}  
		i++; 				
	}
	
	return 0;	
}