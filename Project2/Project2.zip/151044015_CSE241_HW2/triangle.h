#ifndef TRIANGLE_H_
#define TRIANGLE_H_
	#include <iostream>
	#include <fstream>
	#include <cmath>
#include <vector>

using namespace std;

class triangle{
	public:
		triangle();
		triangle(double f_side);		
		double getSide()const;
		void setSide(double side_t);	
		double getPosition_x()const;
		void setPosition_x(double x_koordinat);
		double getPosition_y()const;			
		void setPosition_y(double y_koordinat);
		double getPosition_x2()const;
		void setPosition_x2(double x_koordinat);
		double getPosition_y2()const;	
		void setPosition_y2(double y_koordinat);
		double getPosition_x3()const;
		void setPosition_x3(double x_koordinat);
		double getPosition_y3()const;			
		void setPosition_y3(double y_koordinat);						
		void draw(ofstream *myfile)const;
					
	private:
		double side;
		double x;
		double x2;
		double x3;
		double y;
		double y2;
		double y3;
};

#endif
