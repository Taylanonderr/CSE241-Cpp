	#include "triangle.h"	


		triangle::triangle(){};
		triangle::triangle(double f_side){		/*When the user send side I determine begin coordinates for triangle shape*/
			setSide(f_side);			
		   	  x=0;
		   	  y=(f_side*sqrt(3))/2;
		   	  
		   	  x2=f_side/2;
		   	  y2=0;
		   	  
		   	  x3=f_side;
		   	  y3=(f_side*sqrt(3))/2;  	

		}	
		double triangle::getSide()const{	/*get side for triangle objes for another class or functions which in not this class*/
			return side;
		}
		void triangle::setSide(double side_t){		/*set side for triangle objes for another class or functions which in not this class*/
			side=side_t;
		}		
		double triangle::getPosition_x()const{		/*get coordinate first x for circle objes for another class or functions which in not this class*/
			return x;
		}
		void triangle::setPosition_x(double x_koordinat){	/*set coordinate first x for circle objes for another class or functions which in not this class*/
			x=x_koordinat;
		}
		double triangle::getPosition_y()const{		/*get coordinate first y for circle objes for another class or functions which in not this class*/
			return y;	
		}				
		void triangle::setPosition_y(double y_koordinat){		/*set coordinate first y for circle objes for another class or functions which in not this class*/
			y=y_koordinat;
		}
		double triangle::getPosition_x2()const{		/*get coordinate second x for circle objes for another class or functions which in not this class*/
			return x2;
		}
		void triangle::setPosition_x2(double x_koordinat){		/*set coordinate second x for circle objes for another class or functions which in not this class*/
			x2=x_koordinat;
		}
		double triangle::getPosition_y2()const{		/*get coordinate second y for circle objes for another class or functions which in not this class*/
			return y2;
		}				
		void triangle::setPosition_y2(double y_koordinat){		/*set coordinate second y for circle objes for another class or functions which in not this class*/
			y2=y_koordinat;
		}
		double triangle::getPosition_x3()const{		/*get coordinate third x for circle objes for another class or functions which in not this class*/
			return x3;
		}
		void triangle::setPosition_x3(double x_koordinat){		/*set coordinate third x for circle objes for another class or functions which in not this class*/
			x3=x_koordinat;
		}
		double triangle::getPosition_y3()const{		/*get coordinate third y for circle objes for another class or functions which in not this class*/
			return y3;
		}				
		void triangle::setPosition_y3(double y_koordinat){		/*set coordinate third y for circle objes for another class or functions which in not this class*/
			y3=y_koordinat;
		}							
		void triangle::draw(ofstream *myfile)const{		/*this draw function for main_triangle objes */
		   	  *myfile<<"<polygon points="<<"\"0 "<<y<<" "<<x2<<" 0"<<" "<<x3<<" "<<y3<<"\""<<   // 3 noktanın x ve y koordinatlarını gireceğiz
		  " stroke="<<"\"transparent\""<< " fill="<<"\"red\""<< " stroke-width="<<"\"0.3\""<<"/>\n";	
		}	
