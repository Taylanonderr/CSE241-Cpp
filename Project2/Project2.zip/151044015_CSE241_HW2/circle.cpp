	#include "circle.h"

		circle::circle(){};
		circle::circle(double f_radius){	/*When the user send radius I determine begin coordinate shape*/
			setRadius(f_radius);
			setPosition_x(f_radius);
			setPosition_y(f_radius);			
		};		
		double circle:: getRadius()const{	/*get radius for circle objes for another class or functions which in not this class*/
			return radius;
		}
		void circle::setRadius(double radius_c){	/*set radius for circle objes for another class or functions which in not this class*/
			radius=radius_c;
		}		
		double circle::getPosition_x()const{	/*get coordinate x for circle objes for another class or functions which in not this class*/
			return x;
		}
		void circle::setPosition_x(double x_koordinat){		/*set coordinate x for circle objes for another class or functions which in not this class*/
			x=x_koordinat;
		}
		double circle::getPosition_y()const{	/*get coordinate y for circle objes for another class or functions which in not this class*/
			return y;
		}
		void circle::setPosition_y(double y_koordinat){		/*set coordinate y for circle objes for another class or functions which in not this class*/
			y=y_koordinat;
		}						
		void circle::setShape(char choise){		/*set character for user input to use in composedshape class control in optimalfit function*/
			main_shape = choise;	
		}
		void circle::draw(ofstream *myfile)const{		/*this draw function for main_rectangle objes */
		  	*myfile<<"<circle cx="<<"\""<<getPosition_x() <<"\""<<" cy="<<"\""<<getPosition_y()<<"\""<< " r="<<"\""<<getRadius()<<"\"" <<" stroke="<<"\"green\""<<" fill="<<"\"red\""<<" stroke-width="<<"\"0\""<<" />\n";
					
		}	
	
	
