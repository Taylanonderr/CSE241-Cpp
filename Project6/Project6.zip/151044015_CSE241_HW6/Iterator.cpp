#include "Iterator.h"

namespace my_namespace{
		template<typename C>
			Iterator<C>::Iterator(C obje){
				my_obje=obje;
				iter=my_obje.begin();
			}		
		template<typename C>	
			bool Iterator<C>::hasNext(){
				auto x=iter;
				if(my_obje.end()!=x++)
					return true;
				return false;
			}
		template<typename C>	
			typename C::iterator  Iterator<C>::next(){
				//auto a=std::next(iter, 1);
					//iter=my_obje.end();
				if(iter != my_obje.end()){
					//cout<<"sonuc :"<<*iter<<endl;
					std::advance (iter,1);
				}
				//cout<<"son :"<<*a<<endl;

				return iter;
			}

		template<typename C>	
			void Iterator<C>::remove(){
	           iter = my_obje.erase(iter);
	           
			}

		template<typename C>	
			C Iterator<C>::get_obje(){
				return my_obje;
			}

		template<typename C>	
			typename C::iterator Iterator<C>::get_iter(){
				return iter;
			}

		template<typename C>	
			void Iterator<C>::iter_begin(){
				iter=my_obje.begin();
			}
	}