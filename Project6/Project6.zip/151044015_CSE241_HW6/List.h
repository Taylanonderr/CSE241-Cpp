#ifndef LIST_H_
#define LIST_H_
#include <iostream>
#include "Collection.h"

using namespace std;
namespace my_namespace{

	template<typename E,typename C>

	class List : public Collection<E,C>{
	public:
		List(){}

	};
}
#endif	
