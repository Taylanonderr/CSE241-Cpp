#ifndef ARRAYLIST_H_
#define ARRAYLIST_H_
#include <iostream>
#include <typeinfo>
#include <list> 
#include <set> 
#include <vector> 
#include "List.h"
#include "Iterator.h"
using namespace std;

namespace my_namespace{
	template<typename E,typename C>
		class ArrayList : public List<E,C>{
		public:
			ArrayList(){}
			ArrayList(C &obje);		
			virtual void add(E element);
			virtual void addAll(C C_element);
			virtual void clear();
			virtual bool contains(E element);
			virtual bool containsAll(C C_element);
			virtual bool isEmpty();
			virtual void remove(E e);
			virtual void removeAll(C C_element);
			virtual void retainAll(C C_element);
			virtual int size();		
			Collection<E,C> &iterator();
			C get_collection();
			Iterator<C> get_iterate();				
		private:
			C array_obje;
			Iterator<C> iterate;

		};
	}	
#endif

