#ifndef SET_H_
#define SET_H_
#include <iostream>
#include <typeinfo>
#include <set> 
#include <list> 
#include <vector>
#include "Collection.h"

using namespace std;
namespace my_namespace{

	template<typename E,typename C>

	class Set : public Collection<E,C>{
	public:
		Set(){}

	};
}
#endif	
