#ifndef Iterator_H_
#define Iterator_H_
#include <iostream>
#include <typeinfo>
#include <set> 
#include <list> 
#include <vector> 

using namespace std;


namespace my_namespace{
	template<typename C>
		class Iterator {
		public:
			Iterator(){

			}
			Iterator(C obje);		
			bool hasNext();
			typename C::iterator  next();
			void remove();
			C get_obje();
			typename C::iterator get_iter();
			void iter_begin();	
		private:
			C my_obje;
			typename C::iterator iter;
		};
	}	
#endif

