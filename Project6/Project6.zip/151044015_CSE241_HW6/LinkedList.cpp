#include "LinkedList.h"
using namespace std;

namespace my_namespace{

		template<typename E,typename C>	
			LinkedList<E,C>::LinkedList(C &obje){		//linkedlist constructure for copy anything if 
				linked_obje=obje;
			}		
		template<typename E,typename C>	
			 void LinkedList<E,C>::add(E element){
				int i=0;
				auto iter=linked_obje.end();
				linked_obje.insert(iter,element);	
							
			}
			template<typename E,typename C>		
			 void LinkedList<E,C>::addAll(C C_element){		//	Adds all of the elements in the specified collection to this collection
				int flag=0;
				iterate=Iterator<C>(linked_obje);
				Iterator<C> temp(C_element);
				auto iter=linked_obje.begin();
				auto iter2=C_element.begin();
				while(temp.hasNext()){
					while(iterate.hasNext()){				
						iter++;
						iterate.next();				
					}
					linked_obje.insert(iter,*iter2);				
					iter2=temp.next();	
					iter=linked_obje.begin();																
				}
												
			}
			template<typename E,typename C>	
			 void LinkedList<E,C>::clear(){
				linked_obje.clear();
			}

			template<typename E,typename C>	
			bool LinkedList<E,C>::contains(E element){		//check for same element in a collection if collection has same element return true,if has not same elemnt return false
				iterate=Iterator<C>(linked_obje);
				auto iter=linked_obje.begin();
				while(iterate.hasNext()){			//check with iterator class functions base condition
					if(element==*iter){
						return true;
					}
					iter=iterate.next();			//next function return collection's next element
				}
				return false;			
			}

			template<typename E,typename C>	
			bool LinkedList<E,C>::containsAll(C C_element){
				int flag=0;
				iterate=Iterator<C>(linked_obje);
				auto iter=linked_obje.begin();
				auto iter2=C_element.begin();
				while(iterate.hasNext()){
					Iterator<C> temp(C_element);
					while(temp.hasNext()){				
						if(*iter==*iter2){
							flag=1;
						}
						iter2=temp.next();												
					}

					if(flag==0){					
						return false;		//this concidition for collection does not have any element of container 
					}
					iter=iterate.next();
					auto iter2=C_element.begin();

					flag=0;
				}
				return true;				
			}

			template<typename E,typename C>	
			bool LinkedList<E,C>::isEmpty(){
				auto iter=linked_obje.begin();
				if(iter==linked_obje.end())
					return true;
				return false;
			}
			
			template<typename E,typename C>	
			void LinkedList<E,C>::remove(E e){
			    auto iter=linked_obje.begin();
				iterate=Iterator<C>(linked_obje);
				while(iterate.hasNext()){  	//check with iterator class functions base condition returns true if the iteration has more elements.
					if(e==*iter){
			            iterate.remove();
						iter=linked_obje.erase(iter);
      
					}
					else
						iter++;
						iterate.next();		//next function return collection's next element
				}		
  				
			}

			template<typename E,typename C>	
			void LinkedList<E,C>::removeAll(C C_element){
				int flag=0;
				iterate=Iterator<C>(linked_obje);
				auto iter=linked_obje.begin();
				auto iter2=C_element.begin();
				while(iterate.hasNext()){				//check with iterator class functions returns true if the iteration has more elements in collection.
					Iterator<C> temp(C_element);				
					while(temp.hasNext()){				//check with iterator class functions returns true if the iteration has more elements in specified collection.
						if(*iter==*iter2){
							flag=1;		//it won't erase
						}	
									//next iteration with iteratre class											
						iter2=temp.next();
					}

					if(flag==1){		
			            iterate.remove();							
						iter=linked_obje.erase(iter);		//delete element in collection
					}
					else
						iter++;			//next iteration 
						iterate.next();		//next function return collection's next element					
					iter2=C_element.begin();


					flag=0;
				}
			}

			template<typename E,typename C>	
			void LinkedList<E,C>::retainAll(C C_element){		//Retains only the elements in this collection that are contained in the specified Collection
				int flag=0;
				iterate=Iterator<C>(linked_obje);
				auto iter=linked_obje.begin();
				auto iter2=C_element.begin();
				while(iterate.hasNext()){				//check with iterator class functions returns true if the iteration has more elements in collection.
					Iterator<C> temp(C_element);
					while(temp.hasNext()){				//check with iterator class functions returns true if the iteration has more elements in specified collection.
						if(*iter==*iter2){
							flag=1;		//it won't erase
						}	
						iter2=temp.next();			//next iteration with iteratre class											
					}

					if(flag==0){		
						iter=linked_obje.erase(iter);		//delete element in collection
					}
					else
						iter++;				//next iteration 
						iterate.next();		//next function return collection's next element					
					iter2=C_element.begin();

					flag=0;
				}			
			}

			template<typename E,typename C>	
			int LinkedList<E,C>::size(){
				int counter=0;
				iterate=Iterator<C>(linked_obje);
				auto iter=linked_obje.begin();
				while(iterate.hasNext()){			//check with iterator class functions base condition
					counter++;
					iter=iterate.next();			//next function return collection's next element
				}
				return counter;	
			}
			
			template<typename E,typename C>	
			typename C::iterator LinkedList<E,C>::element(){
				if(isEmpty()){
					throw LinkedlistError(0); 		//throw function vector shouldn't return empty
				}				
				return linked_obje.begin();
			}

			template<typename E,typename C>	
			void LinkedList<E,C>::offer(E e){
				int i=0;
				auto iter=linked_obje.end();
					linked_obje.insert(iter,e);	
			}

			template<typename E,typename C>	
			typename C::iterator LinkedList<E,C>::poll(){
				auto temp=linked_obje.begin();				
				if(isEmpty()){
					throw LinkedlistError(); 	//throw function vector shouldn't return empty
				}
				else{
					linked_obje.erase(linked_obje.begin());					
				}
				return temp;

			}			
			
			template<typename E,typename C>			
			Collection<E,C> &LinkedList<E,C>::iterator(){
				//return *this;
			}
			template<typename E,typename C>	
			C LinkedList<E,C>::get_collection(){
				return linked_obje;
			}

			
			template<typename E,typename C>	
			Iterator<C> LinkedList<E,C>::get_iterate(){
				return iterate;
			}			
	}		