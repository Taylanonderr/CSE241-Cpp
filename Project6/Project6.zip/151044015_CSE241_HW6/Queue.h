#ifndef QUEUE_H_
#define QUEUE_H_
#include <iostream>
#include "Collection.h"
#include "Iterator.h"
#include <iostream>
#include <set> 
#include <list> 
#include <vector> 

using namespace std;
namespace my_namespace{

	template<typename E,typename C>

	class Queue : public Collection<E,C>{
	public:
		virtual void add(E e)=0;
		virtual void offer(E e)=0;
		virtual typename C::iterator element()=0;		
		virtual typename C::iterator poll()=0;
	};
}
#endif	
