#include "ArrayList.h"

namespace my_namespace{
			template<typename E,typename C>
			ArrayList<E,C>::ArrayList(C &obje){
				array_obje=obje;
			}

			template<typename E,typename C>		
			void ArrayList<E,C>::add(E element){		//add specified element in collection
				int i=0;
				auto iter=array_obje.end();
				array_obje.insert(iter,element);
											
			}

			template<typename E,typename C>
			void ArrayList<E,C>::addAll(C C_element){		//	Adds all of the elements in the specified collection to this collection
				int flag=0;
				iterate=Iterator<C>(array_obje);
				Iterator<C> temp(C_element);
				auto iter=array_obje.begin();
				auto iter2=C_element.begin();
				while(temp.hasNext()){
					while(iterate.hasNext()){				
						iter++;
						iterate.next();				
					}
					array_obje.insert(iter,*iter2);				
					iter2=temp.next();	
					iter=array_obje.begin();																
				}
												
			}

			template<typename E,typename C>
			void ArrayList<E,C>::clear(){			//clear collection elements
				array_obje.clear();
			}

			template<typename E,typename C>
			bool ArrayList<E,C>::contains(E element){		//check for same element in a collection if collection has same element return true,if has not same elemnt return false
				iterate=Iterator<C>(array_obje);
				auto iter=array_obje.begin();
				while(iterate.hasNext()){			//check with iterator class functions base condition
					if(element==*iter){
						return true;
					}
					iter=iterate.next();			//next function return collection's next element
				}
				return false;			
			}

			template<typename E,typename C>
			bool ArrayList<E,C>::containsAll(C C_element){
				int flag=0;
				iterate=Iterator<C>(array_obje);
				auto iter=array_obje.begin();
				auto iter2=C_element.begin();
				while(iterate.hasNext()){
					Iterator<C> temp(C_element);
					while(temp.hasNext()){				
						if(*iter==*iter2){
							flag=1;
						}
						iter2=temp.next();												
					}

					if(flag==0){					
						return false;		//this concidition for collection does not have any element of container 
					}
					iter=iterate.next();
					auto iter2=C_element.begin();

					flag=0;
				}
				return true;				
			}

			template<typename E,typename C>
			bool ArrayList<E,C>::isEmpty(){
				auto iter=array_obje.begin();
				if(iter==array_obje.end())
					return true;
				return false;
			}

			template<typename E,typename C>
			void ArrayList<E,C>::remove(E e){
				auto iter=array_obje.begin();
					iterate=Iterator<C>(array_obje);

				while(iterate.hasNext()){  	//check with iterator class functions base condition returns true if the iteration has more elements.
					if(e==*iter){
			            iterate.remove();
						iter=array_obje.erase(iter);
      
					}
					else
						iter++;
						iterate.next();		//next function return collection's next element
				}		
			}     

			template<typename E,typename C>
			void ArrayList<E,C>::removeAll(C C_element){
				int flag=0;
				iterate=Iterator<C>(array_obje);
				auto iter=array_obje.begin();
				auto iter2=C_element.begin();
				while(iterate.hasNext()){				//check with iterator class functions returns true if the iteration has more elements in collection.
					Iterator<C> temp(C_element);				
					while(temp.hasNext()){				//check with iterator class functions returns true if the iteration has more elements in specified collection.
						if(*iter==*iter2){
							flag=1;		//it won't erase
						}	
									//next iteration with iteratre class											
						iter2=temp.next();
					}

					if(flag==1){		
			            iterate.remove();							
						iter=array_obje.erase(iter);		//delete element in collection
					}
					else
						iter++;			//next iteration 
						iterate.next();		//next function return collection's next element					
					iter2=C_element.begin();


					flag=0;
				}
			}

			template<typename E,typename C>
			void ArrayList<E,C>::retainAll(C C_element){		//Retains only the elements in this collection that are contained in the specified Collection
				int flag=0;
				iterate=Iterator<C>(array_obje);
				auto iter=array_obje.begin();
				auto iter2=C_element.begin();
				while(iterate.hasNext()){				//check with iterator class functions returns true if the iteration has more elements in collection.
					Iterator<C> temp(C_element);
					while(temp.hasNext()){				//check with iterator class functions returns true if the iteration has more elements in specified collection.
						if(*iter==*iter2){
							flag=1;		//it won't erase
						}	
						iter2=temp.next();			//next iteration with iteratre class											
					}

					if(flag==0){		
						iter=array_obje.erase(iter);		//delete element in collection
					}
					else
						iter++;				//next iteration 
						iterate.next();		//next function return collection's next element					
					iter2=C_element.begin();

					flag=0;
				}			  	    			
			}

			template<typename E,typename C>
			int ArrayList<E,C>::size(){
				int counter=0;
				iterate=Iterator<C>(array_obje);
				auto iter=array_obje.begin();
				while(iterate.hasNext()){			//check with iterator class functions base condition
					counter++;
					iter=iterate.next();			//next function return collection's next element
				}
				return counter;	
			}			

			template<typename E,typename C>
			Collection<E,C> &ArrayList<E,C>::iterator(){
				return *this;
			}
			template<typename E,typename C>	
			C ArrayList<E,C>::get_collection(){
				return array_obje;
			}

			
			template<typename E,typename C>	
			Iterator<C> ArrayList<E,C>::get_iterate(){
				return iterate;
			}	


}