#ifndef LINKEDLIST_H_
#define LINKEDLIST_H_
#include <iostream>
#include <typeinfo>
#include <list> 
#include <set> 
#include <vector> 
#include "List.h"
#include "Queue.h"
#include "Iterator.h"
using namespace std;

namespace my_namespace{
		class LinkedlistError{
		public:
			LinkedlistError(){}
			LinkedlistError(int a){
				cout<<"Error in element function vector should not be empty for pool function"<<endl;
			}
		}; 
	template<typename E,typename C>
		class LinkedList : public List<E,C> , public Queue<E,C>{
		public:
			LinkedList(){}
			LinkedList(C &obje);	
			virtual void add(E element);
			virtual void addAll(C C_element);
			virtual void clear();
			virtual bool contains(E element);
			virtual bool containsAll(C C_element);
			virtual bool isEmpty();
			virtual void remove(E e);
			virtual void removeAll(C C_element);
			virtual void retainAll(C C_element);
			virtual int size();
			typename C::iterator element();
			typename C::iterator poll();			
			virtual	void offer(E e);
			Collection<E,C> &iterator();
			C get_collection();
			Iterator<C> get_iterate();			
				
		private:
			C linked_obje;
			Iterator<C> iterate;
			
			//Iterator<E> x;
		};
	}	
#endif

