
#include <iostream>
#include <vector>
#include <set> 
#include <list> 
#include "Collection.h"
#include "Set.h"
#include "HashSet.h"
#include "HashSet.cpp"
#include "ArrayList.h"
#include "ArrayList.cpp"
#include "LinkedList.h"
#include "LinkedList.cpp"
#include "Iterator.h"
#include "Iterator.cpp"
#include <string>
using namespace std;
using namespace my_namespace;


int main(){
try{
	Collection<vector<int>,vector<int> > *a;
	Collection<string,vector<string>> *b;
	std::set<string > temp_string1{"Taylan","Deneme","CSE241"};	
	Iterator<set<string >> iter_set(temp_string1);
	auto iter_set1=temp_string1.begin();	
	cout<<"Contains String Set  : ";	
	while(iter_set.hasNext()){			//check with iterator class functions base condition
		cout<<" "<<*iter_set1<<" ";					
		iter_set1=iter_set.next();			//next function return collection's next element
	}
	cout<<endl;

	std::list<string > temp_string2{"Taylan","Deneme","CSE241"};					
	Iterator<list<string >> iter_list(temp_string2);
	auto iter_list1=temp_string2.begin();	
	cout<<"Contains String List : ";
	while(iter_list.hasNext()){			//check with iterator class functions base condition
		cout<<" "<<*iter_list1<<" ";					
		iter_list1=iter_list.next();			//next function return collection's next element
	}
	cout<<endl;

	std::vector<string > temp_string3{"Taylan","Deneme","CSE241"};	
	Iterator< vector<string >> iter_vector(temp_string3);
	auto iter_vector1=temp_string3.begin();	
	cout<<"Contains String Vector : ";	
	while(iter_vector.hasNext()){			//check with iterator class functions base condition
		cout<<" "<<*iter_vector1<<" ";					
		iter_vector1=iter_vector.next();			//next function return collection's next element
	}
	cout<<endl;	

	std::set<int > temp_int1{10,25,50};	
	Iterator<set<int >> iter_int_set(temp_int1);
	auto iter_set2=temp_int1.begin();
	cout<<"Contains Int Set  : ";	
	while(iter_int_set.hasNext()){			//check with iterator class functions base condition
		cout<<" "<<*iter_set2<<" ";					
		iter_set2=iter_int_set.next();			//next function return collection's next element
	}
	cout<<endl;

	std::list<int > temp_int2{10,25,50};					
	Iterator<list<int >> iter_int_list(temp_int2);
	auto iter_list2=temp_int2.begin();	
	cout<<"Contains Int List : ";
	while(iter_int_list.hasNext()){			//check with iterator class functions base condition
		cout<<" "<<*iter_list2<<" ";					
		iter_list2=iter_int_list.next();			//next function return collection's next element
	}
	cout<<endl;

	std::vector<int > temp_int3{10,25,50};	
	Iterator< vector<int >> iter_int_vector(temp_int3);
	auto iter_vector2=temp_int3.begin();	
	cout<<"Contains Int Vector : ";	
	while(iter_int_vector.hasNext()){			//check with iterator class functions base condition
		cout<<" "<<*iter_vector2<<" ";					
		iter_vector2=iter_int_vector.next();			//next function return collection's next element
	}
	cout<<endl;		

	HashSet<int,set<int> > hash_set_int(temp_int1);
	HashSet<int,list<int> > hash_list_int(temp_int2);
	HashSet<int,vector<int> > hash_vector_int(temp_int3);

	ArrayList<int,set<int> > array_set_int(temp_int1);
	ArrayList<int,list<int> > array_list_int(temp_int2);
	ArrayList<int,vector<int> > array_vector_int(temp_int3);

	LinkedList<int,set<int> > linked_set_int(temp_int1);
	LinkedList<int,list<int> > linked_list_int(temp_int2);
	LinkedList<int,vector<int> > linked_vector_int(temp_int3);

	std::set<string > test_string1{"Taylan","Saglık","Huzur"};	
	std::list<string > test_string2{"Taylan","Saglık","Huzur"};	
	std::vector<string > test_string3{"Taylan","Saglık","Huzur"};	


	std::set<int> test_int1{10,4,43};	
	std::list<int> test_int2{10,4,43};	
	std::vector<int> test_int3{10,4,43};


	std::set<string > empty_string1{""};
	std::list<string > empty_string2{""};
	std::vector<string > empty_string3{"selam","baba"};
	HashSet<string,set<string> > hash_set_string(empty_string1);
	HashSet<string,list<string> > hash_list_string(empty_string2);
	HashSet<string,vector<string> > hash_vector_string(empty_string3);

	ArrayList<string,set<string> > array_set_string(empty_string1);
	ArrayList<string,list<string> > array_list_string(empty_string2);
	ArrayList<string,vector<string> > array_vector_string(empty_string3);

	LinkedList<string,set<string> > linked_set_string(empty_string1);
	LinkedList<string,list<string> > linked_list_string(empty_string2);
	LinkedList<string,vector<string> > linked_vector_string(empty_string3);


	cout<<"\n-----HashSet set string ---\n";

	hash_set_string.add("Gebze");
	hash_set_string.add("Önder");	

	Iterator<set<string >> hash_iter_add(hash_set_string.get_collection());	
	auto iter_hash_set=hash_set_string.get_collection().begin();
	cout<<"Add ---- functions element :   ";
	while(hash_iter_add.hasNext()){
		cout<<" "<<*iter_hash_set<<" ";					
		iter_hash_set=hash_iter_add.next();
	}

	hash_set_string.addAll(temp_string1);
	Iterator<set<string >> hash_iter_addAll(hash_set_string.get_collection());	
	auto iter_addAll=hash_set_string.get_collection().begin();
	cout<<"\nAddAll ----- functions element :   ";
	while(hash_iter_addAll.hasNext()){
		cout<<" "<<*iter_addAll<<" ";					
		iter_addAll=hash_iter_addAll.next();
	}	

	cout<<"\nSize ---- function and Collection size :  "<<hash_set_string.size();

	if(hash_set_string.contains("Gebze")){
		cout<<"\nContains ---- Collection has a Gebze"<<endl;
	}
	if(!hash_set_string.contains("Kocaeli")){
		cout<<"Contains ---- Collection has not a Kocaeli"<<endl;
	}
	if(hash_set_string.containsAll(temp_string1)){
		cout<<"ContainsAll ---- Collection has a specified all elements"<<endl;
	}
	else
		cout<<"ContainsAll ---- Collection has not a specified all elements"<<endl;

	if(hash_set_string.isEmpty()){
		cout<<"Isempty ---- Collection is empty"<<endl;
	}
	else
		cout<<"Isempty ---- Collection is not empty"<<endl;	

	hash_set_string.remove("Gebze");
	hash_set_string.removeAll(test_string1);
	Iterator<set<string >> hash_iter_remove(hash_set_string.get_collection());	
	auto iter_removeall=hash_set_string.get_collection().begin();
	cout<<"RemoveALl ---- functions element :   ";
	while(hash_iter_remove.hasNext()){
		cout<<" "<<*iter_removeall<<" ";					
		iter_removeall=hash_iter_remove.next();
	}

	hash_set_string.add("Taylan");	
	cout<<"\nAdd ---- functions element :   Taylan  I called remove and retain reverse \nfunction so I want to print screen after retain same elemnt with collection";

	cout<<endl;
	hash_set_string.retainAll(test_string1);
	Iterator<set<string >> hash_iter_retain(hash_set_string.get_collection());	
	auto iter_retainall=hash_set_string.get_collection().begin();
	cout<<"RetainALl ---- functions element :   ";
	while(hash_iter_retain.hasNext()){
		cout<<" "<<*iter_retainall<<" ";					
		iter_retainall=hash_iter_retain.next();
	}
	cout<<endl;









	cout<<"\n----HashSet list string ---\n";

	hash_list_string.add("Gebze");
	hash_list_string.add("Önder");	

	Iterator<list<string >> hash_listadd(hash_list_string.get_collection());	
	auto listhash_list=hash_list_string.get_collection().begin();
	cout<<"Add ---- functions element :   ";
	while(hash_listadd.hasNext()){
		cout<<" "<<*listhash_list<<" ";					
		listhash_list=hash_listadd.next();
	}

	hash_list_string.addAll(temp_string2);
	Iterator<list<string >> hash_listaddAll(hash_list_string.get_collection());	
	auto listaddAll=hash_list_string.get_collection().begin();
	cout<<"\nAddAll ----- functions element :   ";
	while(hash_listaddAll.hasNext()){
		cout<<" "<<*listaddAll<<" ";					
		listaddAll=hash_listaddAll.next();
	}	

	cout<<"\nSize ---- function and Collection size :  "<<hash_list_string.size();

	if(hash_list_string.contains("Gebze")){
		cout<<"\nContains ---- Collection has a Gebze"<<endl;
	}
	if(!hash_list_string.contains("Kocaeli")){
		cout<<"Contains ---- Collection has not a Kocaeli"<<endl;
	}
	if(hash_list_string.containsAll(temp_string2)){
		cout<<"ContainsAll ---- Collection has a specified all elements"<<endl;
	}
	else
		cout<<"ContainsAll ---- Collection has not a specified all elements"<<endl;

	if(hash_list_string.isEmpty()){
		cout<<"Isempty ---- Collection is empty"<<endl;
	}
	else
		cout<<"Isempty ---- Collection is not empty"<<endl;	

	hash_list_string.remove("Gebze");
	hash_list_string.removeAll(test_string2);
	Iterator<list<string >> hash_listremove(hash_list_string.get_collection());	
	auto listremoveall=hash_list_string.get_collection().begin();
	cout<<"RemoveALl ---- functions element :   ";
	while(hash_listremove.hasNext()){
		cout<<" "<<*listremoveall<<" ";					
		listremoveall=hash_listremove.next();
	}

	hash_list_string.add("Taylan");	
	cout<<"\nAdd ---- functions element :   Taylan  I called remove and retain reverse \nfunction so I want to print screen after retain same elemnt with collection";

	cout<<endl;
	hash_list_string.retainAll(test_string2);
	Iterator<list<string >> hash_listretain(hash_list_string.get_collection());	
	auto listretainall=hash_list_string.get_collection().begin();
	cout<<"RetainALl ---- functions element :   ";
	while(hash_listretain.hasNext()){
		cout<<" "<<*listretainall<<" ";					
		listretainall=hash_listretain.next();
	}
	cout<<endl;




	cout<<"\n------HashSet Set int Functions ----\n";

	hash_set_int.add(30);
	hash_set_int.add(2);	

	Iterator<set<int >> hash_setadd(hash_set_int.get_collection());	
	auto sethash_set=hash_set_int.get_collection().begin();
	cout<<"Add ---- functions element :   ";
	while(hash_setadd.hasNext()){
		cout<<" "<<*sethash_set<<" ";					
		sethash_set=hash_setadd.next();
	}

	hash_set_int.addAll(test_int1);
	Iterator<set<int >> hash_setaddAll(hash_set_int.get_collection());	
	auto setaddAll=hash_set_int.get_collection().begin();
	cout<<"\nAddAll ----- functions element :   ";
	while(hash_setaddAll.hasNext()){
		cout<<" "<<*setaddAll<<" ";					
		setaddAll=hash_setaddAll.next();
	}	

	cout<<"\nSize ---- function and Collection size :  "<<hash_set_int.size();

	if(hash_set_int.contains(30)){
		cout<<"\nContains ---- Collection has a element 30"<<endl;
	}
	if(!hash_set_int.contains(100)){
		cout<<"Contains ---- Collection has not a element 100"<<endl;
	}
	if(hash_set_int.containsAll(temp_int1)){
		cout<<"ContainsAll ---- Collection has a specified all elements"<<endl;
	}
	else
		cout<<"ContainsAll ---- Collection has not a specified all elements"<<endl;

	if(hash_set_int.isEmpty()){
		cout<<"Isempty ---- Collection is empty"<<endl;
	}
	else
		cout<<"Isempty ---- Collection is not empty"<<endl;	

	hash_set_int.remove(30);
	hash_set_int.removeAll(test_int1);
	Iterator<set<int >> hash_setremove(hash_set_int.get_collection());	
	auto setremoveall=hash_set_int.get_collection().begin();
	cout<<"RemoveALl ---- functions element :   ";
	while(hash_setremove.hasNext()){
		cout<<" "<<*setremoveall<<" ";					
		setremoveall=hash_setremove.next();
	}

	hash_set_int.add(10);	
	cout<<"\nAdd ---- functions element :   30  I called remove and retain reverse \nfunction so I want to print screen after retain same elemnt with collection";

	cout<<endl;
	hash_set_int.retainAll(test_int1);
	Iterator<set<int >> hash_setretain(hash_set_int.get_collection());	
	auto setretainall=hash_set_int.get_collection().begin();
	cout<<"RetainALl ---- functions element :   ";
	while(hash_setretain.hasNext()){
		cout<<" "<<*setretainall<<" ";					
		setretainall=hash_setretain.next();
	}
	cout<<endl;






	cout<<"\n------HashSet List İnt Functions ----\n";

	hash_list_int.add(30);
	hash_list_int.add(2);	

	Iterator<list<int >> hash_listaddint(hash_list_int.get_collection());	
	auto hash_listhash_list=hash_list_int.get_collection().begin();
	cout<<"Add ---- functions element :   ";
	while(hash_listaddint.hasNext()){
		cout<<" "<<*hash_listhash_list<<" ";					
		hash_listhash_list=hash_listaddint.next();
	}

	hash_list_int.addAll(test_int2);
	Iterator<list<int >> hash_listaddAllint(hash_list_int.get_collection());	
	auto hash_list_iteraddAllint=hash_list_int.get_collection().begin();
	cout<<"\nAddAll ----- functions element :   ";
	while(hash_listaddAll.hasNext()){
		cout<<" "<<*hash_list_iteraddAllint<<" ";					
		hash_list_iteraddAllint=hash_listaddAllint.next();
	}	

	cout<<"\nSize ---- function and Collection size :  "<<hash_list_int.size();

	if(hash_list_int.contains(30)){
		cout<<"\nContains ---- Collection has a element 30"<<endl;
	}
	if(!hash_list_int.contains(100)){
		cout<<"Contains ---- Collection has not a element 100"<<endl;
	}
	if(hash_list_int.containsAll(temp_int2)){
		cout<<"ContainsAll ---- Collection has a specified all elements"<<endl;
	}
	else
		cout<<"ContainsAll ---- Collection has not a specified all elements"<<endl;

	if(hash_list_int.isEmpty()){
		cout<<"Isempty ---- Collection is empty"<<endl;
	}
	else
		cout<<"Isempty ---- Collection is not empty"<<endl;	

	hash_list_int.remove(30);
	hash_list_int.removeAll(test_int2);
	Iterator<list<int >> hash_listremoveint(hash_list_int.get_collection());	
	auto hash_list_iter_removeall=hash_list_int.get_collection().begin();
	cout<<"RemoveALl ---- functions element :   ";
	while(hash_listremoveint.hasNext()){
		cout<<" "<<*hash_list_iter_removeall<<" ";					
		hash_list_iter_removeall=hash_listremoveint.next();
	}

	hash_list_int.add(10);	
	cout<<"\nAdd ---- functions element :   30  I called remove and retain reverse \nfunction so I want to print screen after retain same elemnt with collection";

	cout<<endl;
	hash_list_int.retainAll(test_int2);
	Iterator<list<int >> hash_listretainint(hash_list_int.get_collection());	
	auto hash_list_iter_retainall=hash_list_int.get_collection().begin();
	cout<<"RetainALl ---- functions element :   ";
	while(hash_listretainint.hasNext()){
		cout<<" "<<*hash_list_iter_retainall<<" ";					
		hash_list_iter_retainall=hash_listretainint.next();
	}
	cout<<endl;




cout<<"\n-----ArrayList Set String ---\n";

	array_set_string.add("Gebze");
	array_set_string.add("Önder");	

	Iterator<set<string >> array_iter_add(array_set_string.get_collection());	
	auto iter_array_set=array_set_string.get_collection().begin();
	cout<<"Add ---- functions element :   ";
	while(array_iter_add.hasNext()){
		cout<<" "<<*iter_array_set<<" ";					
		iter_array_set=array_iter_add.next();
	}

	array_set_string.addAll(temp_string1);
	Iterator<set<string >> array_iter_addAll(array_set_string.get_collection());	
	auto iter_addAll_array=array_set_string.get_collection().begin();
	cout<<"\nAddAll ----- functions element :   ";
	while(array_iter_addAll.hasNext()){
		cout<<" "<<*iter_addAll_array<<" ";					
		iter_addAll_array=array_iter_addAll.next();
	}	

	cout<<"\nSize ---- function and Collection size :  "<<array_set_string.size();

	if(array_set_string.contains("Gebze")){
		cout<<"\nContains ---- Collection has a Gebze"<<endl;
	}
	if(!array_set_string.contains("Kocaeli")){
		cout<<"Contains ---- Collection has not a Kocaeli"<<endl;
	}
	if(array_set_string.containsAll(temp_string1)){
		cout<<"ContainsAll ---- Collection has a specified all elements"<<endl;
	}
	else
		cout<<"ContainsAll ---- Collection has not a specified all elements"<<endl;

	if(array_set_string.isEmpty()){
		cout<<"Isempty ---- Collection is empty"<<endl;
	}
	else
		cout<<"Isempty ---- Collection is not empty"<<endl;	

	array_set_string.remove("Gebze");
	array_set_string.removeAll(test_string1);
	Iterator<set<string >> array_iter_remove(array_set_string.get_collection());	
	auto iter_removeall_array=array_set_string.get_collection().begin();
	cout<<"RemoveALl ---- functions element :   ";
	while(array_iter_remove.hasNext()){
		cout<<" "<<*iter_removeall_array<<" ";					
		iter_removeall_array=array_iter_remove.next();
	}

	array_set_string.add("Taylan");	
	cout<<"\nAdd ---- functions element :   Taylan  I called remove and retain reverse \nfunction so I want to print screen after retain same elemnt with collection";

	cout<<endl;
	array_set_string.retainAll(test_string1);
	Iterator<set<string >> array_iter_retain(array_set_string.get_collection());	
	auto iter_retainall_array=array_set_string.get_collection().begin();
	cout<<"RetainALl ---- functions element :   ";
	while(array_iter_retain.hasNext()){
		cout<<" "<<*iter_retainall_array<<" ";					
		iter_retainall_array=array_iter_retain.next();
	}
	cout<<endl;





cout<<"\n-----ArrayList List String ---\n";

	array_list_string.add("Gebze");
	array_list_string.add("Önder");	

	Iterator<list<string >> array_iter_add_string(array_list_string.get_collection());	
	auto iter_array_list_string=array_list_string.get_collection().begin();
	cout<<"Add ---- functions element :   ";
	while(array_iter_add_string.hasNext()){
		cout<<" "<<*iter_array_list_string<<" ";					
		iter_array_list_string=array_iter_add_string.next();
	}

	array_list_string.addAll(temp_string2);
	Iterator<list<string >> array_iter_addAll_string(array_list_string.get_collection());	
	auto iter_addAll_array_string=array_list_string.get_collection().begin();
	cout<<"\nAddAll ----- functions element :   ";
	while(array_iter_addAll_string.hasNext()){
		cout<<" "<<*iter_addAll_array_string<<" ";					
		iter_addAll_array_string=array_iter_addAll_string.next();
	}	

	cout<<"\nSize ---- function and Collection size :  "<<array_list_string.size();

	if(array_list_string.contains("Gebze")){
		cout<<"\nContains ---- Collection has a Gebze"<<endl;
	}
	if(!array_list_string.contains("Kocaeli")){
		cout<<"Contains ---- Collection has not a Kocaeli"<<endl;
	}
	if(array_list_string.containsAll(temp_string2)){
		cout<<"ContainsAll ---- Collection has a specified all elements"<<endl;
	}
	else
		cout<<"ContainsAll ---- Collection has not a specified all elements"<<endl;

	if(array_list_string.isEmpty()){
		cout<<"Isempty ---- Collection is empty"<<endl;
	}
	else
		cout<<"Isempty ---- Collection is not empty"<<endl;	

	array_list_string.remove("Gebze");
	array_list_string.removeAll(test_string2);
	Iterator<list<string >> array_iter_remove_string(array_list_string.get_collection());	
	auto iter_removeall_array_string=array_list_string.get_collection().begin();
	cout<<"RemoveALl ---- functions element :   ";
	while(array_iter_remove_string.hasNext()){
		cout<<" "<<*iter_removeall_array_string<<" ";					
		iter_removeall_array_string=array_iter_remove_string.next();
	}

	array_list_string.add("Taylan");	
	cout<<"\nAdd ---- functions element :   Taylan  I called remove and retain reverse \nfunction so I want to print screen after retain same elemnt with collection";

	cout<<endl;
	array_list_string.retainAll(test_string2);
	Iterator<list<string >> array_iter_retain_string(array_list_string.get_collection());	
	auto iter_retainall_array_string=array_list_string.get_collection().begin();
	cout<<"RetainALl ---- functions element :   ";
	while(array_iter_retain_string.hasNext()){
		cout<<" "<<*iter_retainall_array_string<<" ";					
		iter_retainall_array_string=array_iter_retain_string.next();
	}
	cout<<endl;







cout<<"\n-----linkedList List String ---\n";

	linked_list_string.add("Gebze");
	linked_list_string.add("Önder");	

	Iterator<list<string >> linked_iter_add_string(linked_list_string.get_collection());	
	auto iter_linked_list_string=linked_list_string.get_collection().begin();
	cout<<"Add ---- functions element :   ";
	while(linked_iter_add_string.hasNext()){
		cout<<" "<<*iter_linked_list_string<<" ";					
		iter_linked_list_string=linked_iter_add_string.next();
	}

	linked_list_string.addAll(temp_string2);
	Iterator<list<string >> linked_iter_addAll_string(linked_list_string.get_collection());	
	auto iter_addAll_linked_string=linked_list_string.get_collection().begin();
	cout<<"\nAddAll ----- functions element :   ";
	while(linked_iter_addAll_string.hasNext()){
		cout<<" "<<*iter_addAll_linked_string<<" ";					
		iter_addAll_linked_string=linked_iter_addAll_string.next();
	}	
	linked_list_string.offer("Istanbul");

	cout<<"\nSize ---- function and Collection size :  "<<linked_list_string.size();

	if(linked_list_string.contains("Gebze")){
		cout<<"\nContains ---- Collection has a Gebze"<<endl;
	}
	if(!linked_list_string.contains("Kocaeli")){
		cout<<"Contains ---- Collection has not a Kocaeli"<<endl;
	}
	if(linked_list_string.containsAll(temp_string2)){
		cout<<"ContainsAll ---- Collection has a specified all elements"<<endl;
	}
	else
		cout<<"ContainsAll ---- Collection has not a specified all elements"<<endl;

	if(linked_list_string.isEmpty()){
		cout<<"Isempty ---- Collection is empty"<<endl;
	}
	else
		cout<<"Isempty ---- Collection is not empty"<<endl;	

	cout<<"Poll ----- function element "<<*linked_list_int.poll();
	cout<<"\nElement ----- function element "<<*linked_list_int.element();
	cout<<endl;
	linked_list_string.remove("Gebze");
	linked_list_string.removeAll(test_string2);
	Iterator<list<string >> linked_iter_remove_string(linked_list_string.get_collection());	
	auto iter_removeall_linked_string=linked_list_string.get_collection().begin();
	cout<<"RemoveALl ---- functions element :   ";
	while(linked_iter_remove_string.hasNext()){
		cout<<" "<<*iter_removeall_linked_string<<" ";					
		iter_removeall_linked_string=linked_iter_remove_string.next();
	}

	linked_list_string.add("Taylan");	
	cout<<"\nAdd ---- functions element :   Taylan  I called remove and retain reverse \nfunction so I want to print screen after retain same elemnt with collection";

	cout<<endl;
	linked_list_string.retainAll(test_string2);
	Iterator<list<string >> linked_iter_retain_string(linked_list_string.get_collection());	
	auto iter_retainall_linked_string=linked_list_string.get_collection().begin();
	cout<<"RetainALl ---- functions element :   ";
	while(linked_iter_retain_string.hasNext()){
		cout<<" "<<*iter_retainall_linked_string<<" ";					
		iter_retainall_linked_string=linked_iter_retain_string.next();
	}
	cout<<endl;















cout<<"\n-----LinkedList Set String ---\n";

	linked_set_string.add("Gebze");
	linked_set_string.add("Önder");	

	Iterator<set<string >> linked_iter_add(linked_set_string.get_collection());	
	auto iter_linked_set=linked_set_string.get_collection().begin();
	cout<<"Add ---- functions element :   ";
	while(linked_iter_add.hasNext()){
		cout<<" "<<*iter_linked_set<<" ";					
		iter_linked_set=linked_iter_add.next();
	}

	linked_set_string.addAll(temp_string1);
	Iterator<set<string >> linked_iter_addAll(linked_set_string.get_collection());	
	auto iter_addAll_linked=linked_set_string.get_collection().begin();
	cout<<"\nAddAll ----- functions element :   ";
	while(linked_iter_addAll.hasNext()){
		cout<<" "<<*iter_addAll_linked<<" ";					
		iter_addAll_linked=linked_iter_addAll.next();
	}	
	linked_set_string.offer("Istanbul");
	cout<<"\nSize ---- function and Collection size :  "<<linked_set_string.size();

	if(linked_set_string.contains("Gebze")){
		cout<<"\nContains ---- Collection has a Gebze"<<endl;
	}
	if(!linked_set_string.contains("Kocaeli")){
		cout<<"Contains ---- Collection has not a Kocaeli"<<endl;
	}
	if(linked_set_string.containsAll(test_string1)){
		cout<<"ContainsAll ---- Collection has a specified all elements"<<endl;
	}
	else
		cout<<"ContainsAll ---- Collection has not a specified all elements"<<endl;

	if(linked_set_string.isEmpty()){
		cout<<"Isempty ---- Collection is empty"<<endl;
	}
	else
		cout<<"Isempty ---- Collection is not empty"<<endl;	
	cout<<"Poll ----- function element "<<*linked_list_int.poll();
	cout<<"\nElement ----- function element "<<*linked_list_int.element();
	cout<<endl;
	linked_set_string.remove("Gebze");
	linked_set_string.removeAll(test_string1);
	Iterator<set<string >> linked_iter_remove(linked_set_string.get_collection());	
	auto iter_removeall_linked=linked_set_string.get_collection().begin();
	cout<<"RemoveALl ---- functions element :   ";
	while(linked_iter_remove.hasNext()){
		cout<<" "<<*iter_removeall_linked<<" ";					
		iter_removeall_linked=linked_iter_remove.next();
	}

	linked_set_string.add("Taylan");	
	cout<<"\nAdd ---- functions element :   Taylan  I called remove and retain reverse \nfunction so I want to print screen after retain same elemnt with collection";

	cout<<endl;
	linked_set_string.retainAll(test_string1);
	Iterator<set<string >> linked_iter_retain(linked_set_string.get_collection());	
	auto iter_retainall_linked=linked_set_string.get_collection().begin();
	cout<<"RetainALl ---- functions element :   ";
	while(linked_iter_retain.hasNext()){
		cout<<" "<<*iter_retainall_linked<<" ";					
		iter_retainall_linked=linked_iter_retain.next();
	}
	cout<<endl;







	cout<<"\n------ArrayList Set Int Functions ----\n";
	array_set_int.add(30);
	array_set_int.add(2);	

	Iterator<set<int >> array_setadd(array_set_int.get_collection());	
	auto array_setarray_set=array_set_int.get_collection().begin();
	cout<<"Add ---- functions element :   ";
	while(array_setadd.hasNext()){
		cout<<" "<<*array_setarray_set<<" ";					
		array_setarray_set=array_setadd.next();
	}

	array_set_int.addAll(test_int1);
	Iterator<set<int >> array_setaddAll(array_set_int.get_collection());	
	auto array_setintAll=array_set_int.get_collection().begin();
	cout<<"\nAddAll ----- functions element :   ";
	while(array_setaddAll.hasNext()){
		cout<<" "<<*array_setintAll<<" ";					
		array_setintAll=array_setaddAll.next();
	}	

	cout<<"\nSize ---- function and Collection size :  "<<array_set_int.size();

	if(array_set_int.contains(30)){
		cout<<"\nContains ---- Collection has a element 30"<<endl;
	}
	if(!array_set_int.contains(100)){
		cout<<"Contains ---- Collection has not a element 100"<<endl;
	}
	if(array_set_int.containsAll(temp_int1)){
		cout<<"ContainsAll ---- Collection has a specified all elements"<<endl;
	}
	else
		cout<<"ContainsAll ---- Collection has not a specified all elements"<<endl;

	if(array_set_int.isEmpty()){
		cout<<"Isempty ---- Collection is empty"<<endl;
	}
	else
		cout<<"Isempty ---- Collection is not empty"<<endl;	

	array_set_int.remove(30);
	array_set_int.removeAll(test_int1);
	Iterator<set<int >> array_setremove(array_set_int.get_collection());	
	auto array_setremoveall=array_set_int.get_collection().begin();
	cout<<"RemoveALl ---- functions element :   ";
	while(array_setremove.hasNext()){
		cout<<" "<<*array_setremoveall<<" ";					
		array_setremoveall=array_setremove.next();
	}

	array_set_int.add(10);	
	cout<<"\nAdd ---- functions element :   30  I called remove and retain reverse \nfunction so I want to print screen after retain same elemnt with collection";

	cout<<endl;
	array_set_int.retainAll(test_int1);
	Iterator<set<int >> array_setretain(array_set_int.get_collection());	
	auto array_setretainall=array_set_int.get_collection().begin();
	cout<<"RetainALl ---- functions element :   ";
	while(array_setretain.hasNext()){
		cout<<" "<<*array_setretainall<<" ";					
		array_setretainall=array_setretain.next();
	}
	cout<<endl;








	cout<<"\n------ArrayList List İnt Functions ----\n";
	
	array_list_int.add(30);
	array_list_int.add(2);	

	Iterator<list<int >> array_listadd(array_list_int.get_collection());	
	auto array_listarray_list=array_list_int.get_collection().begin();
	cout<<"Add ---- functions element :   ";
	while(array_listadd.hasNext()){
		cout<<" "<<*array_listarray_list<<" ";					
		array_listarray_list=array_listadd.next();
	}

	array_list_int.addAll(test_int2);
	Iterator<list<int >> array_listaddAll(array_list_int.get_collection());	
	auto array_listintAll=array_list_int.get_collection().begin();
	cout<<"\nAddAll ----- functions element :   ";
	while(array_listaddAll.hasNext()){
		cout<<" "<<*array_listintAll<<" ";					
		array_listintAll=array_listaddAll.next();
	}	

	cout<<"\nSize ---- function and Collection size :  "<<array_list_int.size();

	if(array_list_int.contains(30)){
		cout<<"\nContains ---- Collection has a element 30"<<endl;
	}
	if(!array_list_int.contains(100)){
		cout<<"Contains ---- Collection has not a element 100"<<endl;
	}
	if(array_list_int.containsAll(temp_int2)){
		cout<<"ContainsAll ---- Collection has a specified all elements"<<endl;
	}
	else
		cout<<"ContainsAll ---- Collection has not a specified all elements"<<endl;

	if(array_list_int.isEmpty()){
		cout<<"Isempty ---- Collection is empty"<<endl;
	}
	else
		cout<<"Isempty ---- Collection is not empty"<<endl;	

	array_list_int.remove(30);
	array_list_int.removeAll(test_int2);
	Iterator<list<int >> array_listremove(array_list_int.get_collection());	
	auto array_listremoveall=array_list_int.get_collection().begin();
	cout<<"RemoveALl ---- functions element :   ";
	while(array_listremove.hasNext()){
		cout<<" "<<*array_listremoveall<<" ";					
		array_listremoveall=array_listremove.next();
	}

	array_list_int.add(10);	
	cout<<"\nAdd ---- functions element :   30  I called remove and retain reverse \nfunction so I want to print screen after retain same elemnt with collection";

	cout<<endl;
	array_list_int.retainAll(test_int2);
	Iterator<list<int >> array_listretain(array_list_int.get_collection());	
	auto array_listretainall=array_list_int.get_collection().begin();
	cout<<"RetainALl ---- functions element :   ";
	while(array_listretain.hasNext()){
		cout<<" "<<*array_listretainall<<" ";					
		array_listretainall=array_listretain.next();
	}
	cout<<endl;









		cout<<"\n------linkedList Set İnt Functions ----\n";

	linked_set_int.add(30);
	linked_set_int.add(2);	

	Iterator<set<int >> linked_setadd(linked_set_int.get_collection());	
	auto linked_setlinked_set=linked_set_int.get_collection().begin();
	cout<<"Add ---- functions element :   ";
	while(linked_setadd.hasNext()){
		cout<<" "<<*linked_setlinked_set<<" ";					
		linked_setlinked_set=linked_setadd.next();
	}

	linked_set_int.addAll(test_int1);
	Iterator<set<int >> linked_setaddAll(linked_set_int.get_collection());	
	auto linked_setintAll=linked_set_int.get_collection().begin();
	cout<<"\nAddAll ----- functions element :   ";
	while(linked_setaddAll.hasNext()){
		cout<<" "<<*linked_setintAll<<" ";					
		linked_setintAll=linked_setaddAll.next();
	}	

	cout<<"\nSize ---- function and Collection size :  "<<linked_set_int.size();
	linked_set_int.offer(5);
	if(linked_set_int.contains(30)){
		cout<<"\nContains ---- Collection has a element 30"<<endl;
	}
	if(!linked_set_int.contains(100)){
		cout<<"Contains ---- Collection has not a element 100"<<endl;
	}
	if(linked_set_int.containsAll(temp_int1)){
		cout<<"ContainsAll ---- Collection has a specified all elements"<<endl;
	}
	else
		cout<<"ContainsAll ---- Collection has not a specified all elements"<<endl;

	if(linked_set_int.isEmpty()){
		cout<<"Isempty ---- Collection is empty"<<endl;
	}
	else
		cout<<"Isempty ---- Collection is not empty"<<endl;
	cout<<"Element ----- function element "<<*linked_list_int.element();			
	cout<<"Poll ----- function element "<<*linked_list_int.poll();
	cout<<endl;
	linked_set_int.remove(30);
	linked_set_int.removeAll(test_int1);
	Iterator<set<int >> linked_setremove(linked_set_int.get_collection());	
	auto linked_setremoveall=linked_set_int.get_collection().begin();
	cout<<"RemoveALl ---- functions element :   ";
	while(linked_setremove.hasNext()){
		cout<<" "<<*linked_setremoveall<<" ";					
		linked_setremoveall=linked_setremove.next();
	}

	linked_set_int.add(10);	
	cout<<"\nAdd ---- functions element :   30  I called remove and retain reverse \nfunction so I want to print screen after retain same elemnt with collection";

	cout<<endl;
	linked_set_int.retainAll(test_int1);
	Iterator<set<int >> linked_setretain(linked_set_int.get_collection());	
	auto linked_setretainall=linked_set_int.get_collection().begin();
	cout<<"RetainALl ---- functions element :   ";
	while(linked_setretain.hasNext()){
		cout<<" "<<*linked_setretainall<<" ";					
		linked_setretainall=linked_setretain.next();
	}
	cout<<endl;


	cout<<"\n------Linkedlist List İnt Functions ----\n";

	linked_list_int.add(30);
	linked_list_int.add(2);	

	Iterator<list<int >> linked_listadd(linked_list_int.get_collection());	
	auto linked_listlinked_list=linked_list_int.get_collection().begin();
	cout<<"Add ---- functions element :   ";
	while(linked_listadd.hasNext()){
		cout<<" "<<*linked_listlinked_list<<" ";					
		linked_listlinked_list=linked_listadd.next();
	}

	linked_list_int.addAll(test_int2);
	Iterator<list<int >> linked_listaddAll(linked_list_int.get_collection());	
	auto linked_listintAll=linked_list_int.get_collection().begin();
	cout<<"\nAddAll ----- functions element :   ";
	while(linked_listaddAll.hasNext()){
		cout<<" "<<*linked_listintAll<<" ";					
		linked_listintAll=linked_listaddAll.next();
	}	

	cout<<"\nSize ---- function and Collection size :  "<<linked_list_int.size();
	linked_set_int.offer(5);
	if(linked_list_int.contains(30)){
		cout<<"\nContains ---- Collection has a element 30"<<endl;
	}
	if(!linked_list_int.contains(100)){
		cout<<"Contains ---- Collection has not a element 100"<<endl;
	}
	if(linked_list_int.containsAll(temp_int2)){
		cout<<"ContainsAll ---- Collection has a specified all elements"<<endl;
	}
	else
		cout<<"ContainsAll ---- Collection has not a specified all elements"<<endl;

	if(linked_list_int.isEmpty()){
		cout<<"Isempty ---- Collection is empty"<<endl;
	}
	else
		cout<<"Isempty ---- Collection is not empty"<<endl;	
	cout<<"Poll ----- function element "<<*linked_list_int.poll();
	cout<<"\nElement ----- function element "<<*linked_list_int.element();
	cout<<endl;
	linked_list_int.remove(30);
	linked_list_int.removeAll(test_int2);
	Iterator<list<int >> linked_listremove(linked_list_int.get_collection());	
	auto linked_listremoveall=linked_list_int.get_collection().begin();
	cout<<"RemoveALl ---- functions element :   ";
	while(linked_listremove.hasNext()){
		cout<<" "<<*linked_listremoveall<<" ";					
		linked_listremoveall=linked_listremove.next();
	}

	linked_list_int.add(10);	
	cout<<"\nAdd ---- functions element :   30  I called remove and retain reverse \nfunction so I want to print screen after retain same elemnt with collection";

	cout<<endl;
	linked_list_int.retainAll(test_int2);
	Iterator<list<int >> linked_listretain(linked_list_int.get_collection());	
	auto linked_listretainall=linked_list_int.get_collection().begin();
	cout<<"RetainALl ---- functions element :   ";
	while(linked_listretain.hasNext()){
		cout<<" "<<*linked_listretainall<<" ";					
		linked_listretainall=linked_listretain.next();
	}
	cout<<endl;

}	
	catch(LinkedlistError){
		cout<<"\n \n------Vector should not be empty for pool function ------"<<endl;
	}

	return 0;
}

