#include "HashSet.h"

namespace my_namespace{
			template<typename E,typename C>	
			HashSet<E,C>::HashSet(C obje){
				set_obje=obje;

			}	

			template<typename E,typename C>		
			void HashSet<E,C>::add(E element){		//add specified element in collection
				//auto iter=set_obje.end();				

				if(!contains(element))			//check with contain function and if specified element in a collection it'will not append collection
					set_obje.insert(set_obje.end(),element);
					//iter=iterate.next();
					

			}

			template<typename E,typename C>	
			void HashSet<E,C>::addAll(C C_element){		//	Adds all of the elements in the specified collection to this collection
				int flag=0;
	
				iterate=Iterator<C>(set_obje);
				Iterator<C> temp(C_element);
				auto iter=set_obje.begin();
				auto iter2=C_element.begin();
				while(temp.hasNext()){
					while(iterate.hasNext()){				
						if(*iter==*iter2){
							flag=1;
						}
						iter++;
						iterate.next();
					}
					if(flag==0){
						set_obje.insert(iter,*iter2);				
					}
					iter=set_obje.begin();
					iter2=temp.next();																	
					flag=0;
				}																			
			}

			template<typename E,typename C>	
			void HashSet<E,C>::clear(){				//clear collection elements
				set_obje.clear();
			}

			template<typename E,typename C>	
			bool HashSet<E,C>::contains(E element){		//check for same element in a collection if collection has same element return true,if has not same elemnt return false
				iterate=Iterator<C>(set_obje);
				auto iter=set_obje.begin();
				while(iterate.hasNext()){			//check with iterator class functions base condition
					if(element==*iter){
						return true;
					}
					iter=iterate.next();			//next function return collection's next element
				}
				return false;			
			}

			template<typename E,typename C>	
			bool HashSet<E,C>::containsAll(C C_element){	//Returns true if this collection contains all of the elements in the specified collection.
				int flag=0;
				iterate=Iterator<C>(set_obje);
				auto iter=set_obje.begin();
				auto iter2=C_element.begin();
				while(iterate.hasNext()){
					Iterator<C> temp(C_element);
					while(temp.hasNext()){				
						if(*iter==*iter2){
							flag=1;
						}
						iter2=temp.next();												
					}

					if(flag==0){					
						return false;		//this concidition for collection does not have any element of container 
					}
					iter=iterate.next();
					auto iter2=C_element.begin();
					flag=0;
				}
				return true;				
			}

			template<typename E,typename C>	
			bool HashSet<E,C>::isEmpty(){		//Returns true if this collection contains no elements.
				auto iter=set_obje.begin();
				if(iter==set_obje.end())
					return true;
				return false;
			}

			template<typename E,typename C>			//düzeltilicek
			void HashSet<E,C>::remove(E e){		//remove(E e) Removes a single instance of the specified element from this collection, if it is present
				auto iter=set_obje.begin();
					iterate=Iterator<C>(set_obje);

				while(iterate.hasNext()){  	//check with iterator class functions base condition returns true if the iteration has more elements.
					if(e==*iter){
			            //iter=iterate.remove();
			            iterate.remove();
						iter=set_obje.erase(iter);
      
					}
					else
						iter++;
						iterate.next();		//next function return collection's next element
				}		  				
			}


			template<typename E,typename C>	
			void HashSet<E,C>::removeAll(C C_element){	//Removes all of this collection's elements that are also contained in the specified collection
				int flag=0;
				iterate=Iterator<C>(set_obje);
				auto iter=set_obje.begin();
				auto iter2=C_element.begin();
				while(iterate.hasNext()){				//check with iterator class functions returns true if the iteration has more elements in collection.
					Iterator<C> temp(C_element);				
					while(temp.hasNext()){				//check with iterator class functions returns true if the iteration has more elements in specified collection.
						if(*iter==*iter2){
							flag=1;		//it won't erase
						}	
									//next iteration with iteratre class											
						iter2=temp.next();
					}

					if(flag==1){		
			            iterate.remove();							
						iter=set_obje.erase(iter);		//delete element in collection
					}
					else
						iter++;			//next iteration 
						iterate.next();		//next function return collection's next element					
					iter2=C_element.begin();


					flag=0;
				}
			}

			template<typename E,typename C>	
			void HashSet<E,C>::retainAll(C C_element){		//Retains only the elements in this collection that are contained in the specified Collection
				int flag=0;
				iterate=Iterator<C>(set_obje);
				auto iter=set_obje.begin();
				auto iter2=C_element.begin();
				while(iterate.hasNext()){				//check with iterator class functions returns true if the iteration has more elements in collection.
					Iterator<C> temp(C_element);
					while(temp.hasNext()){				//check with iterator class functions returns true if the iteration has more elements in specified collection.
						if(*iter==*iter2){
							flag=1;		//it won't erase
						}	
						iter2=temp.next();			//next iteration with iteratre class											
					}

					if(flag==0){		
						iter=set_obje.erase(iter);		//delete element in collection
					}
					else
						iter++;				//next iteration 
						iterate.next();		//next function return collection's next element					
					iter2=C_element.begin();

					flag=0;
				}			  	    			
			}

			template<typename E,typename C>	
			int HashSet<E,C>::size(){			//Returns the number of elements in this collection.																									
				int counter=0;
				iterate=Iterator<C>(set_obje);
				auto iter=set_obje.begin();
				while(iterate.hasNext()){			//check with iterator class functions base condition
					counter++;
					iter=iterate.next();			//next function return collection's next element
				}
				return counter;				
			}

			template<typename E,typename C>				
			Collection<E,C> &HashSet<E,C>::iterator(){
				return *this;
			}

			template<typename E,typename C>	
			C HashSet<E,C>::get_collection()const{
				return set_obje;
			}

			
			template<typename E,typename C>	
			Iterator<C> HashSet<E,C>::get_iterate()const{
				return iterate;
			}			

}