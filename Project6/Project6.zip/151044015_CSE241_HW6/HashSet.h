#ifndef HASHSET_H_
#define HASHSET_H_
#include <iostream>
#include <typeinfo>
#include <set> 
#include <list> 
#include <vector> 
#include "Set.h"
#include "Iterator.h"
#include <string>
using namespace std;

namespace my_namespace{
	template<typename E,typename C>
		class HashSet : public Set<E,C>{
		public:
			HashSet(){}
			HashSet(C obje);	
			virtual void add(E element);
			virtual void addAll(C C_element);
			virtual void clear();
			virtual bool contains(E element);
			virtual bool containsAll(C C_element);
			virtual bool isEmpty();
			virtual void remove(E e);
			virtual void removeAll(C C_element);
			virtual void retainAll(C C_element);
			virtual int size();
			Collection<E,C> &iterator();
			C get_collection()const;
			Iterator<C> get_iterate()const;

		private:
			C set_obje;
			Iterator<C> iterate;
		};
	}	
#endif

