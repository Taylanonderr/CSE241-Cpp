#ifndef COLLECTION_H_
#define COLLECTION_H_
#include <iostream>
#include <set> 
#include <list> 
#include <vector> 
using namespace std;

namespace my_namespace{
template<typename E,typename C>
	class Collection{
	public:
	

		Collection(){}
		virtual Collection<E,C> & iterator()=0;
		virtual void add(E element)=0;
		virtual void addAll(C C_element)=0;
		virtual void clear()=0;
		virtual bool contains(E element)=0;
		virtual bool containsAll(C C_element)=0;
		virtual bool isEmpty()=0;
		virtual void remove(E e)=0;
		virtual void removeAll(C C_element)=0;
		virtual void retainAll(C C_element)=0;
		virtual int size()=0;
	};
}
#endif	
