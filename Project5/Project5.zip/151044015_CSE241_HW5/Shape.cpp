#include <iostream>
#include "Shape.h"

namespace my_shape{

		ostream& operator<<(ostream& outputStream, Shape &obje){
			obje.draw(outputStream);	//I called my virtual print svg format function 
			
			return outputStream;
		}
		bool Shape::operator !=(  Shape & obj2){	//it's an comparison oerator for all shape and derives function according to arreas
			return(obj2.area()!=this->area());						
		}
		bool Shape::operator ==(  Shape & obj2){	//it's an comparison oerator for all shape and derives function according to arreas
			return(obj2.area()==this->area());						
		}	
		bool Shape::operator >(   Shape & obj2){	//it's an comparison oerator for all shape and derives function according to arreas
			return(this->area()>obj2.area());			
		}	
		bool Shape::operator <(   Shape & obj2){	//it's an comparison oerator for all shape and derives function according to arreas
			return(this->area()<obj2.area());			

		}	
}		