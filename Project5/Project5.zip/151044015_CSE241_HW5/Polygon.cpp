#include <iostream>
#include "Polygon.h"

namespace my_shape{

	double Polygon::Point2D::getCoord_x()const{		//get coord_x variable 
		return coord_x;
	}
	void Polygon::Point2D::setCoord_x(double new_coordinate){		//set coord_x variable
		coord_x=new_coordinate;
	}
	double Polygon::Point2D::getCoord_y()const{		//get coord_x variable 
		return coord_y;
	}
	void Polygon::Point2D::setCoord_y(double new_coordinate){		//set coord_y variable
		coord_y=new_coordinate;
	}
	ostream& operator <<(ostream& outputStream,  Polygon &obje){
		obje.draw(outputStream);

		return outputStream;		//return outputfile
	}



	Polygon::Point2D& Polygon::Point2D::operator[](int index){
		return this[index];									//return polygon object

	}


}
	
