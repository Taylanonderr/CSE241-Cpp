#ifndef CIRCLE_H_
#define CIRCLE_H_
#include <iostream>
#include <fstream>
#include "Shape.h"

using namespace std;
namespace my_shape{
	class Negative_circle_class{
		public:
			Negative_circle_class(){}
			Negative_circle_class(double a,double b){
				cout<<"Invalid coordinates error circle x or y"<<endl;
			}
	};
	class circle : public Shape {
		public:
			circle();
			circle(double f_radius);	
			circle(double first,double second);	
			circle(double x_k,double y_k,double radius_c);	
			double getRadius()const;
			void setRadius(double radius_c);	
			double getPosition_x()const;
			void setPosition_x(double x_koordinat);
			double getPosition_y()const;
			void setPosition_y(double y_koordinat);				
			void setShape(char choise);
			double area();
			double perimeter();		
			virtual ostream& draw(ostream& outputStream);
			const circle operator +( const double adding_size);		
			const circle operator -( const double subbing_size);		
			 circle &operator++(); //Prefix version	
			 circle *operator++(int ); //Postfix version	
			 circle &operator--(); //Prefix version	
			 circle *operator--(int ); //Postfix version				
			static double total_areas();
			static double perimeter_length();
			shape_t get_enumshape_t(){
				return shape_type;
			};
			void set_enumshape_t(shape_t type){
				shape_type=type;
			};
		private:
			shape_t shape_type;
			char main_shape;
			double radius;
			double x;
			double y;		
			static double area_c; 
			static double length_c;		
		
	};
}

#endif
