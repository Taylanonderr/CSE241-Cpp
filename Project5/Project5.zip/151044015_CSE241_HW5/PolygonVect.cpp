#include <iostream>
#include "PolygonVect.h"
namespace my_shape{

	PolygonVect::PolygonVect(rectangle& obj_r){
		capacity=4;		//point num
		//I set coorc of all points	my array
		temp_obje.setCoord_x(obj_r.getPosition_x());					//left
		temp_obje.setCoord_y(obj_r.getPosition_y());
		shape_polygon.push_back(temp_obje);									
		temp_obje.setCoord_x(obj_r.getWidth()+obj_r.getPosition_x());	//right
		temp_obje.setCoord_y(obj_r.getPosition_y());
		shape_polygon.push_back(temp_obje);		
		temp_obje.setCoord_x(obj_r.getPosition_x());					//left alt
		temp_obje.setCoord_y(obj_r.getHeight()+obj_r.getPosition_y());
		shape_polygon.push_back(temp_obje);		
		temp_obje.setCoord_x(obj_r.getWidth()+obj_r.getPosition_x());	//right and alt
		temp_obje.setCoord_y(obj_r.getHeight()+obj_r.getPosition_y());	
		shape_polygon.push_back(temp_obje);
		area_p=obj_r.getWidth()*obj_r.getHeight();
		perimeter_p=(2*obj_r.getWidth())+(2*obj_r.getHeight());

	}
	PolygonVect::PolygonVect(triangle& obj_t){			
		capacity=3;		//point num
		//I set coorc of all points	my array
		temp_obje.setCoord_x(obj_t.getPosition_x());
		temp_obje.setCoord_y(obj_t.getPosition_y());	
		shape_polygon.push_back(temp_obje);		
		temp_obje.setCoord_x(obj_t.getPosition_x2());
		temp_obje.setCoord_y(obj_t.getPosition_y2());
		shape_polygon.push_back(temp_obje);		
		temp_obje.setCoord_x(obj_t.getPosition_x3());
		temp_obje.setCoord_y(obj_t.getPosition_y3());
		shape_polygon.push_back(temp_obje);			
		area_p=obj_t.getSide()*obj_t.getSide()*sqrt(3)/4;
		perimeter_p=3*obj_t.getSide();
	}
	PolygonVect::PolygonVect(circle& obj_c){		//conversion circle obje
		double teta;		//angle
		int i;		//loop element
		capacity=100;			//point num
		for(i=0;i<100;i++){
			teta=i*(3.6)*3.14/180;														//calclating points angle
			//I set coorc of all points	my array
			temp_obje.setCoord_x (obj_c.getPosition_x()+obj_c.getRadius()*cos((teta)));		//calculate each x points
	    	temp_obje.setCoord_y (obj_c.getPosition_y()+obj_c.getRadius()*sin((teta)));		//calculate each y points	
	    	shape_polygon.push_back(temp_obje);
		}	
		area_p=obj_c.getRadius()*obj_c.getRadius()*3.14;
		perimeter_p=2*3.14*obj_c.getRadius();
	}

	double PolygonVect::area(){			//return area polygonvect in runtime
		return area_p;
	}
	double PolygonVect::perimeter(){	//return perimeter polygonvect in runtime
		return perimeter_p;
	}	
	ostream& PolygonVect::draw(ostream& outputStream){
		int i;
outputStream <<"<svg version=\"1.1\"\n\t\t"<<"baseProfile=\"full\"\n\t\t"
    <<"xmlns=\"http://www.w3.org/2000/svg\">\n\n\t"  ;		//it's for file svg format				
			outputStream<<"<polygon points="<<"\"";
			for(i=0;i<capacity;i++){						// write svg file our 100 point for circle
				outputStream<<shape_polygon[i].getCoord_x() <<" "<<shape_polygon[i].getCoord_y() <<" ";		
			}
			outputStream<<"\""<<" stroke="<<"\"transparent\""<< " fill="<<"\"green\""<< " stroke-width="<<"\"0.3\""<<"/>\n";	
    	outputStream	<<"	</svg>"	;	/*finish of the svg format I wrote in a file*/		
		
		return outputStream;		//return outputfile*/			
	}			

}	