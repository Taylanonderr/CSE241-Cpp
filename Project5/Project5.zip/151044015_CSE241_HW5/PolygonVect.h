#ifndef POLYGONVECT_H_
#define POLYGONVECT_H_
#include <iostream>
#include <fstream>
#include <vector>
#include "Polygon.h"
#include "Shape.h"
#include "rectangle.h"
#include "circle.h"
#include "triangle.h"

using namespace std;
namespace my_shape{

class PolygonVect: public Polygon{
	public:
		PolygonVect(rectangle &obj);
		PolygonVect(triangle &obj);
		PolygonVect(circle &obj);
		double area();
		double perimeter();
	
		virtual ostream& draw(ostream& outputStream);			

	private:
		PolygonVect::Point2D temp_obje;
		vector <PolygonVect::Point2D> shape_polygon;	
		int capacity;
		double area_p;
		double perimeter_p;
	};
			
}

#endif	
