#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <vector>
#include "composedshape.h"
#include "rectangle.h"
#include "circle.h"
#include "triangle.h"
#include "Polygon.h"
#include "Shape.h"
#include "PolygonDyn.h"
#include "PolygonVect.h"
#include <typeinfo>

using namespace std;
using namespace my_shape ;
void printAll(string filename[],vector <Shape*> shape_v);
void printPoly(string filename[],vector <Shape*> shape_v);
vector <Polygon*> convertAll(vector <Shape*> shape_v);
void sortShapes(vector <Shape*> shape_v);


int main(){
try{
	int i=0,r=0,t=0,c=0;
	double width,height;
	double radius,side,small_side,s_radius,small_width,small_height;
	string file[10];	/*for output filenames*/
	string test[5],test2[5];
	char choose[9][2],second_choose[9][2];		
	rectangle	rect_obj[1];	/*this array for main conventer*/
	rectangle	small_rect_obj[3];	/*this array obje for small shapes using in loop*/
	triangle tri_obj[1];	/*this array for main conventer*/
	triangle small_tri_obj[3];	/*this array obje for small shapes using in loop*/	
	circle	circ_obj[1];	/*this array for main conventer*/
	circle	small_circ_obj[3];	/*this array obje for small shapes using in loop*/

	ComposedShape composed_array[10];
	rect_obj[0]=rectangle (1000.0,800.0);	/*it's for trying main rectangle obj*/
	small_rect_obj[0]=rectangle (52.0,30.0);	/*it's for trying small rectangle obj*/
	small_rect_obj[1]=rectangle (100.0,78.0);	/*it's for trying small rectangle obj*/
	small_rect_obj[2]=rectangle (80.0,70.0);	/*it's for trying small rectangle obj*/	

	tri_obj[0]=triangle (800.0);		/*it's for trying main triangle obj*/
	small_tri_obj[0]=triangle (90.0);		/*it's for trying small rectangle obj*/
	small_tri_obj[1]=triangle (56.0);		/*it's for trying small rectangle obj*/
	small_tri_obj[2]=triangle (150.0);	/*it's for trying small rectangle obj*/


	circ_obj[0]=circle (300.0);		/*it's for trying main circle obj*/
	small_circ_obj[0]=circle (82.0);		/*it's for trying small circle obj*/
	small_circ_obj[1]=circle (100.0);		/*it's for trying small circle obj*/
	small_circ_obj[2]=circle (25.0);		/*it's for trying small circle obj*/
	/*I compare two object when I didn't write anyting*/

	composed_array[0]=ComposedShape(rect_obj[0],small_rect_obj[1]);	
	composed_array[1]=ComposedShape(rect_obj[0],small_tri_obj[2]);	
	composed_array[2]=ComposedShape(rect_obj[0],small_circ_obj[2]);	
	composed_array[3]=ComposedShape(tri_obj[0],small_rect_obj[2]);	
	composed_array[4]=ComposedShape(tri_obj[0],small_tri_obj[1]);
	composed_array[5]=ComposedShape(tri_obj[0],small_circ_obj[1]);	
	composed_array[6]=ComposedShape(circ_obj[0],small_rect_obj[1]);	
	composed_array[7]=ComposedShape(circ_obj[0],small_tri_obj[1]);	
	composed_array[8]=ComposedShape(circ_obj[0],small_circ_obj[1]);	


/*it's for users choise*/
	choose[0][0]='r',second_choose[0][0]='r';
	choose[1][0]='r',second_choose[1][0]='t';             
	choose[2][0]='r',second_choose[2][0]='c';
	choose[3][0]='t',second_choose[3][0]='r';				
	choose[4][0]='t',second_choose[4][0]='t';				
	choose[5][0]='t',second_choose[5][0]='c';				
	choose[6][0]='c',second_choose[6][0]='r';
	choose[7][0]='c',second_choose[7][0]='t';
	choose[8][0]='c',second_choose[8][0]='c';
/*it's for nine situation different file name*/	
	file[0]="result.svg";										
	file[1]="result1.svg";
	file[2]="result2.svg";	
	file[3]="result3.svg";
	file[4]="result4.svg";
	file[5]="result5.svg";
	file[6]="result6.svg";
	file[7]="result7.svg";
	file[8]="result8.svg";

	test[0]="result13.svg";										
	test[1]="result14.svg";
	test[2]="result15.svg";	
	test[3]="result16.svg";
	test[4]="result17.svg";	

	test2[0]="result18.svg";										
	test2[1]="result19.svg";
	test2[2]="result20.svg";	
	test2[3]="result21.svg";
	Shape *deneme;

	ofstream myfile;
	myfile.open(file[0]);
	while(i<9){		//all of the about all situation print
	  	ofstream myfile;
	  	myfile.open(file[i]);	//I open the file which get the main for many result output file 
	    myfile <<"<svg version=\"1.1\"\n\t\t"<<"baseProfile=\"full\"\n\t\t"
	    <<"xmlns=\"http://www.w3.org/2000/svg\">\n\n\t"  ;		//it's for file svg format			
		if(choose[i][0]=='R' || choose[i][0]=='r'){
			if(second_choose[i][0]=='R' || second_choose[i][0]=='r'){
				myfile<<rect_obj[0];	//rect << overload	
				composed_array[0].setMainchar(choose[i][0]);
				composed_array[0].setSmallchar(second_choose[i][0]);
				composed_array[0].optimalfit();
				deneme=&composed_array[0];
				myfile<<*deneme;
							
			}
			if(second_choose[i][0]=='T' || second_choose[i][0]=='t'){
				myfile<<rect_obj[0];	//rect << overload	
				composed_array[1].setMainchar(choose[i][0]);
				composed_array[1].setSmallchar(second_choose[i][0]);
				composed_array[1].optimalfit();
				deneme=&composed_array[1];
				myfile<<*deneme;				
			}
			if(second_choose[i][0]=='C' || second_choose[i][0]=='c'){
				myfile<<rect_obj[0];	//rect << overload
				composed_array[2].setMainchar(choose[i][0]);
				composed_array[2].setSmallchar(second_choose[i][0]);
				composed_array[2].optimalfit();
				deneme=&composed_array[2];
				myfile<<*deneme;				
			}
			r++;
		}
		
  		else if(choose[i][0]=='T' || choose[i][0]=='t'){
			if(second_choose[i][0]=='R' || second_choose[i][0]=='r'){	
				myfile<<tri_obj[0];	//rect << overload	
				composed_array[3].setMainchar(choose[i][0]);
				composed_array[3].setSmallchar(second_choose[i][0]);
				composed_array[3].optimalfit();
				deneme=&composed_array[3];
				myfile<<*deneme;			
			}
			else if(second_choose[i][0]=='T' || second_choose[i][0]=='t'){		
				myfile<<tri_obj[0];	//rect << overload	
				composed_array[4].setMainchar(choose[i][0]);
				composed_array[4].setSmallchar(second_choose[i][0]);
				composed_array[4].optimalfit();
				deneme=&composed_array[4];
				myfile<<*deneme;
			}
			else if(second_choose[i][0]=='C' || second_choose[i][0]=='c'){
				myfile<<tri_obj[0];	//rect << overload	
				composed_array[5].setMainchar(choose[i][0]);
				composed_array[5].setSmallchar(second_choose[i][0]);
				composed_array[5].optimalfit();
				deneme=&composed_array[5];
				myfile<<*deneme;
			}
			t++;		  	
   		} 

		else if(choose[i][0]=='C' || choose[i][0]=='c'){	
			if(second_choose[i][0]=='R' || second_choose[i][0]=='r'){
				myfile<<circ_obj[0];	//circle << overload
				composed_array[6].setMainchar(choose[i][0]);
				composed_array[6].setSmallchar(second_choose[i][0]);
				composed_array[6].optimalfit();
				deneme=&composed_array[6];
				myfile<<*deneme;		
				}
			if(second_choose[i][0]=='T' || second_choose[i][0]=='t'){
				myfile<<circ_obj[0];	//circle << overload
				composed_array[7].setMainchar(choose[i][0]);
				composed_array[7].setSmallchar(second_choose[i][0]);
				composed_array[7].optimalfit();
				deneme=&composed_array[7];
				myfile<<*deneme;							

			}
			if(second_choose[i][0]=='C' || second_choose[i][0]=='c'){		
				myfile<<circ_obj[0];	//circle << overload
				composed_array[8].setMainchar(choose[i][0]);
				composed_array[8].setSmallchar(second_choose[i][0]);
				composed_array[8].optimalfit();
				deneme=&composed_array[8];
				myfile<<*deneme;
			}
			c++; 
			}   			
		myfile.close(); 
		i++; 				
		
	}	 
	vector <Shape*> shape_v;	

	Shape *obje1=&rect_obj[0];
	Shape *obje2=&small_rect_obj[0];
	Shape *composedshape_element=&composed_array[0];

	PolygonDyn poly1(circ_obj[0]);		
		myfile.open("result9.svg");
	    myfile <<"<svg version=\"1.1\"\n\t\t"<<"baseProfile=\"full\"\n\t\t"
	    <<"xmlns=\"http://www.w3.org/2000/svg\">\n\n\t"  ;		//it's for file svg format	;

	    myfile	<<"	</svg>"	;	//finish of the svg format I wrote in a file
		myfile.close();	

	cout<<"\n\n";
	if(*obje1==*obje1){
		cout<<"Equal area   Shape1 : "<<obje1->area()<<" ---- shape2 :"<<obje1->area()<<endl;		
	}
	else{
		cout<<"Their areas not equal  Shape1 : "<<obje1->area()<<" ---- shape2 :"<<obje1->area()<<endl;		
	}
	if(*obje1!=*obje2){
		cout<<"Their areas not equal  Shape1 : "<<obje1->area()<<" ---- shape2 :"<<obje2->area()<<endl;		
	}
	else{
		cout<<"Equal area   Shape1 : "<<obje1->area()<<" ---- shape2 :"<<obje2->area()<<endl;		
	}
	if(*obje1>*obje2){
		cout<<"First obje area bigger than second obje  Shape1 : "<<obje1->area()<<" ---- shape2 :"<<obje2->area()<<endl;		
	}
	if(poly1<*obje1){
		cout<<"First obje area smaller than second obje   Shape1 : "<<poly1.area()<<" ---- shape2 :"<<obje1->area()<<endl;		
	}		
/*******************   					Test								*\\\\\\\\\\\\\\\\\\	*/
	myfile.open("result10.svg");	
	//printAll(myfile,);
	cout<<"\n";
	cout<<"Shape x:coordinate:  "<<rect_obj[0].getPosition_x()<<"  Shape y:coordinate:"<<rect_obj[0].getPosition_y()<<endl<<endl;
	(*obje1)++;
	cout<<"Postfix ++ New shape x:coordinate:  "<<rect_obj[0].getPosition_x()<<"  Nex shape y:coordinate:"<<rect_obj[0].getPosition_y()<<endl<<endl;
	++(*obje1);
	cout<<"Prefix ++ New shape x:coordinate:  "<<rect_obj[0].getPosition_x()<<"  Nex shape y:coordinate:"<<rect_obj[0].getPosition_y()<<endl<<endl;
	(*obje1)--;
	cout<<"Postfix -- New shape x:coordinate:  "<<rect_obj[0].getPosition_x()<<"  Nex shape y:coordinate:"<<rect_obj[0].getPosition_y()<<endl<<endl;
	--(*obje1);
	cout<<"Prefix -- New shape x:coordinate:  "<<rect_obj[0].getPosition_x()<<"  Nex shape y:coordinate:"<<rect_obj[0].getPosition_y()<<endl<<endl;				
	Polygon *denemeee=&poly1;
	myfile<<*denemeee;
	myfile.close();

	myfile.open("result11.svg");
	shape_v.push_back(obje1);
	shape_v.push_back(obje2);		
	shape_v.push_back(denemeee);
	myfile<< poly1;
	myfile.close();	
	shape_v.push_back(composedshape_element);
	printPoly(test2,shape_v);
	myfile.close();
	sortShapes(shape_v);	
	vector <Polygon*> shape_1=(convertAll(shape_v));
	printAll(test,shape_v);
	
	myfile.open("result12.svg");	
	PolygonVect poly2(circ_obj[0]);
	Polygon *deneme2=&poly2;
	myfile<<*deneme2;	
	cout<<"I error checked with exepciton handling "<<endl;
	tri_obj[0]=triangle(-2,5,4,3,2,-1);
	rect_obj[0]=rectangle (-5,800.0,100,200);
	rect_obj[0]=rectangle (-5,800.0);

}

	catch(Negative_rectangle_class)
	{
		cout<<"Negative or zero input weight or height rectangle"<<endl;
	}
	catch(Negative_triangle_class)
	{
		cout<<"Negative or zero input side triangle"<<endl;
	}
	catch(Negative_circle_class)
	{
		cout<<"Negative or zero input radius circle"<<endl;
	}		
	return 0;	


}

void printAll(string filename[],vector <Shape*> shape_v){
	ofstream outputStream;
	cout<<"Print All -- result13.svg to result17.svg files writing all shapes"<<endl;
	int i;
		for(i=0;i<shape_v.size();i++){
			if(typeid(*shape_v[i])==typeid(ComposedShape)){
				outputStream.open(filename[i]);		
			outputStream <<"<svg version=\"1.1\"\n\t\t"<<"baseProfile=\"full\"\n\t\t"
    		<<"xmlns=\"http://www.w3.org/2000/svg\">\n\n\t"  ;		//it's for file svg format						
				outputStream<<*shape_v[i];	/*I send an type of ShapeElem object in ShapeElem class to << overload and write in file */
			}	
			else{

			outputStream.open(filename[i]);			
			outputStream <<"<svg version=\"1.1\"\n\t\t"<<"baseProfile=\"full\"\n\t\t"
    		<<"xmlns=\"http://www.w3.org/2000/svg\">\n\n\t"  ;		//it's for file svg format				
				
			outputStream<<*shape_v[i];	/*I send an type of ShapeElem object in ShapeElem class to << overload and write in file */
	    	outputStream	<<"	</svg>"	;	/*finish of the svg format I wrote in a file*/					
			}
			outputStream.close();
			
		}
}

void printPoly(string filename[],vector <Shape*> shape_v){
	int i;
	ofstream outputStream;	
	cout<<"Print Poly -- for result18.svg to result21.svg files writing if only polygon "<<endl;	
	for(i=0;i<shape_v.size();i++){
		if(typeid(*shape_v[i])==typeid(PolygonDyn) || typeid(*shape_v[i])==typeid(PolygonVect)){
			cout<<"Print poly function it's a Polygon"<<endl;
			outputStream.open(filename[i]);								
			outputStream<<*shape_v[i];	/*I send an type of ShapeElem object in ShapeElem class to << overload and write in file */
			outputStream.close();
		}
		else
			cout<<"Print poly function it's not a Polygon"<<endl;

	}
		//typeid(*p) == typeid(A)		
}

vector <Polygon*> convertAll(vector <Shape*> shape_v){
	int i;
	vector <Polygon*> new_polygon;
	for(i=0;i<shape_v.size();i++){
		if((typeid(*shape_v[i])!=typeid(PolygonDyn)) && (typeid(*shape_v[i])!=typeid(PolygonVect))){
			Polygon * poly_obje=static_cast<Polygon*>(shape_v[i]);
//			CDerived * b = static_cast<CDerived*>(a);

			new_polygon.push_back(poly_obje);
		}
		else{
			new_polygon.push_back((Polygon*)shape_v[i]);
		}
	}
	return new_polygon;	
}

void sortShapes(vector <Shape*> shape_v){
		cout<<"-----Increasingly sort function -------"<<endl;	
	int i,j,s=0,flag=0;
	Shape* temp;
	for(i=0;i<shape_v.size();i++){
		if(typeid(*shape_v[i])!=typeid(ComposedShape))		//it's for we didn't have composedshape area calculate functin so I didn't want to print this
			cout<<(shape_v[i])->area()<<"  ";
	}
	for(i=0;i<shape_v.size();i++){
		flag=0;
		for(j=0;j<shape_v.size();j++){
			if(shape_v[i]->area()<shape_v[j]->area()){
				temp=shape_v[i];
				shape_v[i]=shape_v[j];		
				shape_v[j]=temp;			
			}
		}

	}
	cout<<"\nIncreasingly sorts them with respect to their areas"<<endl;
	for(i=0;i<shape_v.size();i++){
		if(typeid(*shape_v[i])!=typeid(ComposedShape))	//it's for we didn't have composedshape area calculate function so I didn't want to print this
			cout<<(shape_v[i])->area()<<"  ";
	}
	cout<<"\n";

}
