#ifndef POLYGONDYN_H_
#define POLYGONDYN_H_
#include <iostream>
#include <fstream>
#include <vector>
#include "Polygon.h"
#include "Shape.h"
#include "rectangle.h"
#include "circle.h"
#include "triangle.h"

using namespace std;
namespace my_shape{

class PolygonDyn: public Polygon{
	public:
		PolygonDyn(rectangle &obj);
		PolygonDyn(triangle &obj);
		PolygonDyn(circle &obj);	
		double area();
		double perimeter();	
		PolygonDyn::Point2D & getPolygonArray();
		PolygonDyn( const PolygonDyn& obje);	
		PolygonDyn& operator =( const PolygonDyn& rightSide);
		PolygonDyn& operator[](int index);
		int getCapacity();		//get private capacity variable
	
		virtual ostream& draw(ostream& outputStream);


		~PolygonDyn();

					

	private:
		PolygonDyn::Point2D* temp_obje;		
		//Polygon *temp_polygon;
		int capacity;
		double area_p;
		double perimeter_p;
	};
			
}



#endif	
