#ifndef RECTANGLE_H_
#define RECTANGLE_H_
#include <iostream>
#include <fstream>
#include "Shape.h"

using namespace std;
namespace my_shape{
	class Negative_rectangle_class{
		public:
			Negative_rectangle_class(){}
			Negative_rectangle_class(double a,double b){
				cout<<"Invalid coordinates error rectangle x or y"<<endl;
			}
	};
	class rectangle : public Shape {
		public:
			rectangle();
			rectangle(double width_num,double height_num);
			rectangle(double x_k,double y_k ,double r_width,double r_height);

			int getWidth()const;
			void setWidth(double width_r);		
			int getHeight()const;
			void setHeight(double height_r);
			double getPosition_x()const;
			void setPosition_x(double x_koordinat);		
			double getPosition_y()const;
			void setPosition_y(double y_koordinat);											
			double area();		
			double perimeter();		
			ostream& draw(ostream& file);
			const rectangle operator +( const double adding_size);		
			const rectangle operator -( const double subbing_size);

					
			rectangle &operator++(); //Prefix version	
			rectangle *operator++(int ); //Postfix version	
			rectangle &operator--(); //Prefix version	
			rectangle *operator--(int ); //Postfix version			
			static double total_areas();
			static double perimeter_length();
			shape_t get_enumshape_t(){
				return shape_type;
			};
			void set_enumshape_t(shape_t type){
				shape_type=type;
			};
		private:
			shape_t shape_type;
			int width;
			int height;
			double x;
			double y;
			static double area_r; 
			static double length_r;
	};	
}	

#endif
