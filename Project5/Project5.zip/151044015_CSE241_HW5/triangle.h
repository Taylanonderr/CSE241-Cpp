#ifndef TRIANGLE_H_
#define TRIANGLE_H_
	#include <iostream>
	#include <fstream>
	#include <cmath>
#include <vector>
#include "Shape.h"

using namespace std;
namespace my_shape{
	class Negative_triangle_class{
		public:
			Negative_triangle_class(){}
			Negative_triangle_class(double a){
				cout<<"Invalid coordinates error triangle x or y"<<endl;
			}
	};
	class triangle : public Shape {
		public:
			triangle();
			triangle(double f_side);		
			triangle(double first,double second,double third, double fourth, double fifth,double sixth );	
			triangle(double first,double second,double third, double fourth, double fifth,double sixth,double side_t );		

			double getSide()const;
			void setSide(double side_t);	
			double getPosition_x()const;
			void setPosition_x(double x_koordinat);
			double getPosition_y()const;			
			void setPosition_y(double y_koordinat);
			double getPosition_x2()const;
			void setPosition_x2(double x_koordinat);
			double getPosition_y2()const;	
			void setPosition_y2(double y_koordinat);
			double getPosition_x3()const;
			void setPosition_x3(double x_koordinat);
			double getPosition_y3()const;			
			void setPosition_y3(double y_koordinat);						
			double area();
			double perimeter();		
			ostream& draw(ostream& file);//                                               deneme
			const triangle operator +(  const double addbing_size);		
			const triangle operator -(  const double subbing_size);			
			triangle &operator++(); //Prefix version	
			triangle *operator++(int ); //Postfix version
			triangle &operator--(); //Prefix version	
			triangle *operator--(int ); //Postfix version				
			static double total_areas();
			static double perimeter_length();
			shape_t get_enumshape_t(){
				return shape_type;
			};
			void set_enumshape_t(shape_t type){
				shape_type=type;
			};
		private:
			shape_t shape_type;
			double side;
			double x;
			double x2;
			double x3;
			double y;
			double y2;
			double y3;
			static double area_t; 
			static double length_t;		
	};
}
	

#endif

