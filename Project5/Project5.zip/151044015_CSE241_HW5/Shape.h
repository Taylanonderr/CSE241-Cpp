#ifndef SHAPE_H_
#define SHAPE_H_
#include <iostream>
#include <fstream>
#include <vector>


using namespace std;

 namespace my_shape{
class Shape{
	public:
		enum class shape_t{
			big_type,		//container shapes type to write svg file different color
			small_type		//inner shapes type to write svg file different color
		};	
		

		virtual double area()=0;
		virtual double perimeter()=0;	
		virtual Shape &operator++(){}; //Prefix version	
		virtual	Shape *operator++(int ){}; //Postfix version
		virtual	Shape &operator--(){}; //Prefix version	
		virtual	Shape *operator--(int ){}; //Postfix version				
		bool operator !=(  Shape & obj2);
		bool operator ==(  Shape & obj2);	
		bool operator >(   Shape & obj2);	
		bool operator <(   Shape & obj2);			
		virtual ostream& draw(ostream& outputStream)=0;
		friend ostream& operator<<(ostream& outputStream, Shape &obje);
		


	};
}			




#endif	
