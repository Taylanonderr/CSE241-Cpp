#ifndef POLYGON_H_
#define POLYGON_H_
#include <iostream>
#include <fstream>
#include <cmath>
#include <vector>
#include "Shape.h"
#include "rectangle.h"
#include "circle.h"
#include "triangle.h"
using namespace std;

namespace my_shape{
class Polygon: public Shape{
	public:
		Polygon(){}
		double area()=0;
		double perimeter()=0;	

		virtual ostream& draw(ostream& outputStream)=0;		
		friend ostream& operator <<(ostream& outputStream,  Polygon &obje);		
		class Point2D{
			public:			
				double getCoord_x()const;
				void setCoord_x(double new_coordinate);
				double getCoord_y()const;
				void setCoord_y(double new_coordinate);		
				Polygon::Point2D& operator[](int index);
			
		
			private:
				double coord_x;
				double coord_y;

		};
		//friend ostream& operator <<(ostream& outputStream, const Polygon &obje);	
		
	Polygon& operator[](int index);
	

	};
}	

#endif

