#ifndef COMPOSEDSHAPE_H_
#define COMPOSEDSHAPE_H_
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <vector>
#include "rectangle.h"
#include "circle.h"
#include "Polygon.h"
#include "triangle.h"
#include "Shape.h"

using namespace std;

namespace my_shape {
	class ComposedShape: public Shape{
public:

		ComposedShape();
		ComposedShape(rectangle &shape,rectangle &small_shape);	/*this constructor for main container rectangle and small container rectangle assign the objes which create in main,to composedshape clas's objes*/
		ComposedShape(rectangle &shape,triangle &small_shape );	/*this constructor for main container rectangle and small container triangle assign the objes which create in main,to composedshape clas's objes*/
		ComposedShape(rectangle &shape,circle &small_shape);	/*this constructor for main container rectangle and small container circle assign the objes which create in main,to composedshape clas's objes*/	
		ComposedShape(triangle &shape,rectangle &small_shape );	/*this constructor for main container triangle and small container rectangle assign the objes which create in main,to composedshape clas's objes*/
		ComposedShape(triangle &shape,triangle &small_shape);	/*this constructor for main container triangle and small container triangle assign the objes which create in main,to composedshape clas's objes*/
		ComposedShape(triangle &shape,circle &small_shape);		/*this constructor for main container triangle and small container circle assign the objes which create in main,to composedshape clas's objes*/
		ComposedShape(circle &shape,rectangle &small_shape );	/*this constructor for main container circle and small container rectangle assign the objes which create in main,to composedshape clas's objes*/
		ComposedShape(circle &shape,triangle &small_shape);		/*this constructor for main container circle and small container triangle assign the objes which create in main,to composedshape clas's objes*/
		ComposedShape(circle &shape,circle &small_shape);		/*this constructor for main container circle and small container circle assign the objes which create in main,to composedshape clas's objes*/		
		void optimalfit();
		inline char getMainchar()const;
		void setMainchar(char main_container);
		inline char getSmallchar()const;
		void setSmallchar(char main_container);
		vector<Shape*> getVector_Shape()const;
		void setVector_Shape(Shape* shape_obje);		
		rectangle getobje(){return small_rectangle; }	
		Shape& operator[](int index);
		ComposedShape( const ComposedShape& rightSide);	
		ComposedShape& operator =( const ComposedShape& rightSide);		/*assigment operator overloading*/			
		virtual ostream& draw(ostream& outputStream);

		~ComposedShape();
	double area(){		/*I calculate each step my innershapes whole area and acces with cast my voi* variable*/

	}
	double perimeter(){		/*I calculate each step my innershapes whole perimeter length and acces with cast my voi* variable*/

	}

	private:
	shape_t shape_type;
	rectangle small_rectangle;
	triangle triang;
	triangle small_triangle;	
	rectangle rectang;
	circle circ;
	circle small_circle;		
	char main_char;
	char small_char;
	vector <Shape*> shape_v;	
	void optimalfit_helper1();
	void optimalfit_helper2();
	void optimalfit_helper3();
	void optimalfit_helper4();
	void optimalfit_helper5();
	void optimalfit_helper6();
	void optimalfit_helper7();
	void optimalfit_helper8();
	void optimalfit_helper9();
};
}

#endif	
